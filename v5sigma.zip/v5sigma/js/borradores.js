const borradores = {
	template_borrador: '',
	arrays: [],
	counts: [],
	filtro: 'todos',
	categoria: 'todas',
	orden: 'titulo',
	filtro_anterior: '',
	categoria_anterior: '',
	orden_anterior: '',
	//Buscador
	search_q: '',
	search_q_anterior: '',
	printResult(){
		const resultados = $('ul#resultados-borradores').empty();
		this.arrays.forEach(borrador => {
			const { id, categoria, imagen, tipo, categoria_name, url, titulo, causa, fecha_print } = borrador;
			let isUrl = (tipo === 'borradores');
			let temp = borradores.template_borrador
				.replace(/__id__/g, id)
				.replace(/__categoria__/g, categoria)
				.replace(/__imagen__/g, imagen)
				.replace(/__tipo__/g, tipo)
				.replace(/__categoria_name__/g, categoria_name)
				.replace(/__url__/g, url)
				.replace(/__titulo__/g, titulo)
				.replace(/__causa__/g, causa)
				.replace(/__fecha_guardado__/g, fecha_print)
				.replace(/__borrador_id__/g, id)
				.replace(/__url__/g, isUrl ? url : '')
				.replace(/__onclick__/g, isUrl ? '' : `borradores.show_eliminado(${id}); return false;`);

			resultados.append(temp);
			if(borrador['tipo'] !== 'eliminados') {
				$(`#borrador_id_${id} span.causa`).remove();
			}
		});
	},
	printCounts(printCategorias){
		//Filtros
		const counts = ['todos', 'borradores', 'eliminados'];
		counts.map(count => $(`#${count} span.count`).html(this.counts[count]));
		//Categorias
		$('#todas span.count').html(this.counts['todos']);
		$.each(this.counts['categorias'], function(categoria, data) {
			if(printCategorias) {
				$('ul#borradores-categorias').append(`<li id="${categoria}" class="d-flex justify-content-between align-items-center py-1 mb-2"><span role="button" onclick="borradores.active(this); borradores.categoria = '${categoria}'; borradores.query(); return false;">${data['name']}</span> <span class="count">${data['count']}</span></li>`);
			} else {
				$(`ul#borradores-categorias li#${categoria} span.count`).html(data['count']);
			}
		});
	},
	query(force_no_parcial) {
		//Determinacion de busqueda parcial o no
		let parcial = false;
		if(!force_no_parcial){
			//Filtro
			if(this.filtro_anterior != this.filtro){
				parcial = (this.filtro_anterior == 'todos');
			//Categoria
			} else if(this.categoria_anterior != this.categoria){
				parcial = (this.categoria_anterior == 'todas');
			//Orden
			} else if(this.orden_anterior != this.orden){
				parcial = true;
			//Search
			} else if(this.search_q_anterior != this.search_q){
				//Calcula por la busqueda anterior si tiene que hacer una busqueda parcial
				let re = new RegExp(this.search_q_anterior);
				parcial = re.test(this.search_q);
			}
		}
		//Si esta vacio no realizo ninguna consulta
		if((parcial && this.arrays.length==0) || (!parcial && borradores_data.length == 0)){
			this.filtro_anterior = this.filtro;
			this.categoria_anterior = this.categoria;
			this.orden_anterior = this.orden;
			this.search_q_anterior = this.search_q;
			return;
		}
		this.arrays = jLinq.from(parcial ? this.arrays : borradores_data);
		//Filtro
		if(this.filtro != 'todos' && (!parcial || this.filtro_anterior != this.filtro)) {
			this.arrays = this.arrays.equals('tipo', this.filtro);
		}
		//Categoria
		if(this.categoria != 'todas' && (!parcial || this.categoria_anterior != this.categoria)) {
			this.arrays = this.arrays.equals('categoria', this.categoria);
		}
		//Search
		if(!empty(this.search_q) && (!parcial || this.search_q_anterior != this.search_q)) {
			this.arrays = this.arrays.contains('titulo', this.search_q);
		}
		//Ordenar por
		if(!parcial || this.orden_anterior != this.orden) {
			this.arrays = this.arrays.orderBy(this.orden);
		}
		this.arrays = this.arrays.select();
		this.filtro_anterior = this.filtro;
		this.categoria_anterior = this.categoria;
		this.orden_anterior = this.orden;
		this.search_q_anterior = this.search_q;
		this.printResult();
	},
	search(query, event){
		tecla = (document.all) ? event.keyCode:event.which;
		if(tecla === 27) { //Escape, limpio input
			query = '';
			$('#borradores-search').val('');
		}
		if(query == this.search_q) return;
		//Calcula por la busqueda anterior si tiene que hacer una busqueda parcial
		this.search_q = query;
		this.query();
	},
	search_focus(){
		$('label[for="borradores-search"]').hide();
	},
	search_blur(){
		if(empty($('#borradores-search').val())) $('label[for="borradores-search"]').show();
	},
	active(element){
		$(element).parent().parent().parent().children('li').removeClass('bg bg-opacity-1');
		$(element).parent().parent().addClass('bg bg-opacity-1');
	},
	eliminar(id, dialog){
		mydialog.close();
		if(dialog){
			mydialog.center();
			mydialog.master({
				title: 'Eliminar Borrador',
				body: '&iquest;Seguro que deseas eliminar este borrador?',
				buttons: {
					good: { value: 'Si', action: `borradores.eliminar(${id}, false)` }
				}
			})
			return;
		}
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/borradores-eliminar.php`, { borrador_id: id }, response => {
			if(response.charAt(0) === '0') {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
			$(`li#borrador_id_${id}`).fadeOut('normal', function() { $(this).remove(); });
			//Quedaba solo un borrador
			if(borradores_data.length === 1) {
				$('div#borradores div#res').html('<div class="emptyData">No tienes ning&uacute;n borrador ni post eliminado</div>');

				//Lo elimino de borradores_data
				for(let i = 0; i < borradores_data.length; i++){
					if(borradores_data[i]['id'] == id){
						//Hago los descuentos de contadores
						borradores.counts['todos']--;
						borradores.counts[borradores_data[i]['tipo']]--;
						borradores.counts['categorias'][borradores_data[i]['categoria']]['count']--;
						borradores_data.splice(i, 1);
						break;
					}
				}
				//Lo elimino de borradores.arrays
				for(let i=0; i < borradores.arrays.length; i++){
					if(borradores.arrays[i]['id'] == id){
						borradores.arrays.splice(i, 1);
						break;
					}
				}
				//Actualizo contadores
				borradores.printCounts();
			}
         $('#loading').fadeOut(350);
		})
		.fail(() => {
			mydialog.toast('Hubo un error al intentar procesar lo solicitado', 'danger');
         $('#loading').fadeOut(350);
		});
	},

	show_eliminado(id) {
		mydialog.procesando_inicio('Post');
      $('#loading').fadeIn(250);
      $.post(`${global_data.url}/borradores-get.php`, { borrador_id: id }, response => {
      	mydialog.procesando_fin();
			switch(response.charAt(0)){
				case '0': //Error
					mydialog.toast(response.substring(3), 'danger');
				break;
				case '1':
					mydialog.master({
						title: 'Post',
						body: response.substring(3)
					});
				break;
			}
			$('#loading').fadeOut(350);
      })
      .fail(() => {
      	mydialog.toast('Hubo un error al intentar procesar lo solicitado', 'danger');  
			$('#loading').fadeOut(350);    	
      })
      .always(() => {
			mydialog.procesando_fin();
         $('#loading').fadeOut(350);
      });
	}
}

$(document).ready(function(){
	//Guardo el template en una variable
	borradores.template_borrador = $('#template-result-borrador').html();
	$('#template-result-borrador').remove();
	//Inicializo contadores
	borradores.counts = {
		todos: 0, 
		borradores:0, 
		eliminados:0, 
		categorias: {}
	};
	//Hago conteo inicial
	$.each(borradores_data, function(i, borrador) {
		borradores.counts['todos']++;
		borradores.counts[borrador['tipo']]++;
		if(borradores.counts['categorias'][borrador['categoria']]) {
			borradores.counts['categorias'][borrador['categoria']]['count']++;
		} else {
			borradores.counts['categorias'][borrador['categoria']] = { 
				name: borrador['categoria_name'], 
				count:1
			};
		}
	});
	borradores.counts['categorias'] = sortObject(borradores.counts['categorias']);
	//Imprimo los contadores
	borradores.printCounts(true);
	//Query inicial
	borradores.query(true);
});