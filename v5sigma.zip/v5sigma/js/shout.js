const shoutConfig = {
   maxLength: 250,
   apiBaseUrl: global_data.url,
   icons: ['fa-lock-open', 'fa-user-lock', 'fa-lock'],
   placeholders: {
      foto: `https://i.imgur.com/${string_random(6)}.png`,
      enlace: global_data.url,
      video: `https://youtube.com/watch?v=${string_random(11)}`
   }
};

function toggleVisibility(visible = true) {
	$('.shout-loading')[(visible ? 'show' : 'hide')]();
};

function handleLengthValidation(val) {
   if (val.length > shoutConfig.maxLength) {
      return `${error_length} ${val.length} caracteres.`;
   }
   return null;
}

function resetLoader() {
	toggleVisibility(false);
	shout.status = 0;
}

const shout = {
	status: 0,
	adjunto: '',
	type: 'status',
	template: {
		input: `<div class="form-input-group bg-body mb-2"><input type="text" name="input-$1" placeholder="$2"/><button role="button" onclick="shout.adjuntar('$1')"><i class="fas fa-paperclip pe-none" aria-hidden="true"></i></button></div>`
	},
	extensiones: ['jpg', 'jpeg', 'png', 'gif'],
	loadTemplate(input = '') {
		this.type = input;
	   let template = this.template.input.replaceAll('$1', input).replace('$2', shoutConfig.placeholders[input]);
		$('.shout-box .input').html(input === 'status' ? '' : template);
	},
	loadPrivacity() {
		const privacidad = $('#privacidad');
		privacidad.toggleClass('show');
		privacidad.find('span').off('click').on('click', function() {
			const priValue = parseInt($(this).data('value'));
			const iconElement = privacidad.parent().find('i');
			iconElement.removeClass(shoutConfig.icons.join(' ')).addClass(shoutConfig.icons[priValue]);
			$('#shout').attr('data-privacidad', priValue)
		})
	},
	adjuntar() {
      if(shout.status == 1) return false;
      else shout.status = 1;
      toggleVisibility();
		const inpt = $(`input[name="input-${shout.type}"]`);
		let valid = shout.validar(inpt, shout.type);
		if (valid === true) {
			shout.ajaxCheck(inpt.val(), inpt);
		} else {
			mydialog.alert('Error al publicar', valid);
			toggleVisibility(false);
			shout.status = 0;
		}
	},
	validar(input, type) {
		if(imported('import/validar.js', 'isValid', { input, type })) {
			return true;
		}
	},
	// VERIFICAR ARCHIVO
	ajaxCheck(url, input) {
		toggleVisibility();
		if(shout.type === 'video') url = isYoutube(url, 'https://www.youtube.com/watch?v=');
		$.post(`${shoutConfig.apiBaseUrl}/muro-stream.php?do=check&type=${shout.type}`, { url }, response => {
			if(response.charAt(0) === '0') {
				mydialog.alert('Error al publicar', response.substring(3), false);
				return;
			}
			shout.adjunto = input.val();
			$('.input').html(response.substring(3));
			$('#loading').fadeOut(350);
		})
		.done(() => {
			// LOADER/ STATUS
			resetLoader();
			$('#statusPost').html('');
		})
	},
	// COMPARTIR
	compartir() {
		// SI ESTA OCUPADO NO HACEMOS NADA
		if (shout.status === 1) return false;
		else shout.status = 1;
		const valWall = $('#wall');
		const val = valWall.val();
		toggleVisibility();
		const error_length = `Las publicaciones de estado y/o comentarios deben ser inferiores a ${shoutConfig.maxLength} caracteres. Ya has ingresado`;
		// ARCHIVOS ADJUNTOS
		if (shout.type !== 'status') {
			if (shout.adjunto !== '') {
				// VALIDAR
				const error = handleLengthValidation(val);
				if (error) {
				   mydialog.alert('Error al publicar', error);
				   resetLoader();
				} else {
				   shout.ajaxPost(val);
				}
			} else {
				mydialog.alert('Error al publicar', 'Ingresa la <strong>URL</strong> en el campo de texto y a continuaci&oacute;n da clic en <strong>Adjuntar</strong>.');
				resetLoader();
			}
			// PUBLICACION SIMPLE
		} else if (shout.type == 'status') {
			var error = false;
			// VALIDAR
			if (empty(val)) {
				valWall.blur();
				error = true;
				resetLoader();
				return false;
			} else if (val.length > shoutConfig.maxLength) error = `${error_length} ${val.length} caracteres.`;
			// ENVIAR PUBLICACION
			if (error === false) {
				shout.ajaxPost(val);
				return;
			}
			mydialog.alert('Error al publicar', error);
			resetLoader();
		}
	},
	// POSTEAR EN EL MURO
	ajaxPost(data) {
		$('#loading').slideDown(250);
		//DETERMINAR TIPO DE PRIVACIDAD DEL SHOUT BY TO-UP
		let privacidad = $('#shout').data('privacidad');
		let params = toStringParams({ adj: shout.adjunto, data, pid: $('#shout').data('pid'), privacidad });
		toggleVisibility();
		$.post(`${shoutConfig.apiBaseUrl}/muro-stream.php?do=post&type=${shout.type}`, params, response => {
			let message = response.substring(3);
			if(response.charAt(0) === '0') {
				mydialog.toast(message, 'danger');
				return;
			}
			//
			$('#filter_shouts').prepend($(message).fadeIn('slow'));
			$('#wall').val('').focus();
			shoutbox.close()
			$('#shout').data('privacidad', 0)
		})
		.done(() => {
			resetLoader();
			$('#loading').fadeOut(350);
		});
	}
}

$('button[data-type]').on('click', function() {
	let load = $(this).data('type');
	if(in_array(load, ['status', 'foto', 'video', 'enlace'])) {
		shout.loadTemplate(load);
		return;
	}
	if(load === 'privacidad') {
		shout.loadPrivacity();
		return;
	}
});