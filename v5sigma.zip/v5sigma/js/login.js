'use strict';
const urlParams = new URLSearchParams(window.location.search);
const redirectParam = urlParams.get('redirect');
const problem = {
	template(title, next) {
		mydialog.master({
			title,
			body: `<div class="form-group mb-3">
				<label class="form-label" for="r_email">Usuario o e-mail</label>
				<input type="email" id="r_email" name="r_email" class="form-control" placeholder="E-mail con el que te registraste">
			</div>`,
			buttons: { good: { value: 'Continuar', action: next } }
		});
	},
	send(url) {
		const r_email = $('#r_email').val();
		mydialog.procesando_inicio('Procesando...', 'Comprobando información...');
		$.post(`${global_data.url}/${url}.php`, { r_email }, req => {
			mydialog.toast(req.slice(3), (req.charAt(0) === '0' ? 'danger' : 'success'));
			mydialog.procesando_fin();
		});
	},
	account(type, next) {
		const actions = {
			remind_password: { title: 'Recuperar contraseña', url: 'recover-pass' },
			resend_validation: { title: 'Reenviar validación', url: 'recover-validation' }
		};
		if (!next) {
			this.template(actions[type].title, `${type}(true)`);
			return;
		}
		this.send(actions[type].url);
	}
};
const login = {
	loading(start = true) {
		$('button.button[type="submit"]').html((start ? 'Cargando' : 'Iniciar Sesión'))[start ? 'addClass' : 'removeClass']('loading');
	},
	showError(field, message) {
		$(`[data-block="${field}"] .helper`).addClass('error').html(message);
	},
	fieldVerify(field) {
		const value = $(field).val();
      if (!value) {
         $(field).focus();
         login.showError(field, 'Este campo es obligatorio');
         return false;
      }
      return encodeURIComponent(value);
	},
	iniciar(e) {
		e.preventDefault();
		login.loading(true);
		if(!login.fieldVerify('#nickname') || !login.fieldVerify('#password')) return false;
		const params = $('form[name="iniciar"]').serialize();
		$.post(`${global_data.url}/login-user.php`, params, request => {
			const reqCode = parseInt(request.charAt(0));
			if (reqCode === 0) {
				login.loading(false);
				return mydialog.toast(request.slice(3), 'danger');
			}
			if (reqCode === 2 || reqCode === 3) {
				const field = reqCode === 2 ? '#nickname' : '#password';
				login.showError(field, request.slice(3));
				$(field).focus();
				setTimeout(() => login.loading(false), 1000);
				return;
			}
			location.href = (redirectParam === '/' || redirectParam === null) ? global_data.url : redirectParam;
		});
	}
};

$(document).on('keydown', e => {
   if (e.key === 'Enter') {
      login.iniciar();
   }
});

$(document).ready(() => {
	$('form button[type="submit"]').on('click', login.iniciar);
	$('#nickname, #password').on('keyup', () => $('.helper').removeClass('error').html(''));
	$('.password-toggle').on('click', () => {
		const type = ($('#password').attr('type') === 'password') ? 'text' : 'password';
		$('#password').attr('type', type);
		$('.password-toggle i').toggleClass('fa-eye fa-eye-slash');
	});
});