'use strict';
// INICIO - Comunidades
$('.catecomunidades').on('click', function() {
	let categoria = $(this).attr('value');
	let ruta = empty(categoria) ? '/' : `/home/${categoria}/`;
	document.location.href= `${global_data.url}/comunidades${ruta}`;
});

$('.filtroPopulares').on('click', function() {
	let filtro = $(this).attr('value');
	$('.filtrarPopular > div').hide();
	$(`.filtrarPopular > #ccp_${filtro}`).show();
});

crapeandoShared.start('.share-tema', {
	message: 'Hola a todos, los invito a ver este tema espectacular!',
	active: ['facebook', 'twitter', 'whatsapp'],
	print: false,
   styles: {
      size: '2rem',
      font: '1.325rem'
   }
});

// Editor de respuestas|temas comunidades
if(($('#responder').length || $('#markItUp').length) && !$('.wysibb-texarea').length) {
	if($('#responder').length) {
	   $('#responder').removeAttr('onblur onfocus class style title').css('height', '80').html('').wysibb({ 
	   	buttons: "smilebox,gifbox,|,bold,italic,underline,link" 
	   });
	}
   if($('#markItUp').length) $('#markItUp').css({height: 470}).wysibb();
}

$('#add_new_com #nombre').on('keyup', function(event) {
	let nombre = $(this).val();
	// Normalizar la cadena para eliminar acentos
	let normalized = nombre.normalize("NFD");
	// Eliminar todos los caracteres que no sean letras o espacios
	let cleaned = normalized.replace(/[^a-zA-Z ]/g, '').replace(/ /g, '-').toLowerCase();
	$('#add_new_com #ncorto').val(cleaned)
});

function displayMessages(element, display = true) {
	$(element)[(display ? 'addClass' : 'removeClass')]('error');
}

$('#remoback').on('change', function() {
   const colorValue = this.value;
   $('#back_color').val(colorValue.startsWith('#') ? colorValue.substring(1) : colorValue);
});

const comunidad = {
	// Al usar onProcess en false, no se abrirá el modal por defecto
	onProcess: true,
	requeridos(error = false) {
		// Variable para almacenar el primer campo con error
   	let firstErrorField = null;
		$('.required').each(function() {
        	if ($(this).val() == '' || $(this).val() == 0) {
            displayMessages(this);
            error = true;
            // Guardar el primer campo con error si no ha sido guardado ya
            if (firstErrorField === null) {
               firstErrorField = $(this);
            }
        } else displayMessages(this, false);
   	});
   	return error;
	},
	// Función para mostrar modales con estructura común
	mostrarModal([title, body, valueOK, actionOK, valueFail = 'Cancelar', actionFail = 'close']) {
		mydialog.master({title, body, buttons: {
			good: { value: valueOK, action: actionOK },
			fail: { value: valueFail, action: actionFail }
		}});
	},
	realizarSolicitudAJAX(endpoint, data, onSuccess, onError) {
		if(comunidad.onProcess === true) mydialog.procesando_inicio();
		$.post(`${global_data.url}/comunidades-${endpoint}.php`, data, response => {
			if(comunidad.onProcess === true) mydialog.procesando_fin();
			const isSuccess = parseInt(response.charAt(0)) === 1;
			if (isSuccess || comunidad.onProcess === false) {
				if (typeof onSuccess === 'function') onSuccess(response);
			} else {
				mydialog.alert('Error', response.substring(3));
				if (typeof onError === 'function') onError();
			}
		});
	},
	actualizarConteo(selector, incremento) {
		const total = parseInt($(selector).text(), 10) + incremento;
		$(selector).text(total);
	},
	unirme() {
		$('#loading').fadeIn(250);
		this.onProcess = false;
		this.realizarSolicitudAJAX('unirme', gget('comid', true), req => {
			mydialog.toast(req.substring(3), (req.charAt(0) == '0' ? 'danger' : 'success'));
			if(req.charAt(0) === '1') {
				$('.action_comunidad').toggle();
				comunidad.actualizarConteo('#com_miembros_total', 1);
			}
		});
		$('#loading').fadeOut(250);
	},
	abandonar(continuar) {
		if (!continuar) {
			this.mostrarModal(['Abandonar comunidad', '&iquest;Realmente deseas abandonar la comunidad?', 'Aceptar', `comunidad.abandonar(true)`]);
			return;
		}
		this.realizarSolicitudAJAX('abandonar', gget('comid', true), req => {
			mydialog.toast(req.substring(3), (req.charAt(0) == '0' ? 'danger' : 'success'));
			if(req.charAt(0) === '1') {
				mydialog.close();
				$('.action_comunidad').toggle();
				comunidad.actualizarConteo('#com_miembros_total', -1);
			}
		});
	},
	seguir_comunidad() {
		$('#loading').fadeIn(250);
		this.realizarSolicitudAJAX('seguir_com', gget('comid', true), response => {
			const accion = parseInt(response.charAt(0), 10);
			const btnToShow = accion === 1 ? '#unfollow_comr' : '#follow_com';
			const btnToHide = accion === 1 ? '#follow_com' : '#unfollow_comr';
			$(btnToShow).show();
			$(btnToHide).hide();
			comunidad.actualizarConteo('#com_seguidores_total', accion === 1 ? 1 : -1);
		});
		$('#loading').fadeOut(250);
	},
	load_page(page, rid = 'temas', rget = 'comid') {
		$('#loading').fadeIn(250);
		$(`#result_${rid}`).css({'opacity': 0.5});
		comunidad.onProcess = false;
		this.realizarSolicitudAJAX(`pages_${rid}`, gget(rget, true) + '&page=' + page, response => {
			$(`#result_${rid}`).html(response).css({'opacity' : 1});
			$('#loading').fadeOut(250);
		});
	},
	subCategorias() {
		let cid = $('#ShowCats').val();
		if(cid === 0) {
			$('#ShowSubcats').html('<option value="0">Selecciona una categor&iacute;a</option>').attr({ disabled: 'disabled' });
		}
		comunidad.onProcess = false;
		comunidad.realizarSolicitudAJAX('subcategorias', `cid=${cid}`, response => {
			$('#ShowSubcats').removeAttr('disabled').html(response);
		});
	},
	crear_comunidad() {
   	let error = this.requeridos();
   	// Si hay error, desplazarse al primer campo con error
    	if (error) {
        	$('html, body').animate({
            scrollTop: firstErrorField.offset().top - 75 // Ajusta el desplazamiento según sea necesario
        	}, 800); // Velocidad del desplazamiento en milisegundos
        	return;
    	} else  {
			// Obtener el campo de color de fondo y eliminar el "#" si existe
			const backColorInput = $('#back_color');
			let backColorValue = backColorInput.val();
			if (backColorValue.startsWith('#')) {
				backColorValue = backColorValue.substring(1); // Eliminar el "#"
				backColorInput.val(backColorValue); // Actualizar el valor sin el "#"
			}
			// Enviar el formulario después de modificar el valor
			$('#add_new_com').submit();
		}
	},
	borrar(comid, continuar) {
		if (!continuar) {
			this.mostrarModal(['Eliminar Comunidad', '&#191;Quieres eliminar esta comunidad?', 'Si, elimiar', `comunidad.borrar(${cid}, true)`]);
			return;
		}
		this.realizarSolicitudAJAX('borrar_com', gget('comid', true) + '&susp=1', req => {
			mydialog.toast(req.substring(3), (req.charAt(0) == '0' ? 'danger' : 'success'));
		}); 
		$('#loading').fadeOut(350);
	},
	favorito: {
		filtrar(cat) {
			$('.com_category').each(function(){
				$(this)[(cat === 'all' ? 'show' : 'hide')]();
				if(cat !== 'all') {
					$('.com_category.'+cat).show();
				}
        });
		},
		eliminar(favid) {
			comunidad.realizarSolicitudAJAX('del_favorito', { favid }, req => {
				mydialog.toast(req.substring(3), (req.charAt(0) === '0' ? 'danger' : 'success'));
				if(req.charAt(0) == '1') {
					$('#fav_tema_id_' + favid).fadeOut(100, function(){ 
						$(this).remove();
					});
				}
			}); 
			$('#loading').fadeOut(350);
		}
	},
	tema: {
		eliminar(accion, continuar) {
			const isMod = accion === 'mod';
			const body = isMod ? '&iquest;Seguro que deseas borrar este tema?<br /><br /><input type="text" class="input_text" id="del_razon" maxlength="80" placeholder="Causa..." />' : '&iquest;Seguro que deseas borrar tu tema?';

			if (!continuar) {
				comunidad.mostrarModal(['Eliminar tema', body, 'Eliminar', `comunidad.tema.eliminar('${accion}', true)`]);
				return;
			}

			let data = gget('temaid', true);
			if (isMod) data += `&razon=${encodeURIComponent($('#del_razon').val() || 'Sin razón informativa!')}`;
			comunidad.realizarSolicitudAJAX('del_tema', data);
		},
		reactivar(continuar) {
			if (!continuar) {
				comunidad.mostrarModal(['Reactivar tema', '&iquest;Seguro que deseas reactivar este tema?', 'Reactivar', `comunidad.tema.reactivar(true)`]);
				return;
			}
			comunidad.realizarSolicitudAJAX('reactivar_tema', cgget('temaid', true));
		},
		recomendar(continuar) {
			if (!continuar) {
				comunidad.mostrarModal(['Recomendar', '¿Quieres recomendar este tema a tus seguidores?', 'Recomendar', `comunidad.tema.recomendar(true)`]);
				return;
			}
			comunidad.realizarSolicitudAJAX('reco_tema', gget('temaid', true), () => comunidad.actualizarConteo('#t_share', 1));
		},
		votar(accion) {
			const data = `voto=${accion}&${gget('temaid')}`;
			comunidad.realizarSolicitudAJAX('votar_tema', data, () => {
				let votosTotal = parseInt($('#votos_total').text());
				votosTotal += accion === 'pos' ? 1 : -1;
				$('#votos_total').css({ color: votosTotal < 0 ? 'red' : votosTotal > 0 ? 'green' : '#222' }).html(votosTotal);
			});
		},
		seguir() {
			comunidad.onProcess = false;
			comunidad.realizarSolicitudAJAX('seguir_tema', gget('temaid', true), () => {
				const isFollowing = $('#follow_tema').is(':visible');
				$('#follow_tema, #unfollow_tema').toggle();
				comunidad.actualizarConteo('#segs_total', isFollowing ? 1 : -1);
			});
		},
		comentar() {
			let data = gget('temaid', true);
			let text = $('#responder').bbcode();
			$('#btn_newcom').attr({ disabled: 'disabled' });
			if(empty(text) || text.length > 1500) {
				if(text.length > 1500) mydialog.alert('Error', "Tu comentario no puede ser mayor a 1500 caracteres.");
				if(empty(text)) mydialog.alert('Error', "Tu comentario no puede estar vacio.");
				$('#responder').focus();
				$('#btn_newcom').removeAttr('disabled');
				return;
			}
			$('#loading').fadeIn(250);   
			data += `&body=${encodeURIComponent(text)}`;
			comunidad.onProcess = false;
			console.log(data)
			comunidad.realizarSolicitudAJAX('responder', data, response => {
				console.log(response)
				let isSuccess = parseInt(response.charAt(0)) === 1;
				if(isSuccess){
					// limpiamos la caja
					$('.ctc_form .wysibb-text-editor.wysibb-body').html('');
					//$('#add_new_com').html(response.substring(3)).slideDown('slow', () => $('.com_bigmsj_blue, .com_bigmsj_red').hide('fast'));
					comunidad.actualizarConteo('#cbt_val', 1);
				} else {			
					//$('.com_bigmsj_red').html(response.substring(3)).show('fast');
				}
				$('#btn_newcom').removeAttr('disabled');
				$('#loading').fadeOut(350);
				mydialog.close();
			});
		},
		crear(continuar = false) {
   		let error = comunidad.requeridos();
			if(error) {
				mydialog.master({
					title: 'Previsualizar',
					body: 'Cargando vista previa....',
					button: { good: { value: 'Cerrar', action: 'close' }, fail: { display: false }}
				});
				let data = toStringParams({
					'titulo': $('input[name=titulo]').val(),
					'cuerpo': $('textarea[name=cuerpo]').bbcode()
				})
				comunidad.realizarSolicitudAJAX('preview_tema', data, response => {
					mydialog.body(response);
					mydialog.buttons(true, true, 'Agregar tema', 'comunidad.tema.crear(true);', true, true, true, 'Cerrar previsualizaci&oacute;n', 'close', true, false);
					$('html, body').animate({scrollTop: firstErrorField.offset().top - 75}, 800);
				});
			}
			if(continuar) $('#add_new_tema').submit();
		},
		guardar() {
   		let error = comunidad.requeridos();
			if(error) {
				// Ya que no son muchos campos
				let dataForm = toStringParams({
					comid: global_data.comid,
					bid: parseInt($('input[name="bid"]').val() || 0),
					titulo: $('input[name=titulo]').val(),
					cuerpo: $('textarea[name=cuerpo]').bbcode(),
					cerrado: ($('input[name="cerrado"]').is(':checked')) ? 1 : 0,
					sticky: ($('input[name="sticky"]').is(':checked')) ? 1 : 0
				});
				$('#loading').fadeIn(250);
				comunidad.onProcess = false;
				comunidad.realizarSolicitudAJAX('save_borrador', dataForm, response => {
					let currentTime = new Date();
					let message;
					// Obtenemos hora
					const hours = [
						currentTime.getHours(),
						currentTime.getMinutes(),
						currentTime.getSeconds()
					].join(':');
					if(parseInt(response.charAt(0)) === 1) {
						$('input[name="bid"]').val(response.substring(3));
						message = `Borrador guardado a las ${hours} hs.`;
					} else {
						message = response.substring(3);
					}
					$('#msj_borrador').html(message);
					$('#loading').fadeOut(250);
				});
			}
		}
	},
	favorito: {
		guardar() {
			$('#loading').fadeIn(250);
			comunidad.onProcess = false;
			comunidad.realizarSolicitudAJAX('add_favorito', gget('temaid', true), response => {
				const isFavourite = parseInt(response.charAt(0)) === 1;
				comunidad.actualizarConteo('#favs_total', isFavourite ? 1 : -1);
				$('.add_favorito').toggle();
				$('#loading').fadeOut(250);
			});
		}
	},
	respuesta: {
		votar(rid, type) {
			$('#loading').fadeIn(250);
			comunidad.onProcess = false;
			comunidad.realizarSolicitudAJAX('votar_respuesta', `voto=${type}&rid=${rid}`, () => {
				comunidad.actualizarConteo(`#total_votos_${rid}`, (type === 'pos' ? 1 : -1));
				$('#loading').fadeOut(250);
			});			
		},
		citar(rid, username) {
			let textarea = $('#respuesta');
			let content = textarea.val();
			const reply = htmlspecialchars_decode($(`#coment_source_${rid}`).html(), 'ENT_NOQUOTES');
			$('.ctc_form .wysibb-text-editor.wysibb-body').html(`[quote=${username}]${reply}[/quote]`);
		},
		eliminar(rid) {
			$('#loading').fadeIn(250);
			$.post(`${global_data.url}/comunidades-del_respuesta.php`, { rid }, response => {
				if(parseInt(response.charAt(0)) === 0) {
					mydialog.toast(response.substring(3), 'danger');
				} else {
					$(`#coment_id_${rid}`).fadeOut(100, function() {
						$(this).remove();
					});
				}
			});
			$('#loading').fadeOut(250);
		}
	},
	miembros: {
		resultados(params) {
			const loadMembers = $('#com_members_result');
			loadMembers.css({  opacity: 0.5  });
			comunidad.onProcess = false;
			comunidad.realizarSolicitudAJAX('load_members', params, response => loadMembers.html(response).css({  opacity: 1 }));
		},
		buscar() {
			let params = gget('comid', true) + '&search=' + $('#search_member').val();
			comunidad.miembros.resultados(params);
		},
		cargar(type = 'miembros') {
			$('.filtro-miembro').removeClass('bg-opacity-3').addClass('bg-opacity-1');
			$(`.filtro-miembro#${type}`).addClass('bg-opacity-3').removeClass('bg-opacity-1');
			let params = gget('comid', true) + '&type=' + type;
			comunidad.miembros.resultados(params);
		},
		administrar(uid) {
			$('#loading').fadeIn(250);
			comunidad.onProcess = false;
			comunidad.realizarSolicitudAJAX('member_admin', gget('comid', true) + '&userid=' + uid, response => {
				let act = parseInt(response.charAt(0));
				if(act === 1) comunidad.mostrarModal(['Moderar usuario', response.substring(3), 'Aceptar', `comunidad.miembros.administrando(true)`]);
				if(act === 0) mydialog.alert('Error', response.substring(3));
			});
		},
		administrando() {
			mydialog.procesando_inicio();
			let data = toStringParams({
				comid: global_data.comid,
				type: ($('input[name="type"]').prop('checked') === 'checked') ? 1 : 2,
				rango: $('select[name="rango"]').val(),
				tiempo: ($('input[name="tiempo"]').prop('checked') === 'checked') ? 0 : 1,
				causa: $('input[name="causa"]').val(),
				dias: $('input[name="dias"]').val(),
				userid: $('input[name="userid"]').val()
			});
			comunidad.onProcess = false;
			comunidad.realizarSolicitudAJAX('member_admin_submit', data, response => {
				let act = parseInt(response.charAt(0));
				mydialog.procesando_fin();
				mydialog.alert((act === 1 ? 'Exito' : 'Error'), response.substring(3), (act === 1));
			});
		},
		habilitar(uid, continuar) {
			if (!continuar) {
				const template = `<span class="d-block py-1">Si vas a reactivar al usuario antes de su habilitaci&oacute;n autom&aacute;tica. Explica tus razones</span>
				<div class="form-group">
					<input type="text" class="input_text" id="del_razon" maxlength="80" placeholder="Causa..." />
				</div>`;
				comunidad.mostrarModal(['Rehabilitar usuario', template, 'Aceptar', `comunidad.miembros.habilitar(${uid}, true)`]);
				return;
			}
			let data = toStringParams({
				comid: global_data.comid,
				userid: uid,
				razon: $('#del_razon').val()
			});
			comunidad.onProcess = false;
			comunidad.realizarSolicitudAJAX('member_reactivar', data, response => {
				let act = parseInt(response.charAt(0));
				mydialog.procesando_fin();
				mydialog.alert((act === 1 ? 'Exito' : 'Error'), response.substring(3), (act === 1));
			});
		}
		
	}
}

const comunidadImagen = {
	cambiar(cid, type = 'perfil') {
		$('#loading').fadeIn(250);
		const input = document.getElementById(`input_${type}`).files[0];

		if(!input) {
			mydialog.alert('Error', 'No seleccionó ningún archivo.');
			$('#loading').fadeOut(250);
			return;
		}

		$('#cei_cambio').css({ 'opacity': 0.5 });
		// Crear FormData y agregar el archivo de imagen
		const formData = new FormData();
		formData.append((type === 'perfil' ? 'imagen' : 'background'), input);
		// Usar fetch en lugar de $.ajaxFileUpload
		let page = (type === 'perfil') ? 'imagen' : 'fondo';
		fetch(`${global_data.url}/comunidades-edit_${page}.php?${gget('comid', true)}`, {
			method: 'POST',
			body: formData
		})
		.then(response => response.json())
		.then(data => {
			if (data.charAt(0) === '1') {
				const imageUrl = data.substring(3) + '?' + new Date().getTime();
				$('#image_' + type).css({ 'opacity': 1 }).attr({ src: imageUrl });
			} else {
				mydialog.alert('Error', data.substring(3));
			}
			$('#loading').fadeOut(250);
		})
		.catch(error => {
			console.error('Error en la solicitud:', error);
			mydialog.alert('Error', 'Ocurrió un error al subir la imagen.');
			$('#loading').fadeOut(250);
		});
	},
};