'use strict';
const borrar_post = (pid, confirmacion = 1) => {
	imported('import/posts.borrar_post.js', 'borrarPost', { pid, confirmacion });
}
function __getAction(element, page, params = {}) {
	$('#loading').fadeIn(250);
	$(element).css('opacity', 0.5);
	$.get(`${global_data.url}/posts-${page}.php`, params, response => $(element).css('opacity', 1).html(response))
	.always(() => $('#loading').fadeOut(350));
};
function filterTypeAction(pestana = 'posts', tipo = 5) {
	let loadPage = (pestana === 'shouts') ? 'shouts' : `tops-${pestana}`;
	let loadHtml = (pestana === 'shouts') ? 'filter_shouts' : `top_${pestana}`;
	__getAction(`#${loadHtml}`, loadPage, { tipo });
};
//ACTUALIZAR COMENTARIOS
const actualizar_comentarios = () => __getAction('#load_comments', 'last-comentarios');
//FILTRO SHOUTS HOME
const filtrar_shout = tipo => __getAction('#filshout', 'shouts', { tipo });
//NUEBE DE TAGS
const UpdateTags = () => __getAction('#load_tags', 'last-tags');
//AFILIADOS
const afiliado = {
	nuevo() {
		imported('import/acciones.afiliados.js', 'nuevoAfiliado');
	},
	enviar() {
		imported('import/acciones.afiliados.js', 'afiliadoEnviar');
	},
	detalles(ref) {
		imported('import/acciones.afiliados.js', 'detalles', ref);
	}
};
var muro = {
	like_this(id, type, obj) { 
		imported('import/perfil.shout-like.js', 'likeShout', { id, type, obj });
	},
	favorito(id) {
		const obj = { endpoint: 'favorito', comid: id, selector: `#shout_favourite_${id}` };
		imported('import/perfil.shouts.js', 'phpPost', obj);
	},
	show_comment_box(id) {
		$('#commentBox' + id).show();
		$('#commentTextarea' + id).focus();
		$('#activida' + id).hide();
	},
	comentar(pid) {
		const textarea = $(`#commentTextarea${pid}`);
		let data = textarea.bbcode();
		if (empty(data)) {
			textarea.focus();
			return false;
		}
		//
		$('#loading').fadeIn(250);
		$(`#carga_${pid}`).show();
		$(`#commentBox${pid}`).hide();
		$.post(`${global_data.url}/muro-stream.php?do=repost`, toStringParams({ data, pid }), response => {
			if (response.charAt(0) === '0') {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
			textarea.html('');
			$(`#commentBox${pid}, #carga_${pid}`).hide();
			$(`#shout_comment_${pid}`).total({ sumar: true, find: '' });
			$('#loading').fadeOut(250);
		})
		.done(() => {
			$('#loading').fadeOut(350);
			$(`#carga_${pid}`).hide();
		});
	}
};