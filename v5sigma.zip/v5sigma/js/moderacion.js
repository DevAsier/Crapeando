function __postAction(urlPath, data, element = '') {
	$.post(`${global_data.url}/${urlPath}`, data, response => {
		mydialog.toast(response.substring(3), (response.charAt(0) == '0' ? 'danger' : 'success'));
		if(!empty(element)) {
			$(element).fadeOut().remove();
		}
	});
}
function handleRedirect(redirect, path, response, element) {
	if (redirect === 'true') mod.redirect(`/moderacion/${path}`, 1200);
	else if (redirect === path) {
		mydialog.alert('Aviso', response.substring(3));
		mod.redirect(`/${path}/`, 2000);
	} else {
		mydialog.close();
		$(element).slideUp();
	}
}
var mod = {
	posts: {
		view(postid) {
			$('#loading').fadeIn(250);
			$.post(`${global_data.url}/moderacion-posts.php?do=view`, { postid }, response => {
				mydialog.master({
					title: '...',
					body: response,
					buttons: {
						good: { enabled: false },
						fail: { value: 'Cerrar' }
					}
				});
				$('#loading').fadeOut(350);
			})
		},
		ocultar(pid) {
			let razon = $('#d_razon').val();
			if (razon.length < 1 || razon.length > 50) {
				let msg = (razon.length > 50) ? 'La raz&oacute;n debe tener menos de 50 letras.' : 'Introduzca una raz&oacute;n';
				mydialog.toast(msg, 'danger');
				razon.focus();
				return;
			}
			__postAction('moderacion-posts.php?do=ocultar', { razon, pid });
		},
		// BORRAR
		borrar(postid, redirect, aceptar) {
			if (!aceptar) {
				$('#loading').fadeIn(250);
				$.post(`${global_data.url}/moderacion-posts.php?do=borrar`, response => {
					mydialog.master({
						title: 'Borrar Post',
						body: response,
						buttons: {
							good: { value: 'Borrar', action: `mod.posts.borrar(${postid}, '${redirect}', 1)` }
						}
					});
					$('#loading').fadeOut(350);
					return;
				});
				return;
			} 
			mydialog.procesando_inicio('Eliminando...', 'Borrar Post');
			let razon = $('#razon').val()
			let razon_desc = $('input[name=razon_desc]').val();
			let send_b = $('#send_b').prop('checked') ? 'yes' : false;

			$('#loading').fadeIn(250);
			$.post(`${global_data.url}/moderacion-posts.php?do=borrar`, { postid, razon, razon_desc, send_b }, response => {
				if(response.charAt(0) === '0') {
					mydialog.toast(response.substring(3), 'danger');
					return;
				}
				handleRedirect(redirect, 'posts', response, '#report_' + postid);
				$('#loading').fadeOut(350);
			}).always(() => {
				mydialog.procesando_fin();
				$('#loading').fadeOut(350);
			});
		}
	},
	mps: {
		borrar(mpid, few) {
			if (!few) {
				mydialog.master({
					title: 'Borrar Mensaje',
					body: '&#191;Quiere eliminar <b>toda</b> la conversaci&oacute;n?',
					buttons: {
						good: { value: 'S&iacute;', action: `mod.mps.borrar(${mpid}, 1)` }
					}
				});
				return;
			}
			__postAction('moderacion-mps.php?do=borrar', { mpid }, '#report_' + mid);			
		}
	},
	fotos: {
		borrar(fid, redirect, aceptar) {
			if (!aceptar) {
				$.post(`${global_data.url}/moderacion-fotos.php?do=borrar`, response => {
					mydialog.master({
						title: 'Borrar Foto',
						body: response,
						buttons: {
							good: { value: 'Borrar', action: `mod.fotos.borrar(${fid}, '${redirect}', 1)` }
						}
					});
					return;
				});
				return;
			}
			mydialog.procesando_inicio('Eliminando...', 'Borrar Foto');
			let razon = $('#razon').val()
			let razon_desc = $('input[name=razon_desc]').val();
			$('#loading').fadeIn(250);
			$.post(`${global_data.url}/moderacion-fotos.php?do=borrar`, { fid, razon, razon_desc }, response => {
				if(response.charAt(0) === '0') {
					mydialog.toast(response.substring(3), 'danger');
					return;
				}
				handleRedirect(redirect, 'fotos', response, '#report_' + fid);
			}).always(() => {
				mydialog.procesando_fin();
				$('#loading').fadeOut(350);
			});
		}
	},
	users: {
		action(uid, action, redirect) {
			let btn_txt = (action == 'aviso') ? 'Enviar' : 'Suspender';
			let titulo = (action == 'aviso') ? 'Enviar Aviso/Alerta' : 'Suspender usuario';
			//
			mod.load_dialog('/moderacion-users.php?do=' + action, 'uid=' + uid, titulo, btn_txt, 'mod.users.set_' + action + '(' + uid + ', ' + redirect + ');');
		},
		set_aviso(uid, redirect) {
			let av_type = $('#mod_type').val();
			let av_subject = $('#mod_subject').val();
			let av_body = $('#mod_body').val();
			//
			mod.send_data('/moderacion-users.php?do=aviso', 'uid=' + uid + '&av_type=' + av_type + '&av_subject=' + av_subject + '&av_body=' + av_body, uid, redirect);
		},
		set_ban(uid, redirect) {
			let b_time = $('#mod_time').val();
			let b_cant = $('#mod_cant').val();
			let b_causa = $('#mod_causa').val();
			//
			mod.send_data('/moderacion-users.php?do=ban', 'uid=' + uid + '&b_time=' + b_time + '&b_cant=' + b_cant + '&b_causa=' + b_causa, uid, "'" + redirect + "'");
		}
	},
	load_dialog(url_get, url_data, titulo, btn_txt, fn_txt) {
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}${url_get}`, url_data, response => {
			mydialog.master({
				title: titulo,
				body: response, 
				buttons: {
					good: { value: btn_txt, action: fn_txt }
				}
			});
		})
		.always(() => $('#loading').fadeOut(350));
	},
	send_data(url_post, url_data, id, redirect) {
		$('#loading').fadeIn(250);
		mydialog.procesando_inicio('Procesando...', 'Espere');
		$.post(`${global_data.url}${url_post}`, url_data, response => {
			if(response.charAt(0) === '0') {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
			mydialog.alert('Aviso', response.substring(3));
			if (redirect === 'true') mod.redirect("/moderacion/" + type, 1200);
			else if (redirect === 'false') $('#report_' + id).slideUp();
			$('#loading').fadeOut(350);
		})
		.always(() => {
			mydialog.procesando_fin();
			$('#loading').fadeOut(350);
		});
	},
	reboot(id, type, hdo, redirect) {
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/moderacion-${type}.php?do=${hdo}`, { id }, response => {
			if(response.charAt(0) === '0') {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
			mydialog.toast(response.substring(3));
			$('#report_' + id).fadeOut();
			if (redirect) {
				if (redirect) mod.redirect("/moderacion/" + type, 1200);
				else $('#report_' + id).slideUp();
			}
			$('#loading').fadeOut(350);
		})
		.always(() => $('#loading').fadeOut(350));
	},
	redirect(url_ref, time) {
		setTimeout(function() {
			document.location.href = global_data.url + url_ref;
		}, time)
	}
}