'use strict';
/**
 * string_random = Crea una cadena de texto aleatorio
 * toStringParams = Convierte objeto a parametros
 * kmg = Hace lo mismo que el plugin kmg de smarty
 * isYoutube = Comprueba si el enlace es de youtube
 * isURL = Comprueba si es una url
 * isImage = Comprueba si es una imagen
*/
function string_random(t=10){const r="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";let n="";for(let o=0;o<t;o++)n+=r.charAt(Math.floor(62*Math.random()));return n};
function toStringParams(r){return new URLSearchParams(r).toString()};
function kmg(t){if(t<=0)return"0";const n=Math.floor((t.toString().length-1)/3);return 0===n?t.toString():(t/Math.pow(1e3,n)).toFixed(1)+["","K","M","B","T"][n]};const isYoutube=(t,e="")=>{const u=t.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/]+\/.+|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^&?#]{11})/);return empty(e)?!(!u||11!==u[1].length)&&u[1]:e+u[1]};const isURL=(t)=>{return/^(https?:\/\/)?([\w-]+(\.[\w-]+)+)([\w.,@?^=%&:/~+#-]*[\w@?^=%&/~+#-])?$/.test(t)};const isImage=(t)=>{return/\.(jpg|jpeg|png|gif|bmp|svg|webp|tiff)$/i.test(t)};
/**
 * Imported v1.2
 * Lo que hace es cargar el código cuando es necesario
 * y que no se cargue cuando no se usa
 * Ahora verifica si ya fue importado
*/
const importedFiles=new Map;async function imported(o="",r="",t,e="theme"){let i;try{const{img:e}=global_data;if(i=`${e}js/${o}?v`+string_random(4),importedFiles.has(i))return void console.log(`Archivo ${i} ya ha sido importado.`);const n=await import(i);importedFiles.set(i,!0),n[r]?n[r](t):console.error(`Function ${r} no se encontro en ${i}`)}catch(o){console.error(`Error al importar ${i}:`,o)}}
// Complemento creado para Crapeando
const crapeandoShared={message:"Hola a todos, los invito a ver este artículo espectacular!",active:["facebook","twitter","reddit","telegram","whatsapp"],print:!0,styles:{color:!0,box:!0,size:"1.5rem",font:"1rem"},services:{print:{icon:"fas fa-print"},facebook:{url:"https://www.facebook.com/sharer/sharer.php?u={url}&display=popup&ref=plugin",icon:"fab fa-facebook-f"},reddit:{url:"http://reddit.com/submit?url={url}&title={title}",icon:"fab fa-reddit-alien"},twitter:{url:"https://twitter.com/intent/tweet?url={url}&text={title}",icon:"fab fa-x-twitter"},telegram:{url:"https://t.me/share/url?url={url}&text={title}",icon:"fab fa-telegram"},whatsapp:{url:"https://wa.me/?text={url} - {title}",icon:"fab fa-whatsapp",mobile:"whatsapp://send?text={url} - {title}"}},formated:(t,e)=>t.replace(/\{(.*?)\}/g,((t,r)=>e[r])),createIcon(t,e={}){const{color:r=this.styles.color,box:a=this.styles.box,size:i=this.styles.size,font:s=this.styles.font}=e,{icon:n}=this.services[t];return`<span data-color="${r}" data-service="${t}" class="d-flex justify-content-center align-items-center ${a?"rounded-1":"rounded-circle"}" style="width:${i};height:${i};font-size:${s};"><i class="${n} pe-none"></i></span>`},start(t,e={}){const{styles:r=this.styles,active:a=this.active,print:i=this.print}=e;a.forEach((e=>$(t).append(this.createIcon(e,r)))),i&&$(t).append(this.createIcon("print",r)),$(t).addClass(`crapeando-shared shared_${string_random(10)}`),this.setupEventListeners(a)},getUrl(t){const{url:e,mobile:r}=this.services[t];return"whatsapp"===t&&/Mobi|Android/i.test(navigator.userAgent)?r:e},stringEncode:(t,e)=>"telegram"===t?rawurlencode(e):encodeURIComponent(e),setupEventListeners(t){$("[data-service]").on("click",(function(){const e=$(this).data("service");if("print"===e)crapeandoShared.printPartOfPage(".content-print");else if(t.includes(e)){const t=crapeandoShared.getUrl(e),r=crapeandoShared.formated(t,{url:crapeandoShared.stringEncode(e,location.href),title:crapeandoShared.stringEncode(e,document.title)});window.open(r,document.title,"width=700,height=400,left=300,top=150")}}))},printPartOfPage(t){const e=document.querySelector(t).innerHTML,r=window.open("","","width=600,height=400");r.document.write(`<!DOCTYPE html><html lang="es"><head><title>Imprimir</title><style>body{font-family:Arial,sans-serif;padding:20px;}</style></head><body>${e}</body></html>`),r.document.close(),r.focus(),r.onload=()=>{r.print(),r.onafterprint=()=>r.close()}}};
/**
 * Plugins globales que utilizará el script.
 * Los plugins: (fueron obtenidos desde https://locutus.io/php/)
*/
const empty=e=>{let n,r,t;const o=[void 0,null,!1,0,"","0"];for(r=0,t=o.length;r<t;r++)if(e===o[r])return!0;if("object"==typeof e){for(n in e)if(e.hasOwnProperty(n))return!1;return!0}return!1},htmlspecialchars_decode=(e,n)=>{let r=0,t=0,o=!1;void 0===n&&(n=2),e=e.toString().replace(/&lt;/g,"<").replace(/&gt;/g,">");const i={ENT_NOQUOTES:0,ENT_HTML_QUOTE_SINGLE:1,ENT_HTML_QUOTE_DOUBLE:2,ENT_COMPAT:2,ENT_QUOTES:3,ENT_IGNORE:4};if(0===n&&(o=!0),"number"!=typeof n){for(n=[].concat(n),t=0;t<n.length;t++)0===i[n[t]]?o=!0:i[n[t]]&&(r|=i[n[t]]);n=r}return n&i.ENT_HTML_QUOTE_SINGLE&&(e=e.replace(/&#0*39;/g,"'")),o||(e=e.replace(/&quot;/g,'"')),e.replace(/&amp;/g,"&")},number_format=(e,n,r,t)=>{e=(e+"").replace(/[^0-9+\-Ee.]/g,"");const o=isFinite(+e)?+e:0,i=isFinite(+n)?Math.abs(n):0,a=void 0===t?",":t,l=void 0===r?".":r;let c="";return c=(i?function(e,n){if(-1===(""+e).indexOf("e"))return+(Math.round(e+"e+"+n)+"e-"+n);{const r=(""+e).split("e");let t="";return+r[1]+n>0&&(t="+"),(+(Math.round(+r[0]+"e"+t+(+r[1]+n))+"e-"+n)).toFixed(n)}}(o,i).toString():""+Math.round(o)).split("."),c[0].length>3&&(c[0]=c[0].replace(/\B(?=(?:\d{3})+(?!\d))/g,a)),(c[1]||"").length<i&&(c[1]=c[1]||"",c[1]+=new Array(i-c[1].length+1).join("0")),c.join(l)},rawurlencode=e=>(e+="",encodeURIComponent(e).replace(/!/g,"%21").replace(/'/g,"%27").replace(/\(/g,"%28").replace(/\)/g,"%29").replace(/\*/g,"%2A")),base64_encode=e=>"undefined"!=typeof window&&window.btoa?window.btoa(unescape(encodeURIComponent(e))):Buffer.from(e,"binary").toString("base64"),in_array=(e,n,r=!1)=>{for(let t in n)if(r?n[t]===e:n[t]==e)return!0;return!1};
// Mini plugin para realizar el total
!function(t){t.fn.total=function(n){const a=t.extend({sumar:!1,restar:!1,find:"strong",title:null},n);return this.each((function(){const n=t(this);let e=parseInt(n.data("total"),10)||0;a.sumar?e+=1:a.restar&&(e-=1),null!==a.title&&n.attr("title",a.title),n.attr("data-total",e),""!==a.find?n.find(a.find).text(kmg(e)):n.text(kmg(e))}))}}(jQuery);
/* MyDialog */
var mydialog = {
	is_show: false,
	class_aux: '',
	mask_close: true,
	close_button: false,
	defaultButtons: {
		display_all: true,
		good: { value: 'Aceptar', action: 'close', enabled: true, display: true, focus: true },
		fail: { value: 'Cancelar', action: 'close', enabled: true, display: true, focus: false }
	},
	template: `<div id="mask" class="vw-100 vh-100 bg-body bg-opacity-2"></div>
	<div id="dialog" class="bg-body rounded border border-2">
		<div class="d-flex p-2 justify-content-between align-items-center border-bottom">
			<div id="title" class="fw-bold"></div>
			<button class="reset" onclick="mydialog.close()" role="button">
				<i class="fa-solid fa-xmark" aria-hidden="true"></i>
			</button>
		</div>
		<div id="cuerpo" class="p-3 position-relative overflow-y-auto">
			<div id="modalBody"></div>
		</div>
		<div id="buttons" class="p-2 d-flex justify-content-end align-items-center column-gap-2"></div>
	</div>`,
	show(class_aux){
		if(this.is_show) return;
		else this.is_show = true;
		if($('#mydialog').html() == '') $('#mydialog').addClass('position-fixed z-full').html(this.template);
		if(!empty(this.class_aux)) $('#mydialog').addClass(this.class_aux);
		if(this.mask_close) $('#mask').on('click', () => this.close());
		if(!this.close_button) $('#mydialog .close_dialog').remove();
		$('#mask').css({ width: $(document).width(), height: $(document).height(), display: 'block' });
		$('body').css({ overflow: 'hidden' });
		$(window).on('resize', this.center);
	},
	close() {
		this.class_aux = '';
		this.mask_close = true;
		this.close_button = false;
		this.is_show = false;
		$('#mydialog').removeClass('position-fixed z-full').html('');
		$('body').css({ overflow: 'auto' });
		this.procesando_fin();
	},
	center() {
		$('#mydialog #dialog').css({
         position: 'fixed',
         top: '50%',
         left: '50%',
         transform: 'translate(-50%, -50%)'
      });
	},
	title(title) { $('#mydialog #title').html(`<h4>${title}</h4>`); },
	body(body) { $('#mydialog #modalBody').html(body); },
	buttons(
		buttonsEnabled, 
		confirmDisplay, confirmValue, confirmAction, confirmEnabled, confirmFocus, 
		cancelDisplay, cancelValue, cancelAction, cancelEnabled, cancelFocus
	) {
		if(!buttonsEnabled) { 
			$('#mydialog #buttons').remove();
			return;
		}
			
		// Establecer acciones predeterminadas para los botones
		confirmAction = (confirmAction === 'close' || empty(confirmAction)) ? 'mydialog.close()' : confirmAction;
		cancelAction = (cancelAction === 'close' || !cancelValue || empty(cancelAction)) ? 'mydialog.close()' : cancelAction;
		
		// Valores predeterminados para el segundo botón
		if (!cancelValue) { 
			cancelValue = 'Cancelar';
			cancelEnabled = true; 
		}

		// Generar HTML para los botones
		const buttonHTML = (display, type, enabled, val, action) => 
			display ? `<input type="button" class="button button${type}" value="${val}" onclick="${action}"${enabled ? '' : ' disabled'} />` : '';
		
		let html = buttonHTML(confirmDisplay, '', confirmEnabled, confirmValue, confirmAction);
		html += buttonHTML(cancelDisplay, '-danger', cancelEnabled, cancelValue, cancelAction);

		$('#mydialog #buttons').html(html);
		
		if(confirmFocus) $('#mydialog #buttons .button.button-success').focus();
		else if(cancelFocus) $('#mydialog #buttons .button.button-danger').focus();
	},
	toast(content = 'Realizado con exito', type = 'success', timeout = 5) {
		const styles = {
			success: { bg: '0,80,0', color: '204,255,204', icon: 'circle-check' }, 
			danger: { bg: '80,0,0', color: '255,204,204', icon: 'circle-xmark' }, 
			warning: { bg: '230,168,56', color: '13,8,8', icon: 'triangle-exclamation' }
		};
		const style = styles[type] || styles.success;
		const toastHTML = `<div class="toast position-fixed z-full mt-4 p-2 d-flex justify-content-start align-items-center column-gap-2 rounded shadow" style="--bg:${style.bg}; --color:${style.color};right:1rem;">
		   <div class="toast-icon image image-3 text-center"><i class="fas fa-${style.icon} pe-none" aria-hidden="none"></i></div>
		   <div class="toast-title fw-500 flex-grow-1">${content}</div>
		   <div class="toast-close image image-3 text-center" role="button" onclick="mydialog.toastClose()"><i class="fas fa-xmark pe-none" aria-hidden="none"></i></div>
		</div>`;
		mydialog.close();
		if($('.toast').html() !== '') $('#mydialog').before(toastHTML);
		setTimeout(() => mydialog.toastClose(), timeout * 1000);
	},
	toastClose() {
		$('.toast').remove();
	},
	alert(title, body, reload) {
		this.show();
		this.title(title);
		this.body(body);
		this.buttons(true, true, 'Aceptar', 'mydialog.close();' + (reload ? 'location.reload();' : 'close'), true, true, false);
		this.center();
	},
	error_500(fun_reintentar){
		setTimeout(function(){
			mydialog.procesando_fin();
			mydialog.show();
			mydialog.title('Error');
			mydialog.body("Error al intentar procesar lo solicitado");
			mydialog.buttons(true, true, 'Reintentar', 'mydialog.close();'+fun_reintentar, true, true, true, 'Cancelar', 'close', true, false);
			mydialog.center();
		}, 200);
	},
	procesando_inicio(title, value = 'Espere por favor...'){
		if(!this.is_show){
			this.show();
			this.title(title);
			this.body('');
			this.buttons(false, false);
			this.center();
		}
		$('#mydialog #cuerpo').css({ height: '120px'}).append(`
			<div id="procesando" class="text-center py-3 position-absolute w-100">
				<div id="mensaje" class="d-flex justify-content-center align-items-center column-gap-2 flex-column">
					<img src="${global_data.img}images/loading_bar.gif" />
					<span>${value}</span>
				</div>
			</div>`);
		$('#mydialog #procesando').fadeIn('fast');
		$('#mydialog #modalBody').fadeOut('fast');
	},
	procesando_fin() {
		$('#mydialog #cuerpo').css({ height: 'auto'});
		$('#mydialog #procesando').fadeOut('fast');
		$('#mydialog #modalBody').fadeIn('fast');
	},
	master(objects, options = {}) {
		const { all = true, good = this.defaultButtons.good, fail = this.defaultButtons.fail } = {
			...this.defaultButtons,
			...objects.buttons,
			good: { ...this.defaultButtons.good, ...objects.buttons?.good },
			fail: { ...this.defaultButtons.fail, ...objects.buttons?.fail }
		};
		this.show(true);
		this.title(objects.title);
		this.body(objects.body);
		this.buttons(all, good.display, good.value, good.action, good.enabled, good.focus, fail.display, fail.value, fail.action, fail.enabled, fail.focus);
		this.center();
	}
};
// Copiar en portapapeles!
function copyBBCodeToClipboard(bbcode) {
   navigator.clipboard.writeText(bbcode).then(() => mydialog.toast("BBCode copiado al portapapeles"))
   .catch(err => console.error("Error al copiar el BBCode al portapapeles: ", err));
}
function cmdSmile() {
	const gifDivId = "GifBox";
   let gifDiv = document.getElementById(gifDivId);
   if (gifDiv) gifDiv.remove();
   else {
   	gifDiv = document.createElement("div");
   	gifDiv.id = gifDivId;
   	document.body.appendChild(gifDiv);
   	$('#loading').fadeIn(250);
   	$.get(`${global_data.url}/live-emojis.php?load=gif`, rqs => {
   		gifDiv.innerHTML = rqs;
   		$('#loading').fadeOut(250);
   	});
   }
}

$(document).on('keydown', function(tecla) {
   if (tecla.key === 'Escape') mydialog.close();
});
// Función para cerrar el modal
function cerrarModal() {
   $('#mydialog').removeClass('modalThumb').html('');
}
$('img.thumbox').on('click', function() {
	const link = $(this).attr('src');
	$('#mydialog').addClass('modalThumb').html(`<span class="close" onclick="cerrarModal()">&times;</span>
   <div class="d-flex flex-column">
   	<img id="modalImage" src="${link}" alt="Imagen expandida">
   	<a id="externalLink" class="external-link" href="${link}" target="_blank">Abrir con el navegador</a>
   </div>`);
});

$(() => {
	if($('lite-youtube').length > 0) imported('lite-youtube.js', 'liteYt');

	$('textarea[data-smile="true"]').each(function() {
      let smileIcon = $('<span class="smileIcon" style="cursor: pointer; margin-left: 5px;float:right"><i class="fas fa-smile"></i></span>');
      $(this).after(smileIcon);
      smileIcon.on('click', () => cmdSmile());
   });
	if($('.js-switch').length > 0) {
	   $(document).on('change', '.js-switch', function() {
   		$(this).val(this.checked ? 1 : 0);
		});
	}
});