'use strict';
// Botón de PAUSA/REANUDAR
$('#btn').on('click', function() {
   let isPause = $('#btn').hasClass('bpausa'); // Determina si el botón está en estado "pausa"
   let newClass = isPause ? 'bplay' : 'bpausa'; // Nueva clase a asignar
   let newIcon = isPause ? 'play' : 'pause'; // Ícono que se mostrará
   // Cambiar clase e ícono del botón
   $('#btn').removeClass(!newClass).addClass(newClass);
   $('#btn').html(`<i class="fas fa-${newIcon}"></i>`);
   // Detener o iniciar el intervalo de actualización
   if (isPause) {
      clearInterval(refreshInterval);
   } else {
      refreshInterval = setInterval(updateLiveActivity, 500);
   }
});

// Función que gestiona la actividad en vivo
function updateLiveActivity() {
	let filter = {};
	['posts', 'shouts', 'usuarios', 'fotos'].forEach(check => {
    	let newDato = '#filter' + check.charAt(0).toUpperCase() + check.slice(1);
   	filter[check] = $(newDato).prop('checked') ? 1 : 0; 
	});

	$.post(`${global_data.url}/envivo-actividad.php`, $.param(filter), request => $('.envivo-results').html(request))
}

// Iniciar el intervalo de actualización al cargar la página
let refreshInterval = setInterval(updateLiveActivity, 5000);