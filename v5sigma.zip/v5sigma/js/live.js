'use strict';
const live = {
	updateTime: 30000,
	hideTime: 20000,
	status: {
		nots: getCookie('live_nots') || 'ON',
		mps: getCookie('live_mps') || 'ON',
		sound: getCookie('live_sound') || 'ON',
	},
	focus: true,
	nTotal: 0,
	mTotal: 0,
	inicializar() {
		if (this.status.nots === 'OFF' && this.status.mps === 'OFF') return;
		setTimeout(() => this.update(), this.updateTime);
	},
	print(ld) {
		$('#js').html(ld);
		this.nTotal += parseInt($('#live-stream').attr('ntotal'));
		this.mTotal += parseInt($('#live-stream').attr('mtotal'));
		const totalNotis = this.nTotal + this.mTotal;

		if (totalNotis > 0) {
			$('#BeeperBox').html($('#live-stream').html()).slideToggle(1000).fadeIn(1200);
			this.mouseEvents();

			if (this.focus) {
				setTimeout(() => this.hide(), this.hideTime);
			} else {
				const {
					s_title: title,
					s_slogan: slogan
				} = global_data;
				$(document).attr('title', `(${totalNotis}) ${title} - ${slogan}`);
				const soundType = this.mTotal > 0 ? 'newMessage' : 'newAlert';
				if (this.status.sound === 'ON') {
					$('#swf').html(`<embed width="1px" height="1px" wmode="transparent" allowscriptaccess="always" quality="high" bgcolor="#ffffff" src="${global_data.url}/inc/ext/${soundType}.swf" type="application/x-shockwave-flash">`);
				}
				notifica.popup(this.nTotal);
				mensaje.popup(this.mTotal);
			}
		}
	},
	mouseEvents() {
		$('.UIBeep').hover(
			function() {
				$(this).addClass('UIBeep_Selected').parent().parent().addClass('UIBeep_Paused');
			},
			function() {
				$(this).removeClass('UIBeep_Selected').parent().parent().removeClass('UIBeep_Paused');
				live.hide();
			}
		);
	},
	update() {
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/live-stream.php`, {
			nots: this.status.nots,
			mps: this.status.mps
		}, h => {
			this.print(h);
			$('#loading').fadeOut(350);
		}).always(() => setTimeout(() => this.update(), this.updateTime));
	},
	hide() {
		$('.UIBeeper_Full').each(function() {
			if (!$(this).hasClass('UIBeep_Paused')) {
				$(this).fadeOut().remove();
				setTimeout(() => live.hide(), 1000);
			}
		});
	},
	chStatus(type) {
		this.status[type] = this.status[type] === 'ON' ? 'OFF' : 'ON';
		setCookie(`live_${type}`, this.status[type], 90);
	}
};
// Función para obtener el valor de una cookie
function getCookie(name) {
	const value = `; ${document.cookie}`;
	const parts = value.split(`; ${name}=`);
	if (parts.length === 2) return parts.pop().split(';').shift();
	return null;
}
// Función para establecer una cookie
function setCookie(name, value, days) {
	// 864e5 es lo mismo que 864 × 10^5 = 86400000
	const expires = new Date(Date.now() + days * 864e5).toUTCString();
	document.cookie = `${name}=${value}; expires=${expires}; path=/`;
}
$(document).ready(() => {
	$('.beeper_x').on("click", function() {
		$(`#beep_${$(this).attr('bid')}`).fadeOut().remove();
		return false;
	});
	live.inicializar();
	$(window).on('focus', () => live.focus = true).on('blur', () => live.focus = false);
});