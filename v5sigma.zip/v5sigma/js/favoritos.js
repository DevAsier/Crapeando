var favoritos = {
	template_favorito: '',
	template_categoria: '',
	objects: {},
	counts: {},
	categoria: 'todas',
	orden: 'fecha_guardado',
	categoria_anterior: '',
	orden_anterior: '',
	search_q: '',
	search_q_anterior: '',
	eliminados_force_order: false,
	eliminados: [],
	printResult: function(){
		const resultados = $('#favbox').empty();
		this.objects.forEach(favorito => {
			const { fav_id, post_id, titulo, categoria, categoria_name, imagen, url, 
				fecha_creado, fecha_creado_formato, fecha_creado_palabras, fecha_guardado, 
				fecha_guardado_formato, fecha_guardado_palabras, puntos, comentarios 
			} = favorito;
			let temp = favoritos.template_favorito
				.replace(/__fav_id__/g, fav_id)
				.replace(/__imagen__/g, imagen)
				.replace(/__categoria_name__/g, categoria_name)
				.replace(/__titulo__/g, titulo)
				.replace(/__url__/g, url)
				.replace(/__fecha_creado_formato__/g, fecha_creado_formato)
				.replace(/__fecha_creado_palabras__/g, fecha_creado_palabras)
				.replace(/__fecha_guardado_formato__/g, fecha_guardado_formato)
				.replace(/__fecha_guardado_palabras__/g, fecha_guardado_palabras)
				.replace(/__puntos__/g, kmg(puntos))
				.replace(/__comentarios__/g, kmg(comentarios));
			resultados.append(temp);
		});
	},
	printCounts(printCategorias){
		//Categorias
		$.each(this.counts, function(categoria, data){
			if(printCategorias) {
				let appcat = favoritos.template_categoria
				.replace(/__categoria__/g, categoria)
				.replace(/__categoria_name__/g, data['name'])
				.replace(/__count__/g, data['count'])
				$('div.categoriaList ul').append(appcat);
			} else {
				$(`li#cat_${categoria} span.count`).html(data['count']);
			}
		});
	},
	query(force_no_parcial) {
		let parcial = false;
		if(!force_no_parcial){
			//Categoria
			if(this.categoria_anterior !== this.categoria) {
				parcial = (this.categoria_anterior == 'todas');
			//Orden
			} else if(this.orden_anterior !== this.orden) {
				parcial = true;
			//Search
			} else if(this.search_q_anterior !== this.search_q) {
				//Calcula por la busqueda anterior si tiene que hacer una busqueda parcial
				let re = new RegExp(this.search_q_anterior);
				parcial = re.test(this.search_q);
			}
		}
		//Si esta vacio no realizo ninguna consulta
		if((parcial && this.objects.length==0) || (!parcial && favoritos_data.length == 0)){
			this.categoria_anterior = this.categoria;
			this.orden_anterior = this.orden;
			this.search_q_anterior = this.search_q;
			return;
		}
		this.objects = jLinq.from(parcial ? this.objects : favoritos_data);
		//Categoria
		if(this.categoria != 'todas' && (!parcial || this.categoria_anterior != this.categoria)) {
			this.objects = this.objects.equals('categoria', this.categoria);
		}
		//Search
		if(!empty(this.search_q) && (!parcial || this.search_q_anterior != this.search_q)) {
			this.objects = this.objects.contains('titulo', this.search_q);
		}
		//Ordenar por
		if(!parcial || this.orden_anterior != this.orden || this.eliminados_force_order) {
			this.objects = this.objects.orderBy((this.orden=='titulo' ? '' : '-') + this.orden);
		}
		this.eliminados_force_order = false;
		this.objects = this.objects.select();
		this.categoria_anterior = this.categoria;
		this.orden_anterior = this.orden;
		this.search_q_anterior = this.search_q;
		this.printResult();
	},
	//Buscador
	search(q, event){
		tecla = (document.all) ? event.keyCode:event.which;
		if(tecla === 27){ //Escape, limpio input
			q = '';
			$('#favoritos-search').val('');
		}
		if(q == this.search_q) return;
		//Calcula por la busqueda anterior si tiene que hacer una busqueda parcial
		this.search_q = q;
		this.query();
	},
	search_focus(){
		$('label[for="favoritos-search"]').hide();
	},
	search_blur(){
		if(empty($('#favoritos-search').val(), true)) $('label[for="favoritos-search"]').show();
	},
	active(e){
		return true;
	},
	active2(e){
		$(e).parent().parent().children().children('span').removeClass('bg bg-opacity-1');
		$(e).addClass('bg bg-opacity-1');
	},
	icono(obj, title, alt, fav_id, action) {
		$(obj).children().attr({ src: `${global_data.img}images/${alt}.png`, title, alt });
		$(obj).parent().css('opacity', '0.5');
		$(obj).removeAttr('onclick').off('click').on('click', function(){ 
			favoritos[action](fav_id, this); 
			return false; 
		});
	},
	//Guardo los favoritos eliminados, por si quiere reactivar alguno
	eliminar(fav_id, obj){
	   $('#loading').fadeIn(250);
	   $.post(`${global_data.url}/favoritos-borrar.php`, `fav_id=${fav_id}` + gget('key'), response => {
	   	if(response.charAt(0) === '0') {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
			for(let i = 0, s = favoritos.objects.length; i < s; ++i){
				if(favoritos.objects[i]['fav_id'] == fav_id){
					favoritos.eliminados.push(favoritos.objects[i]);
					favoritos.counts[favoritos.objects[i]['categoria']]['count']--;
					favoritos.objects.splice(i, 1);
					break;
				}
			}
			for(let i = 0, s = favoritos_data.length; i < s; ++i){
				if(favoritos_data[i]['fav_id'] == fav_id){
					favoritos_data.splice(i, 1);
					break;
				}
			}
			favoritos.icono(obj, 'Reactivar', 'reactivar', fav_id, 'reactivar');
			//Actualizo la impresion de contadores
			favoritos.printCounts();
         $('#loading').fadeOut(350);
	   })
	   .fail(() => {
	   	mydialog.toast('Hubo un error al intentar procesar lo solicitado', 'danger');
         $('#loading').fadeOut(350);
	   });
	},

	reactivar(fav_id, obj){
		//Recorro los eliminados en busqueda del post_id y el fav_date
		for(let i = 0, s = this.eliminados.length; i < s; ++i){
			if(this.eliminados[i]['fav_id'] == fav_id){
				var post_id = this.eliminados[i]['post_id'];
				var fav_date = this.eliminados[i]['fecha_guardado'];
				break;
			}
		}
		if(i === s) return false; //No encontrado
      $('#loading').fadeIn(250);
      $.post(`${global_data.url}/favoritos-agregar.php`, `postid=${post_id}&reactivar=${fav_date}` + gget('key'), response => {
      	if(response.charAt(0) === '0') {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}	
			//Lo elimino de favoritos.eliminados
			for(let i = 0, s = favoritos.eliminados.length; i < s; ++i){
				if(favoritos.eliminados[i]['fav_id'] == fav_id){
					let favorito = favoritos.eliminados[i];
					favoritos.eliminados.splice(i, 1);
					break;
				}
			}
			//Incremento el conteo de la categoria
			favoritos.counts[favorito['categoria']]['count']++;
			//Cambio fav_id por el nuevo valor
			favorito['fav_id'] = fav_id = response.substring(3);
			//Lo agrego a los dos arrays
			favoritos_data.push(favorito);
			favoritos.objects.push(favorito);
			//Fuerzo el ordenamiento en el proximo query, ya que al agregarlo al final lo pierde
			favoritos.eliminados_force_order = true;
			favoritos.icono(obj, 'Borrar', 'borrar', fav_id, 'eliminar');
			//Actualizo la impresion de contadores
			favoritos.printCounts();
			$('#loading').fadeOut(350);
      })
      .fail(() => {
      	mydialog.toast('Hubo un error al intentar procesar lo solicitado', 'danger');
         $('#loading').fadeOut(350);
      });
	}
}


$(document).ready(function(){
	//Guardo el template en una variable
	favoritos.template_favorito = $('#template-result-favorito').html();
	$('#template-result-favorito').remove();

	favoritos.template_categoria = '<li id="cat___categoria__" class="d-flex justify-content-between align-items-center py-1 mb-2"><span role="button" onclick="favoritos.active(this); favoritos.categoria = \'__categoria__\'; favoritos.query(); return false;">__categoria_name__</span> <span class="count">__count__</span></li>';
	//Hago conteo inicial
	$.each(favoritos_data, function(i, favorito){
		if(favoritos.counts[favorito['categoria']]) {
			favoritos.counts[favorito['categoria']]['count']++;
		} else {
			favoritos.counts[favorito['categoria']] = {'name': favorito['categoria_name'], 'count':1};
		}
	});
	favoritos.counts = sortObject(favoritos.counts);
	//Imprimo los contadores
	favoritos.printCounts(true);
	//Query inicial
	favoritos.query(true);
});