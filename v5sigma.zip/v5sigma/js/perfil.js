'use strict';
const perfil = {
	cache: {},
	loadTab(tab) {
		$('.itemsLists li span').removeClass('bg-active').filter(`.${tab}`).addClass('bg-active');
		$('#perfil_content > div').hide();
		$('#perfil_load').show();
		perfil.cargar(tab);
	},
	// CARGAR CONTENIDO
	cargar(type) {
		let status = $(`#perfil_${type}`).attr('status');
		if (status == 'activo') {
			$('#perfil_load').hide();
			$(`#perfil_${type}`).fadeIn();
			return true;
		}
		//
		$('#loading').slideDown(250);
		let pid = $('#info').attr('pid');
		$.post(`${global_data.url}/perfil-${type}.php`, { pid }, response => {
			if (response.charAt(0) === '0') {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
			if (typeof perfil.cache[type] == 'undefined') {
				$('#perfil_content').append(response.substring(3));
				$(`#perfil_${type}`).fadeIn();
				perfil.cache[type] = true;
			}
			$('#perfil_load').hide();
			$('#loading').slideUp(350);
		});
	},
	// CARGAR PAGINAS DE LOS SEGUIDORES!
	follows(type, page) {
		let pid = $('#info').attr('pid');
		$(`#perfil_${type}`).css('opacity', .5);
		$.post(`${global_data.url}/perfil-${type}.php?hide=true&page=${page}`, { pid }, response => {
			$(`#perfil_${type}`).html(response.substring(3)).css('opacity', 1);
		});
	}
}
/** ACTIVIDAD **/
var actividad = {
	total: 25,
	show: 25,
	cargar(id, ac_do, ac_type) {
		// ELIMINAR
		$('#last-activity-view-more').remove();
		if (ac_do == 'filtrar') actividad.total = 0;
		// ENVIAMOS
		let params = toStringParams({ pid: $('#info').attr('pid'), ac_type: ac_type, do: ac_do, start: actividad.total });
		$.post(`${global_data.url}/perfil-actividad.php`, params, response => {
			let message = response.substring(3);
			if (response.charAt(0) === '0') {
				mydialog.toast(message, 'danger');
				return;
			}
			$('#last-activity-container')[(ac_do === 'more' ? 'append' : 'html')].append(message);
			let total_pubs = parseInt($('#total_acts').attr('val'));
			actividad.total = actividad.total + parseInt(total_pubs);
			$('#total_acts').remove();
		});
	},
	borrar: function(id, obj) {
		// ENVIAMOS
		$.post(`${global_data.url}/perfil-actividad.php`, { pid: $('#info').attr('pid'), acid: id, do: 'borrar' }, response => {
			let number = parseInt(response.charAt(0));
			if (number === 0) mydialog.toast(response.substring(3), 'danger');
			else if (number === 1) $(obj).parent().parent().parent().remove();
		});
	}
}

/** MURO **/
var muro = {
	maxLength: 420,
	maxWidth: 574, // WIDTH PARA LAS FOTOS Y VIDEOS
	placeholders: {
		foto: 'https://i.imgur.com/' + string_random(6) + '.png',
		enlace: global_data.url,
		video: 'https://youtube.com/watch?v=' + string_random(11)
	},
	template: {
		input: `<div class="form-input-group bg-body mb-2"><input type="text" name="input-$1" placeholder="$2"/><button role="button" onclick="muro.stream.adjuntar('$1')"><i class="fas fa-paperclip pe-none load-attr" aria-hidden="true"></i></button></div>`
	},
	extensiones: ['jpg', 'jpeg', 'png', 'gif'],
	handleError(response) {
		if(response.charAt(0) === '0') {
			mydialog.toast(response.substring(3), 'danger');
			return;
		}
	},
	stream: {
		total: 0, // TOTAL DE PUBLICACIONES CARGADAS
		show: 10, // CUANTOS SE MUESTRAN POR CADA CARGA
		type: 'status', // TIPO D PUBLICACION ACTUAL
		status: 0, // PARA EVITAR CLICKS INESESARIOS
		adjunto: '', // SE HA CARGADO UN ARCHIVO ADJUNTO?
		// CARGAR EL TIPO DE PUBLICACION :
		load(aid, obj) {
			// ACTUAL
			muro.stream.type = aid;
         let atxt = (aid === 'foto') ? 'a' : 'e';
         let newDescription = (aid === 'status') ? $('#wall').data('placeholder') : `Haz un comentario sobre est${atxt} ${muro.stream.type}...`;
         $('#wall').attr({ placeholder: newDescription });
			//
			let template = muro.template.input.replaceAll('$1', aid).replace('$2', muro.placeholders[aid]);
			$('.box-muro .input').html(aid === 'status' ? '' : template);
			// 
			return false;
		},
		// ADJUNTAR ARCHIVO EXTERNO : FOTO, ENLACE, VIDEO DE YOUTBE
		adjuntar() {
			// SI ESTA OCUPADO NO HACEMOS NADA
			if (muro.stream.status == 1) return false;
			else muro.stream.status = 1;
			// LOADER
			muro.stream.loader(true);
			// FUNCION
			const inpt = $(`input[name="input-${muro.stream.type}"]`);
			let valid = muro.stream.validar(inpt, muro.stream.type);
			if (valid === true) {
				// ADJUNTAMOS...
				muro.stream.ajaxCheck(inpt.val(), inpt);
			} else {
				mydialog.alert('Error al publicar', valid);
				// LOADER / DISABLED / STATUS
				muro.stream.loader(false);
				muro.stream.status = 0;
			}
		},
		// VERIFICAR ARCHIVO
		ajaxCheck(url, input) {
			$('#loading').fadeIn(250);
			$('#statusPost').html('Adjuntando: ' + muro.stream.type);
			if(muro.stream.type === 'video') {
				url = isYoutube(url, 'https://www.youtube.com/watch?v=');
			}
			$.post(`${global_data.url}/muro-stream.php?do=check&type=${muro.stream.type}`, { url }, response => {
				muro.handleError(response);
				muro.stream.adjunto = input.val();
				$('.input').html(response.substring(3));
				$('#statusPost').html('Adjuntado correctamente');
				$('#loading').fadeOut(350);
			})
			.done(() => {
				// LOADER/ STATUS
				muro.stream.loader(false);
				muro.stream.status = 0;
				$('#statusPost').html('');
			})
		},
		// VALIDAR LAS URL DE LOS ARCHIVOS ADJUNTOS
		validar(input, type) {
			if(imported('import/validar.js', 'isValid', { input, type })) {
				return true;
			}
		},
		// COMPARTIR
		compartir() {
			// SI ESTA OCUPADO NO HACEMOS NADA
			if (muro.stream.status === 1) return false;
			else muro.stream.status = 1;
			const valWall = $('#wall');
			const val = valWall.val();
			// LOADER
			muro.stream.loader(true);
			$('#statusPost').html('Publicacion: En espera');
			// 
			const error_length = `Las publicaciones de estado y/o comentarios deben ser inferiores a ${muro.maxLength} caracteres. Ya has ingresado`;
			// ARCHIVOS ADJUNTOS
			if (muro.stream.type != 'status') {
				if (muro.stream.adjunto != '') {
					// VALIDAR
					if (val.length > muro.maxLength) {
						mydialog.alert('Error al publicar', `${error_length} ${val.length} caracteres.`);
						// LOADER/ STATUS
						muro.stream.loader(false);
						muro.stream.status = 0;
					// ENVIAMOS PUBLICACION
					} else {
						muro.stream.ajaxPost(val || '');
					}
				} else {
					mydialog.alert('Error al publicar', 'Ingresa la <b>URL</b> en el campo de texto y a continuaci&oacute;n da clic en <b>Adjuntar</b>.');
					// LOADER/ STATUS
					muro.stream.loader(false);
					muro.stream.status = 0;
				}
				// PUBLICACION SIMPLE
			} else if (muro.stream.type == 'status') {
				var error = false;
				// VALIDAR
				if (empty(val)) {
					valWall.blur();
					error = true;
					// LOADER/ STATUS
					muro.stream.loader(false);
					muro.stream.status = 0;
					return false;
				} else if (val.length > muro.maxLength) error = `${error_length} ${val.length} caracteres.`;
				// ENVIAR PUBLICACION
				if (error == false) {
					muro.stream.ajaxPost(val);
				} else {
					mydialog.alert('Error al publicar', error);
					// LOADER/ STATUS
					muro.stream.loader(false);
					muro.stream.status = 0;
				}
			}
		},
		// POSTEAR EN EL MURO
		ajaxPost(data) {
			$('#loading').slideDown(250);
			//DETERMINAR TIPO DE PRIVACIDAD DEL SHOUT BY TO-UP
			$('#statusPost').html('Publicacion: subiendo...');
			let privacidad = $('.marcado').attr('data-value');
			let params = toStringParams({ adj: muro.stream.adjunto, data, pid: $('#info').attr('pid'), privacidad });
			$.post(`${global_data.url}/muro-stream.php?do=post&type=${muro.stream.type}`, params, response => {
				muro.handleError(response);
				let message = response.substring(3);
				// ESCONDEMOS SI ES EL PRIMER COMENTARIO
				if ($('#solouno').length === 0) $('#solouno').hide();
				//
				$('#wall-content, #news-content, #destacados-content, #populares-content, #publico-content').prepend($(message).fadeIn('slow'));
				$('#wall').val('').focus();
				muro.stream.load('status', $('#stMain'));
				$('#privami span').removeClass('marcado');
				$('#privami span[data-value="0"]').addClass('marcado');
				$('#charCount').text(`Caracteres restantes: ${muro.maxLength}`);
				$('#statusPost').html('Publicacion: Correcta');
			})
			.done(() => {
				muro.stream.loader(false);
				muro.stream.status = 0;
				$('#statusPost').html('');
				$('#loading').fadeOut(350);
			});
		},
		loadMore(type) {
			// SI ESTA OCUPADO NO HACEMOS NADA
			if (muro.stream.status == 1) return false;
			else muro.stream.status = 1;
			// LOADER
			$('.content span.active').hide();
			$('.content span.off').show();
			// CARGAMOS
			$('#loading').fadeIn(250);
			let params = toStringParams({
				pid: $('#info').attr('pid'),
				start: muro.stream.total,
				tipo: muro.stream.tipo,
				acciones: muro.stream.acciones,
				tiempos: muro.stream.tiempos
			});
			$.post(`${global_data.url}/muro-stream.php?do=more&type=${type}`, params, response => {
				muro.handleError(response);
				$(`#${type}-content`).append(response.substring(3));
				let total_pubs = $('#total_pubs').attr('val');
				total_pubs = parseInt(total_pubs);
				// 
				let msg = (type == 'news' && total_pubs < 0) ? 'Solo puedes ver los &uacute;ltimos 100 shouts.' : 'No hay m&aacute;s shouts para mostrar';
				if (total_pubs == 0 || total_pubs < muro.stream.show) $('.more-pubs').html(msg).css('color', '#000');
				else muro.stream.total = muro.stream.total + parseInt(total_pubs);
				// REMOVER
				$('#total_pubs').remove();
				$('#loading').fadeOut(250);
			}).done(() => {
				$('.content span.active').show();
				$('.content span.off').hide();
				muro.stream.status = 0;
				$('#loading').fadeOut(450);
			})
		},
		// LOADER
		loader(active) {
			$('#barca')[(active ? 'show' : 'hide')]();
		}
	},
	// LIKE
	like_this(id, type, obj) {
		imported('import/perfil.shout-like.js', 'likeShout', { id, type, obj });
	},
	show_likes(id, type) {
	   muro.stream.status = 1;
	   $('#loading').fadeIn(250);
	   $.post(`${global_data.url}/muro-likes.php?do=show`, { id, type }, response => {
	      const { status, data } = response;
	      if (status === 0) {
	         mydialog.toast(data, 'danger');
	      } else if (status === 1) {
	         let html = '<ul id="show_likes">';
	         data.forEach(user => {
	         	const { user_id, user_name } = user;
	            html += `<li><a href="${global_data.url}/perfil/${user_name}" class="d-flex justify-content-start align-items-center column-gap-2"><img src="${global_data.url}/files/avatar/${user_id}_50.jpg" class="object-fit-cover rounded overflow-hidden image image-6"/> <span>${user_name}</span></a></li>`;
	         });
	         html += '</ul>';
	         mydialog.show(true);
	         mydialog.title('Personas a las que les gusta');
	         mydialog.body(html);
	         mydialog.buttons(true, true, 'Cerrar', 'close', true, true);
	         mydialog.center();
	      }
	      $('#loading').fadeOut(350);
	   }, 'json').done(() => muro.stream.status = 0);
	},
	compartir(id) {
		const obj = { endpoint: 'compartir', comid: id, selector: `#shout_shared_${id}` };
		imported('import/perfil.shouts.js', 'phpPost', obj);
	},
	favorito(id) {
		const obj = { endpoint: 'favorito', comid: id, selector: `#shout_favourite_${id}` };
		imported('import/perfil.shouts.js', 'phpPost', obj);
	},
	actividad(id) {
		imported('import/perfil.shouts.js', 'ver_actividad', id);
	},
	show_comment_box(id) {
		$('#commentBox' + id).show();
		$('#commentTextarea' + id).focus();
		$('#activida' + id).hide();
	},
	comentar(pid) {
		const textarea = $(`#commentTextarea${pid}`);
		let data = textarea.bbcode();
		muro.stream.status = 1;
		if (empty(data)) {
			textarea.focus();
			// LOADER/ STATUS
			muro.stream.loader(false);
			muro.stream.status = 0;
			return false;
		}
		//
		$('#loading').fadeIn(250);
		$(`#carga_${pid}`).show();
		$(`#commentBox${pid}`).hide();
		$.post(`${global_data.url}/muro-stream.php?do=repost`, toStringParams({ data, pid }), response => {
			muro.handleError(response);
			textarea.bbcode('');
			$(`#commentBox${pid}, #carga_${pid}`).hide();
			$(`#shout_comment_${pid}`).total({ sumar: true });
			$('#loading').fadeOut(250);
		})
		.done(() => {
			muro.stream.status = 0;
			$('#loading').fadeOut(350);
			$(`#carga_${pid}`).hide();
		});
	},
	more_comments(pid, obj) {
		muro.stream.status = 1;
		$(obj).parent().find('img').show();
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/muro-stream.php?do=more_comments`, { pid }, response => {
			muro.handleError(response);
			$(`#commentsBox_${pid}`).html(response.substring(3));
			$('#loading').fadeOut(350);
		})
		.done(() => {
			muro.stream.status = 0;
			$('#loading').fadeOut(550);
		});
	},
	comentar_shout(pid) {
		const commentTextarea = $(`#commentTextarea${pid}`);
		let data = commentTextarea.bbcode();
		if (empty(data)) {
			commentTextarea.focus();
			muro.stream.loader(false);
			muro.stream.status = 0;
			return false;
		}
		$('#loading').fadeIn(250);

		$.post(`${global_data.url}/muro-stream.php?do=repost`, toStringParams({ data, pid }), response => {
			muro.handleError(response);
			commentTextarea.html('');
			$(`#commentsList_${pid}, #commentsBox_${pid}`).append($(response.substring(3)));
			$(`#totalComments`).total({ sumar: true, find: '' });
			$(`#shout_comment_${pid}`).total({ sumar: true });
			$('.empty').hide();
			$('#loading').fadeOut(250);
		})
		.done(() => {
			muro.stream.status = 0;
			$('#loading').fadeOut(350);
		});
	},
	// MOSTRAR VIDEO DEL MURO
	load_atta(type, ID, obj) {
		let content;
		switch (type) {
			case 'foto':
				content = `<center><img src="${ID}" style="max-width:${this.maxWidth}px;max-height:380px"/></center>`;
				break;
			case 'video':
				content = `<lite-youtube videoid="${ID}" class="rounded" style="margin:0 auto;max-width:80%;background-image: url(\'https://i.ytimg.com/vi_webp/${ID}/maxresdefault.webp\');"></lite-youtube>`;
				break;
		}
		// CARGAMOS
		$(obj).parent().html(content);
	},
	// ELIMINAR PUBLICACION / COMENTARIO
	del_pub(id, type) {
		let txtType = (type === 1) ? 'publicaci&oacute;n' : 'comentario';
		let txt =  (txtType === 1 ? 'a' : 'e');
		//
		mydialog.master({
			title: `Eliminar ${txtType}`,
			body: `¿Seguro que deseas eliminar est${txt} ${txtType}`,
			buttons: {
				good: { value: `Eliminar ${txtType}`, action: `muro.eliminar(${id}, '${type}')` }
			}
		});
	},
	handleDelete(response, id, snd_type) {
		muro.handleError(response);
		mydialog.close();
		$(`#${snd_type}_${id}`).remove();
		if (snd_type == 'cmt') {
			$(`#totalComments`).total({ restar: true, find: '' });
		}
		$('#loading').fadeOut(350);
	},
	// ELIMINAR PUBLICACION / COMENTARIO
	eliminar(id, type) {
		// LOADER / STATUS
		muro.stream.status = 1;
		let snd_type = (type === 1) ? 'pub' : 'cmt';
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/muro-stream.php?do=delete`, { id, type: snd_type }, response => muro.handleDelete(response, id, snd_type))
		.done(() => {
			muro.stream.status = 0;
			$('#loading').fadeOut(350);
		});
	},
	eliminar_abierto(id, type, nombre) {
		muro.stream.status = 1;
		let snd_type = (type === 1) ? 'pub' : 'cmt';
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/muro-stream.php?do=delete`, { id, type: snd_type }, response => {
			muro.handleDelete(response, id, snd_type);
			document.location.href = `${global_data.url}/perfil/${nombre}`;
		})
		.done(() => {
			muro.stream.status = 0;
			$('#loading').fadeOut(350);
		});
	}
}

// Gestión de privacidad en Shout
$('#fulls').on('click', function() {
	const optionsList = $(this).next();
	optionsList.is(':visible') ? $('body').click() : optionsList.show();
});

$('body').on('click', function(event) {
	if (!$(event.target).is('#fulls') && !$(event.target).closest('#privami').length) {
		$('#fulls').next().hide();
	}
});

$('#privami span').on('click', function() {
	const privacidad = $(this).closest('#privami');
	privacidad.find('span').removeClass('marcado');
	$(this).addClass('marcado');

	const priValue = parseInt($(this).data('value'));
	const iconClasses = ['fa-lock-open', 'fa-user-lock', 'fa-lock'];
	const iconElement = $('#fulls i');

	iconElement.attr('class', `fas ${iconClasses[priValue]}`);
	$('#shout').attr('data-privacidad', priValue);
});

const types = $('.box-muro .buttons > div:first-child > div');
types.each((index, element) => {
	$(element).on('click', function() {
		let type = $(this).data('type');
		$(element).removeClass('bg-opacity-1 bg-opacity-3');
		$(`[data-type="${type}"]`).toggleClass('bg-opacity-1', 'bg-opacity-3');
		muro.stream.load(type, this)
	});
});

/** READY **/
$(function() {
	const length = muro.maxLength;
	const wall = $('#wall');
	const charCount = $('#charCount');
	let totalChar = length;
	charCount.text(`Caracteres restantes: ${totalChar}`);
	wall.attr({ maxLength: length }).on('input', function(e) {
	   let currentLength = $(this).val().length;
	   let remainingChar = length - currentLength;
	   if (remainingChar < 0) {
	      $(this).val($(this).val().substring(0, length));
	      remainingChar = 0;
	   }
	   charCount.text(`Caracteres restantes: ${remainingChar}`);
	});

	$('input[name=hack]').on("focus", function() {
		$(this).hide();
		$(this).parent().find('div.formulario').show();
		let publicacion = $(this).attr('pid');
		$('#commentTextarea' + publicacion).focus()
	});
});