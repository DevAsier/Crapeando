const citar_comment = (id, nick) => imported('import/posts.citar_comentario.js', 'citar_comment', { id,nick });
const borrar_com = (...args) => imported('import/posts.borrar_comentario.js', 'borrarComentario', args);
const ocultar_com = (...args) => imported('import/posts.ocultar_comentario.js', 'ocultarComentario', args);

const borrar_post = (pid, confirmacion = 1) => imported('import/posts.borrar_post.js', 'borrarPost', { pid, confirmacion });
const votar_post = puntos => imported('import/posts.votar_post.js', 'votarPost', puntos);
const add_favoritos = () => imported('import/posts.favoritos_agregar.js', 'agregarAFavoritos');

/* COMENTARIOS */
var comentario = {
	/* VARIABLES */
	cache: {},
	cargado: false,
	/* FUNCIONES */
	cargar(postid, page, autor) {
		// GIF
		$('#com_gif').show();
		$('div#comentarios').css('opacity', 0.4)
			// COMPRVAMOS CACHE
		if (typeof comentario.cache['c_' + page] == 'undefined') {
			$('#loading').fadeIn(250);
			$.post(`${global_data.url}/comentario-ajax.php?page=${page}`, {
				postid,
				autor
			}, request => {
				comentario.cache[`c_${page}`] = request;
				$('#comentarios').html(request);
				comentario.set_pages(postid, page, autor);
				$('#loading').fadeOut(350);
			});
		} else {
			$('#comentarios').html(comentario.cache['c_' + page]);
			$('.paginadorCom').html(comentario.cache['p_' + page]);
			$('#com_gif').hide();
			$('div#comentarios').css('opacity', 1);
		}
	},
	set_pages(postid, page, autor) {
		var total = parseInt($('#ncomments').text());
		//
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/comentario-pages.php?page=${page}`, {
			postid,
			autor,
			total
		}, request => {
			comentario.cache[`p_${page}`] = request;
			$('.paginadorCom').html(request);
			$('#com_gif').hide();
			$('div#comentarios').css('opacity', 1);
			$('#loading').fadeOut(350);
		});
	},
	// NUEVO COMENTARIO
	nuevo(mostrar_resp, comentarionum) {
		// EVITAR FLOOD
		$('#btnsComment').attr({
			disabled: 'disabled'
		});
		//
		const newCommentTextarea = $('#body_comm');
		const text = newCommentTextarea.bbcode();
		// VACIO o DEFAULT
		if (text == '' || text == newCommentTextarea.attr('title')) {
			newCommentTextarea.focus();
			$('#btnsComment').removeAttr('disabled');
			return;
		} else if (text.length > 500) {
			mydialog.alert("Error", "Tu comentario no puede ser mayor a 500 caracteres.", false);
			newCommentTextarea.focus();
			$('#btnsComment').removeAttr('disabled');
			return;
		}
		// IMAGEN
		$('.miComentario #gif_cargando').show();

		const params = {
			comentario: text,
			autor: $('#auser_post').val(),
			postid: global_data.postid,
			mostrar_resp
		};
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/comentario-agregar.php`, toStringParams(params), request => {
			const reqMessage = request.substring(3);
			switch (parseInt(request.charAt(0))) {
				case 0:
					$('.miComentario .error').html(reqMessage).show();
					$('#btnsComment').removeAttr('disabled');
					break;
				case 1:
					$("#nuevos").fadeIn();
					$('#preview').remove();
					$('#nuevos').html(reqMessage).slideDown('slow', () => {
						$('#no-comments, .miComentario').hide();
						$('#avicome').show();
					});
					let nComment = parseInt($('#ncomments').text());
					$('#ncomments').html(nComment + 1);
					break;
			}
			$('#loading').fadeOut(350);
			$('.miComentario #gif_cargando').hide();
			mydialog.close();
		});
	},

	resp(id) {
		$('#' + id).removeAttr('style');
		var textarea = $('#bodys_comm_' + id);
		textarea.focus();
	},

	nuevos(mostrar_resp, comentarionum, cid) {
		// EVITAR FLOOD
		$('#btnssComment').attr({ 'disabled': 'disabled' });
		let textarea = $('#bodys_comm_' + cid);
		let comentario = textarea.val();
		let commentLength = comentario.length > 1500;
		// VACIO o DEFAULT
		if (empty(comentario) || comentario === textarea.attr('title') || commentLength) {
			if(commentLength) {
				mydialog.toast("Tu comentario no puede ser mayor a 1500 caracteres.", 'danger');
			}
			textarea.focus();
			$('#btnssComment').attr({ 'disabled': '' });
			return;
		}
		// IMAGEN
		$('.resp #gif_cargando').show();
		$('#loading').fadeIn(250);
		let params = toStringParams({
			comentario,
			postid: global_data.postid,
			mostrar_resp,
			auser: $('#ausers_post').val(),
			respuesta: $('#respuesta_' + cid).val()
		});
		$.post(`${global_data.url}/comentario-agregar.php`, params, response => {
			if(response.charAt(0) === '0') {
				$('.resp .error').html(response.substring(3)).show('slow');
				$('#btnssComment').attr({ 'disabled': '' });
				return;
			}
			$('#preview').remove();
			$('#nuevoss_' + cid).html(response.substring(3)).slideDown('slow', function() {
				$('.especial3').attr('class', 'especial1');
				$('#nuevoss_' + cid + ' .especial1 .comentario-post .comment-box');
				$('#no-comments').hide('slow');
				$('.resp').html('<div class="empty bg bg-opacity-1 rounded m-2">Tu comentario fue agregado correctamente </div>');
			});
			// SUMAMOS
			$(`#ncomments`).total({ sumar: true, find: '' });
		})
		.always(() => {
			$('#loading').fadeOut(350);
			$('.resp #gif_cargando').hide();
		});
	},
	// VOTAR COMENTARIO
	votar(cid, voto) {
		let voto_tag = $('#votos_total_' + cid)
		let total_votos = parseInt(voto_tag.text());
		total_votos = (isNaN(total_votos)) ? 0 : total_votos;
		// FIX
		voto = (voto === 1) ? 1 : -1;
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/comentario-votar.php`, { voto, cid, postid: global_data.postid }, response => {
			if(response.charAt(0) === '0') {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
			total_votos = parseInt(total_votos + voto);
			if (total_votos > 0) total_votos = '+' + total_votos; // PONEMOS EL SIGNO + POR ESTETICA :P
			let klass = (total_votos < 0) ? 'negativo' : 'positivo'; // CLASS
			// MOSTRAMOS SI NO ES VISIBLE Y AGREGAMOS LA NUEVA CLASS
			$('#ul_cmt_' + cid + ' > .numbersvotes').show();
			voto_tag.text(total_votos).removeClass('positivo, negativo').addClass(klass);
			// ESCONDEMOS LAS MANITAS xd
			$('#ul_cmt_' + cid).find('.icon-thumb-up, .icon-thumb-down').hide();
			$('#loading').fadeOut(350);
		});
	},
	// CITAR
	citar: function(id, nick) {
		var textarea = $('#body_comm');
		textarea.focus();
		textarea.val(((textarea.val() != '') ? textarea.val() + '\n' : '') + '[quote=' + nick + ']' + htmlspecialchars_decode($('#citar_comm_' + id).html(), 'ENT_NOQUOTES') + '[/quote]\n');
	},
	// EDITAR
	editar(id, step) {
		switch (step) {
			case 'show':
				let bbcode = htmlspecialchars_decode($('#citar_comm_' + id).html(), 'ENT_NOQUOTES');
				$('#comment-body-' + id).html(`<textarea id="edit-comment-${id}" class="textarea-edit" placeholder="Escribir un comentario...">${bbcode}</textarea><input type="button" class="button" onclick="comentario.editar(${id}, 'send')" value="Continuar"/> <strong id="edit-error-${id}"></strong>`);
				$('#edit-comment-' + id).css({ 'max-height': '300px', 'min-height': '40px' }).select();
			break;
			case 'send':
				$('#loading').fadeIn(250);
				let comentario = $('#edit-comment-' + id).val();
				let params = toStringParams({
					comentario,
					cid: id
				});
				$.post(`${global_data.url}/comentario-editar.php`, params, response => {
					if(response.charAt(0) === '0') {
						$('#edit-error-' + id).css('color', 'red').html(response.substring(3));
						return;
					}
					mydialog.toast('Comentario editado...');
					setTimeout(() => location.reload(), 4000);
					$('#loading').fadeOut(350);
				});
			break;
		}
	}
}

/* extras */
function emoticones() {
	var winpops = window.open(global_data.url + "/emoticones.php", "", "width=180px,height=500px,scrollbars,resizable");
}

/* EMOTICONOS */
function moreEmoticons(margin) {
	var emos = $('#emoticons');
	$('#loading').fadeIn(250);
	$.get(`${global_data.url}/emoticones.php`, 'ts=false', response => {
		if (margin) $(emos).css({ marginTop: '1em' })
		$(emos).append(response);
		$('#moreemofn').hide();
		$('#loading').fadeOut(350);
	});
}

//Editor de posts comentarios
if ($('#body_comm, #body_resp').length && !$('.wysibb-texarea').length) {
	const wbbOpt = {
		buttons: "smilebox,gif,|,bold,italic,underline,strike,sup,sub,|,img,video,link"
	}
	$('#body_comm, #body_resp').removeAttr('onblur onfocus class style title').css('height', '80').html('').wysibb(wbbOpt);
}

crapeandoShared.start('.share-post', {
	styles: {
		size: '2.5rem',
		font: '1.5rem'
	}
});

function loadSmiles() {
	$.post(`${global_data.url}/emoticones-load.php`, {}, req => {
		$('#emoticons').html(req);
		let cookie = getCookie('emoticons');
		if (cookie) {
			items = cookie.split(/,/);
			for (let i = 0; i <= items.length; i++) {
				$('#emoticons .e_container a[data-code="' + items[i] + '"]').clone().prependTo("#emoticons .e_container .ec_tab_0");
			};
		}
	});
}
$(document).ready(() => {
	if ($('pre > code').length > 0) {
	   Prism.highlightAll();
	}
});