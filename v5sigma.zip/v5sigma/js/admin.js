function showConfirmationDialog(title, body, action, value = '') {
   mydialog.master({
      title: title,
      body: body,
      buttons: { good: { value: (empty(value) ? 'S&iacute;' : value), action: action} }
   });
}

var admin = {
	__postAction(urlPath, params, element) {
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/${urlPath}.php`, params, response => {
			admin.updateStatus(response, element);
			$('#loading').fadeOut(250);
		});
	},
	__postOpenClose(urlPath, params, obj, element) {
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/${urlPath}.php`, params, response => {
			let number = parseInt(response.charAt(0));
			if(response.charAt(0) === 0) {
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
			$(element).html(`<font color="${obj[number].color}">${obj[number].text}</font>`);
			$('#loading').fadeOut(350);
		});
	},
	handleResponse(response, element) {
		mydialog.toast(response.substring(3), (response.charAt(0) === '0' ? 'danger' : 'success'));
		if (response.charAt(0) === '1') $(element).fadeOut().remove();
		$('#loading').fadeOut(350);
	},
	updateStatus(response, element) {
		if(response.charAt(0) === '0') {
			mydialog.toast(response.substring(3), 'danger');
			return;
		}
		let msg = (response.charAt(0) === '1') ? 'Activo' : 'Inactivo';
		let msgColor = (response.charAt(0) === '1') ? 'green' : 'purple';
		$(element).html(`<font color="${msgColor}">${msg}</font>`);
	},
	afs: {
		borrar(afid, gew) {
			if (!gew) {
				showConfirmationDialog('Borrar Afiliado', '&#191;Quiere borrar este afiliado?', `admin.afs.borrar(${afid}, 1)`);
				return;
			} 
			$('#loading').fadeIn(250);
			$.post(global_data.url + '/afiliado-borrar.php', { afid }, response => {
				admin.handleResponse(response, '#few_' + afid);
			});
		},
		accion(aid) {
			admin.__postAction('afiliado-setactive', { aid }, '#status_afiliado_' + aid);
		}
	},
	news: {
		accion(nid) {
			admin.__postAction('admin-noticias-setInActive', { nid }, '#status_noticia_' + nid);
		},
	},
	nicks: {
		accion(nid, accion, gew) {
			if (!gew) {
				let title = (accion === 'aprobar') ? 'Aprobar Cambio' : 'Denegar Cambio';
				let body = (accion === 'aprobar') ? '&#191;Quiere aprobar el cambio?' : '&#191;Quiere denegar el cambio?';
				showConfirmationDialog(title, body, `admin.nicks.accion(${nid}, '${accion}', 1)`);
				return;
			}
			admin.__postAction('admin-nicks-change', { nid, accion }, '#nick_' + nid);
		}
	},
	sesiones: {
		borrar(sid, gew) {
			if (!gew) {
				showConfirmationDialog('Cerrar sesi&oacute;n', '&#191;Quiere cerrar la sesi&oacute;n de este usuario/visitante? Se borrar&aacute; la sesi&oacute;n', `admin.sesiones.borrar(${sid}, 1)`);
				return;
			}
			admin.__postAction('admin-sesiones-borrar', { sid }, '#sesion_' + sid);			
		}
	},
	posts: {
		borrar(pid, gew) {
			if (!gew) {
				showConfirmationDialog('Borrar Post', '&#191;Quiere borrar este post permanentemente?', `admin.posts.borrar(${pid}, 1)`);
				return;
			}
			admin.__postAction('posts-admin-borrar', { pid }, '#post_' + pid);
		}
	},
	blacklist: {
		borrar(bid, gew) {
			if (!gew) {
				showConfirmationDialog('Retirar Bloqueo', '&#191;Quiere retirar este bloqueo?', `admin.blacklist.borrar(${bid}, 1)`);
				return;
			}
			admin.__postAction('admin-blacklist-delete', { bid }, '#block_' + bid);
		}
	},
	badwords: {
		borrar(wid, gew) {
			if (!gew) {
				showConfirmationDialog('Retirar Filtro', '&#191;Quiere retirar este filtro?', `admin.badwords.borrar(${wid}, 1)`);
				return;
			}
			admin.__postAction('admin-badwords-delete', { wid }, '#wid_' + wid);
		}
	},
	fotos: {
		borrar(foto_id, gew) {
			if (!gew) {
				showConfirmationDialog('Borrar Foto', '&#191;Quiere borrar esta foto permanentemente?', `admin.fotos.borrar(${foto_id}, 1)`);
				return;
			}
			admin.__postAction('admin-foto-borrar', { foto_id }, '#foto_' + wid);
		},
		setOpenClosed(fid) {
			const __states = {
				1: { color: 'red', text: 'Cerrados' },
				2: { color: 'green', text: 'Abiertos' }
			}
			admin.__postOpenClose('admin-foto-setOpenClosed', { fid }, __states, '#comments_foto_' + fid);
		},
		setShowHide(fid) {
			const __states = {
				1: { color: 'purple', text: 'Ocultar' },
				2: { color: 'green', text: 'Visible' }
			}
			admin.__postOpenClose('admin-foto-setShowHide', { fid }, __states, '#status_foto_' + fid);
		}
	},
	medallas: {
		borrar(medal_id, gew) {
			if (!gew || gew === 2) {
				let act = (gew === 2) ? 3 : 2;
				let body = (gew === 2) ? 'Si borra la medalla, los usuarios que tengan esta medalla la perder&aacute;n, &#191;seguro que quiere continuar?' : '&#191;Quiere borrar esta medalla?';
				showConfirmationDialog('Borrar Medalla', '&#191;Quiere borrar esta foto permanentemente?', `admin.medallas.borrar(${medal_id}, ${act})`);
				return;
			}
			admin.__postAction('posts-medalla-borrar', { medal_id }, '#medal_id_' + medal_id);
		},
		borrar_asignacion(aid, mid, gew) {
			if (!gew) {
				showConfirmationDialog('Borrar Asignacion', '&#191;Quiere continuar borrando esta asignaci&oacute;n?', `admin.medallas.borrar_asignacion(${aid}, ${mid}, 1)`);
				return;
			}
			admin.__postAction('posts-medalla-borrar-asignacion', { aid, mid }, '#assign_id_' + aid);
		},
		asignar(mid, gew) {
			if (!gew) {
				const form = `<div style="padding:5px 35px;" id="AFormInputs">
					<div class="form-group">
						<label class="form-label" for="m_usuario">Al usuario (nombre):</label>
						<input name="m_usuario" id="m_usuario"/>
					</div>
					<div class="form-group">
						<label class="form-label" for="m_post">Al post (id):</label>
						<input name="m_post" id="m_post"/>
					</div>
					<div class="form-group">
						<label class="form-label" for="m_foto">A la foto (id):</label>
						<input name="m_foto" id="m_foto"/>
					</div>
				</div>`;
				showConfirmationDialog('Asignar medalla', form, `admin.medallas.asignar(${mid}, 1)`, 'Asignar');
				return;
			}
			let m_usuario = $('#m_usuario').val();
			let pid = $('#m_post').val();
			let fid = $('#m_foto').val();
			$('#loading').fadeIn(250);
			$.post(`${global_data.url}/admin-medalla-asignar.php`, { mid, m_usuario, pid, fid }, response => {
				mydialog.toast(response.substring(3), (response.charAt(0) == '0' ? 'danger' : 'success'));
				if (response.charAt(0) === '1') {
					const element = $(`#total_med_assig_${mid}`);
					element.text(parseInt(element.text()) + 1);
					$('#loading').fadeOut(350);
				}
			});
		}
	},
	mp: {
		borrar(mp, gew) {
			if (!gew) {
				showConfirmationDialog('Borrar Mensaje', '&#191;Quieres borrar el mensaje completo?', `admin.mp.borrar(${mp}, 1)`);
				return;
			}
			admin.__postAction('admin-mensajes-borrar', { mp }, '#mp_' + mp_id);
		}
	},
	rmp: {
		borrar(rmp, gew) {
			if (!gew) {
				showConfirmationDialog('Borrar Respuesta', '&#191;Quiere borrar la respuesta?', `adminrmp.borrar(${rmp}, 1)`);
				return;
			}
			admin.__postAction('admin-respuestas-borrar', { rmp }, '#rmp_' + rmp);
		}
	},
	users: {
		setInActive(uid) {
			const __states = {
				1: { color: 'green', text: 'Activo' },
				2: { color: 'purple', text: 'Inactivo' }
			}
			admin.__postOpenClose('admin-users-InActivo', { uid }, __states, '#status_user_' + uid);
		}
	}
}

/* AFILIADOS */
var ad_afiliado = {
	cache: {},
	detalles(ref) {
		$.post(`${global_data.url}/afiliado-detalles.php`, { ref }, response => {
			mydialog.master({
				title: 'Detalles de afiliado',
				body: response
			})
		});
	}
}