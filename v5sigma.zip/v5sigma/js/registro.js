'use strict';
let allFields = $(".registro .form-group input");
// Verificamos
let config_inputs = {
	nick: {
		status: false,
		pattern: /^[a-zA-Z0-9\_\-]{4,20}$/
	},
	password: {
		status: false,
		pattern: /^.{4,32}$/
	},
	email: {
		status: false,
		pattern: /^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/
	},
	nacimiento: {
		status: false,
		pattern: /^\d{4}-\d{2}-\d{2}$/
	},
	sexo: {
		status: false,
		pattern: /^[mfMF01]{1}$/
	},
	pais: {
		status: false,
		pattern: /^[a-zA-Z]{2}$/
	},
	estado: {
		status: false,
		pattern: /^\d{1,3}$/
	}
}

function helperMsg({ element: field, message, type }) {
	const statusColor = ['error', 'success', 'loading', 'info'];
	let add = statusColor[type];
	$(`#group-${field} .helper`).html(message).removeClass('error success loading info').addClass(add);
	return (type === 1);
}

function getField(element, request) {
	let text = $(`#group-${element} input`).val();
	if(text === undefined) {
		text = $(`#${element} option:selected`).val();
	}
	let prop = (element === 'password2') ? 'password' : element;
	let usePattern = config_inputs[prop].pattern.test(text);
	return usePattern ? helperMsg({ element, message: request.substring(3), type: parseInt(request.charAt(0)) }) : false;
}

function sonTodosVerdaderos(obj) {
   for (var prop in obj) {
      if (obj.hasOwnProperty(prop) && !obj[prop].status) {
         return false;
      }
   }
   return true;
}

function verifyNick(element) {
	const { value: nickValue, name: nickName } = element;
	let countn = parseInt(nickValue.length);
	if(countn <= 4) {
		helperMsg({ element: 'nick', message: `Debes ser mayor a 4 caracteres`, type: 3 });
	} else if(nickName === 'nick' && countn >= 20) {
		helperMsg({ element: 'nick', message: `Debes ser menor a 20 caracteres`, type: 3 });
	} else {
		helperMsg({ element: 'nick', message: `Comprobando nick...`, type: 2 });
	}
	$.post(`${global_data.url}/registro-check-nick.php?ajax=true`, { nick: nickValue }).then(response => {
		config_inputs['nick'].status = getField('nick', response);
	});	
}

function verifyPassword() {
	let passValue = $('#password').val();
	let compare = passValue === $('#nick').val();
	helperMsg({ element: 'password', message: `Comprobando contraseña...`, type: 2 });
	if(compare) {
		helperMsg({ element: 'password', message: 'No puede ser igual al Nick', type: 0 });
	} else {
		config_inputs['password'].status = getField('password', '1: Ok')
	}
}

function verifyEmail() {
	let emailValue = $('#email').val();
	helperMsg({ element: 'email', message: `Comprobandoemail...`, type: 2 });
	$.post(`${global_data.url}/registro-check-email.php?ajax=true`, { email: emailValue }).then(response => {
		config_inputs['email'].status = getField('email', response);
	});
}

function verifyNacimiento() {
   const newDate = new Date($('#nacimiento').val());
   const today = new Date();
   
   const minYear = today.getFullYear() - 90;
   const maxYear = today.getFullYear() - 16;

	helperMsg({ element: 'nacimiento', message: `Comprobando nacimiento..`, type: 2 });
   if (newDate.getFullYear() > today.getFullYear()) {
      helperMsg({ element: 'nacimiento', message: `La fecha no puede ser en el futuro`, type: 0 });
   } else if (newDate.getFullYear() < minYear) {
      helperMsg({ element: 'nacimiento', message: `No puedes ser tan viejo!`, type: 0 });
   } else if (newDate.getFullYear() > maxYear) {
     	helperMsg({ element: 'nacimiento', message: `Debes ser mayor de 16 años`, type: 0 });
   } else {
      config_inputs['nacimiento'].status = getField('nacimiento', '1: Fecha válida!');
   }
}

function verifySexo() {
	helperMsg({ element: 'sexo', message: `Comprobando sexo..`, type: 2 });
}

function verifyPaisEstado(field, message) {
	helperMsg({ element: field, message: `Comprobando ${field}..`, type: 2 });
	config_inputs[field].status = getField(field, message);
}

let verificar = (field) => {
	const { target: element } = field;
	switch (element.name) {
		case 'nick': verifyNick(element); break;
		case 'password': verifyPassword(); break;
		case 'email': verifyEmail(); break;
		case 'nacimiento': verifyNacimiento(); break;
		case 'sexo': 
			verifySexo();
			config_inputs['sexo'].status = getField('sexo', '1: OK');
		break;
	}
}

function replaceParams() {
	// Serializamos el formulario
	let datosFormulario = $('.registro form').serialize();
	let datosArray = datosFormulario.split('&');
	let datosProcesados = {};
	datosArray.forEach(function(par) {
	   let [clave, valor] = par.split('=');
	   if (clave === 'nacimiento') {
	      let [anio, mes, dia] = valor.split('-');
	      datosProcesados['dia'] = dia;
	      datosProcesados['mes'] = mes;
	      datosProcesados['anio'] = anio;
	   } else if(clave === 'email') {
	   	datosProcesados[clave] = decodeURIComponent(valor);
	   } else datosProcesados[clave] = valor;   
	});
	return $.param(datosProcesados);
}

function loading(start = true) {
	$('#reCaptchaNext').val((start ? 'Creando su cuenta...Espere' : 'Crear cuenta'))[start ? 'addClass' : 'removeClass']('loading');
}

function terminar(action) {
	window.location.href = global_data.url + (action === 1 ? '/' : '/cuenta/');
}

function crearCuenta() {
	loading();
	if(sonTodosVerdaderos(config_inputs)) {
		let nuevaCadena = replaceParams();
		$.post(`${global_data.url}/registro-nuevo.php`, nuevaCadena, request => {
			let numberAction = parseInt(request.charAt(0));
			let messageAction = request.substring(3);
			if(numberAction === 0) {
				mydialog.alert('Error', messageAction, false);
				loading(false);
			}
			if(numberAction === 1 || numberAction === 2) {
				mydialog.master({
					title: 'Cuenta creada',
					body: messageAction,
					buttons: {
						good: {
							action: terminar(numberAction)
						}
					}
				});
			}
		})
	} else loading(false);
}

allFields.on('blur keyup', verificar);

const changeStatus = bool => $('#reCaptchaNext').prop('disabled', bool);
function onReCaptchaSuccess() { 
	changeStatus(false);
}
function onReCaptchaExpired() { 
	changeStatus(true);
}

$(document).ready(() => {
	changeStatus(true);
	$('.password-toggle').on('click', function() {
		$('.password-toggle i').toggleClass('fa-eye fa-eye-slash');
		$('#password').attr('type', $('#password').attr('type') === 'password' ? 'text' : 'password');
	});

	$('#pais').on('change', () => {
		let pais_code = $('#pais option:selected').val();
		verifyPaisEstado('pais', (pais_code === '' ? '0: Seleccione un país' : '1: OK'));
		$('#estado').html('').append('<option value="" selected="selected">Regi&oacute;n</option>');
		helperMsg({ element: 'estado', message: `Cargando estados...`, type: 2 });
		$.get(`${global_data.url}/registro-geo.php`, { pais_code }, request => {
			$('#estado').append(request.substring(3)).removeAttr('disabled').val('').focus();
			helperMsg({ element: 'estado', message: `Seleccione un estado...`, type: 2 });
		})
	});

	$('#estado').on('change', () => {
		let estado = $('#estado option:selected').val();
		verifyPaisEstado('estado', (estado === '' ? '0: Seleccione un estado' : '1: OK'));
	});

	$('form').submit(function(e) {
	   e.preventDefault();
	   crearCuenta();
	});
});