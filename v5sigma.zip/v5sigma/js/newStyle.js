const newFeatureTitle = `<h2>¡Hemos renovado nuestra apariencia! 🎉</h2>`;
const newFeatureContent = `<p class="d-block py-1">Ahora podrás disfrutar de una experiencia visual fresca y moderna con nuevas características:</p><p>🌞 <strong>Modo Light/Dark</strong>: Alterna entre un diseño claro y oscuro según tu preferencia.</p><p>📱 <strong>Responsive</strong>: Nuestra interfaz se adapta automáticamente a cualquier dispositivo, para que tengas la mejor experiencia, ya sea en móvil, tablet o computadora.</p><p>♿ <strong>Accesibilidad mejorada</strong>: Nos hemos asegurado de que nuestra plataforma sea más inclusiva y fácil de usar para todos.</p><p>🎨 <strong>Amplia paleta de colores</strong>: Explora nuevas opciones de personalización de color y encuentra el estilo que mejor se adapte a ti.</p><br><p class="d-block text-center py-2">¡Esperamos que disfrutes esta actualización tanto como nosotros al crearla! 😊</p>`;

let newFeatureName = 'feature-update';
let featureExists = localStorage.getItem(newFeatureName);

if (featureExists === false || featureExists === null) {
	function toAccount() {
		window.location.href = global_data.url + '/cuenta/';
	}
	mydialog.master({
		title: newFeatureTitle,
		body: newFeatureContent,
		buttons: {
			good: {
				value: 'Ir a cuenta',
				action: 'toAccount()'
			}
		}
	})
   localStorage.setItem(newFeatureName, true);
}