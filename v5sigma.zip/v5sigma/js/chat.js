﻿'use strict';
var chat = {
	msgs: 0,
	scrollBottom: true,
	loading: '<img src="'+ global_data.img +'images/cargando.gif" class="center">',
	emotes: {
		find: [":)", ":D", ";)", ":O", "(H)", ":P", "8o|", ":S", ":$", ":(", ":'(", ":|", "(6)", "8-|", ":-/", "^o)", "(A)", ":[", ":-#", ":-*", "+o(", "(brb)", ":^)", "*-)", "<o)", "8-)", "|-)", ";-/", "(jk)", "(j)", "(V)", "(lol)", "(xD)", ":8)", "(ff)", "(fm)", ":'|", ":]", ":}", "(BOO)", "*|", "(wm)", "(xo)", "(l)", "(u)", "(@)", "(&)", "(S)", "(*)", "(~)", "(8)", "(E)", "(F)", "(W)", "(O)", "(K)", "(G)", "(^)", "(P)", "(I)", "(C)", "(T)", "({)", "(})", "(B)", "(D)", "(Z)", "(X)", "(Y)", "(N)", "(nnh)", "(#)", "(R)", "(sn)", "(tu)", "(pl)", "(||)", "(pi)", "(so)", "(au)", "(ap)", "(um)", "(ip)", "(co)", "(mp)", "(st)", "(pu)", "(yn)", "(h5)", "(mo)", "(bah)", "(li)", "(wo)", "(bus)", "*p*", "*s*", "(M)", "(xx)"],
		replace: ["[emote=001.png]", "[emote=002.png]", "[emote=003.gif]", "[emote=004.png]", "[emote=006.png]", "[emote=104.png]", "[emote=049.png]", "[emote=009.png]", "[emote=008.png]", "[emote=010.png]", "[emote=011.gif]", "[emote=012.png]", "[emote=013.png]", "[emote=050.png]", "[emote=083.png]", "[emote=051.png]", "[emote=014.png]", "[emote=043.png]", "[emote=048.png]", "[emote=052.png]", "[emote=053.png]", "[emote=066.gif]", "[emote=072.gif]", "[emote=073.gif]", "[emote=075.gif]", "[emote=076.gif]", "[emote=078.gif]", "[emote=082.png]", "[emote=084.png]", "[emote=086.png]", "[emote=087.png]", "[emote=089.gif]", "[emote=090.png]", "[emote=088.png]", "[emote=091.gif]", "[emote=092.gif]", "[emote=093.gif]", "[emote=094.gif]", "[emote=095.png]", "[emote=096.png]", "[emote=097.gif]", "[emote=100.png]", "[emote=101.gif]", "[emote=015.png]", "[emote=016.png]", "[emote=018.png]", "[emote=019.png]", "[emote=020.png]", "[emote=021.png]", "[emote=022.png]", "[emote=023.png]", "[emote=024.png]", "[emote=025.png]", "[emote=026.png]", "[emote=027.gif]", "[emote=028.png]", "[emote=029.png]", "[emote=030.png]", "[emote=031.png]", "[emote=032.png]", "[emote=033.png]", "[emote=034.png]", "[emote=035.png]", "[emote=036.png]", "[emote=037.png]", "[emote=038.png]", "[emote=039.png]", "[emote=040.png]", "[emote=041.png]", "[emote=042.png]", "[emote=044.png]", "[emote=046.png]", "[emote=047.png]", "[emote=054.png]", "[emote=055.png]", "[emote=056.png]", "[emote=057.png]", "[emote=058.png]", "[emote=059.png]", "[emote=060.png]", "[emote=061.png]", "[emote=062.png]", "[emote=063.png]", "[emote=064.png]", "[emote=065.png]", "[emote=067.png]", "[emote=102.png]", "[emote=068.png]", "[emote=069.gif]", "[emote=070.png]", "[emote=071.png]", "[emote=074.gif]", "[emote=077.png]", "[emote=045.png]", "[emote=079.png]", "[emote=085.png]", "[emote=017.png]", "[emote=103.png]"],
	},
	empty() {
		$('.chat_msgs').html('<h3 style="position: absolute; display: block; width: 180px; height: 30px; margin: auto; bottom: 0; top: 0; left: 0; right: 0;">¡No hay mensajes!</h3>');
	},
	help() {
		mydialog.master({
			title: 'Ayuda',
			body: '<div class="docs"><p>Escribe un mensaje en la caja de texto y pulsa <kbd>Enter</kbd> para enviarlo.</p><h3>Usuario</h3><p>El color del nick es aleatorio y no es posible cambiarlo, los moderadores<br>son los mismos que en el resto de la web.</p><h3>BBCodes</h3><p>Puedes usar los siguientes bbcodes:</p></div><code>[b], [i], [u], [br], [url], [color]</code><p>(las imágenes y los enlaces se convertirán automáticamene)</p>'
		});
	},
	send() {
		const chatAviso = $('.chat_aviso');
		let text = $('.chat_text');
		let message = text.val().trim();
		if(message) {
			text.val('').attr('disabled', 'disabled');
			$.getJSON(global_data.url+'/chat-send.php', { message }).done(function(data) {
				text.removeAttr('disabled');
				if(data.error) {
					chatAviso.html(data.message).slideDown('fast');
					text.val(message);
				} else {
					chatAviso.slideUp('fast');
					chat.load();
				}
				text.focus();
			});
		} else chatAviso.html('Escribe un mensaje.').slideDown('fast');
	},
	parseMessage: function(str) {
		var result = '';
		str = str.replaceArray(chat.emotes.find, chat.emotes.replace);
		str = str.replace(/\[br\]/gi, '<br>'),
		str = str.replace(/\[i\](.+?)\[\/i]/gi, '<i>$1</i>'),
		str = str.replace(/\[b\](.+?)\[\/b]/gi, '<b>$1</b>'),
		str = str.replace(/\[u\](.+?)\[\/u\]/gi, '<u>$1</u>'),
		str = str.replace(/\[url\](.+?)\[\/url\]/gi, '<a href="$1" target="_blank">$1</a>'),
		str = str.replace(/\[url=(.+?)\](.+?)\[\/url\]/gi, '<a href="$1" target="_blank">$2</a>'),
		str = str.replace(/\[color=(.+?)\](.+?)\[\/color\]/gi, '<span style="color: $1">$2</span>'),
		str = str.replace(/\[emote=(.+?)\]/gi, '<img src="'+global_data.img+'images/icons/smiles/$1">');
		str = str.split(' ');
		
		$.each(str, function(key, val) {
		   val = val.trim();
		   var ext = val.slice(-4).toLowerCase();
		   var isImage = ext === '.png' || ext === '.jpg' || ext === '.gif';
		   var isLink = val.startsWith('http://') || val.startsWith('https://') || val.startsWith('www.');
		   if (isImage && isLink) {
		      val = `<a href="${val}" target="_blank"><img src="${val}" class="chat_img" alt></a>`;
		   } else if (isLink) {
		      val = `<a href="${val}" target="_blank">${val}</a>`;
		   }
		   result += ' ' + val;
		});
		return result;
	},
	admod() {
		$('.btn_more').toggleClass('active');
		var pos = $('.btn_more').position(), x = pos.left, y = pos.top;
		$('.admod_menu').css({'top': y + 45, 'left': x - ($('.admod_menu').width() - 50)}).slideToggle();
	},
	showEmotes() {
		$('.chat_emotes').slideToggle();
		$('#toggleEmotes').toggleClass('btn_arrow_down');
		if($.trim($('.container-1').html()) !== '') chat.changeEmotes(1);
		else chat.changeEmotes(2);
	},
	changeEmotes(tab) {
		$('.emotes_container div').hide();
		$('.tabs button').removeClass('active');
		$(`.tab-${tab}`).addClass('active');
		let emotes = $('.container-'+tab);
		if(!emotes.attr('load')) {
			if(tab === 2) {
				for (let i = 0; i < chat.emotes.find.length; i++) {
					let find = chat.emotes.find[i];
					let replace = chat.emotes.replace[i].replace(/\[emote=(.+?)\]/gi, '$1');
					emotes.append(`<img src="${global_data.img}images/icons/smiles/${replace}" onclick="chat.addEmote(this)" alt="${find}" class="chat_img">`);
				}
			} else if(tab === 3) {
				emotes.load(global_data.url+'/chat-emotes.php');
			}
			emotes.attr('load', true);
		}
		emotes.show();
	},
	addEmote(obj) {
		let message = $('.chat_text').val();
		let emote = $(obj).attr('alt');
		$('.chat_text').val(`${message} ${emote}`);
		$('.container-1 img').each(function() { 
			if($(this).attr('alt') === emote) $(this).remove(); 
		});
		let src = $(obj).attr('src');
		$('.container-1').prepend(`<img src="${src}" onclick="chat.addEmote(this)" alt="${emote}" class="chat_img">`);
	},
	addBadWord(submit) {
		if(!submit) {
			mydialog.master({
				title: 'Agregar censura/emoticono',
				body: '<form class="badword_form"><table class="chat_table" cellspacing="0"><tbody><tr><td>Tipo</td><td><input name="type" type="radio" value="0" checked>Censura <input name="type" type="radio" value="1"> Emoticono</td></tr><tr><td>Método</td><td><input name="method" type="radio" value="0" checked>Parcial <input name="method" type="radio" value="1"> Exacto</td></tr><tr><td>Antes</td><td><input type="text" name="word" placeholder="-yao" style="margin: 0;"></td></tr><tr><td>Después</td><td><input type="text" name="swop" placeholder="http://i.imgur.com/yaoming.png" style="margin: 0;"></td></tr></tbody></table></form>',
				buttons: { good: { value: 'Agregar', action: 'chat.addBadWord(true)' }}
			});
		} else {
			$.getJSON(global_data.url+'/chat-badword.php', $('.badword_form').serialize()).done(function(data) {
				mydialog.body(data.message);
				mydialog.buttons(true, true, 'Aceptar', 'close', true);
				mydialog.center();
				$('.container-3').removeAttr('load');
				chat.changeEmotes(3);
			});
		}
	},
	delAlert(id, user) {
		mydialog.master({
			title: '¿Cómo quieres eliminar el/los mensaje(s)?',
			body: '<center>Cargando...</center>',
			buttons: { 
				good: { value: 'Solo este', action: `chat.delete(${id}, 'byMsg')`},
				fail: { value: 'Todos del usuario', action: `chat.delete(${user}, 'byUser')`}
			}
		});
	},
	delete(id, type) {
		$.getJSON(global_data.url+'/chat-delete.php', { id, type }).done(function(data) {
			mydialog.close();
			chat.load();
		});
	},
	banAlert(user = '', type = '') {
		$('.btn_more').removeClass('active');
		$('.admod_menu').hide();
		let time = new Date();
		let form = `<form class="ban_form"><input type="hidden" name="type" value="${type}">`
		form += user ? `<input type="hidden" name="user" value="${user}">` : '<p><strong>Nick</strong> del usuario:<input type="text" name="user" class="mb-3"></p>';
		let year = time.getFullYear();
		form += `Selecciona hasta cuando estará baneado:<div class="d-flex justify-content-start align-items-start column-gap-2"><input type="number" name="day" value="${time.getDate()}" style="width: 42px;" title="Día" min="1" max="31"> /<input type="number" name="month" value="${time.getMonth() + 1}" style="width: 42px;" title="Mes" min="1" max="12"> /<input type="number" name="year" value="${year}" style="width: 60px;" title="Año" min="${year}" max="${year + 10}">, <input type="number" name="hour" value="${time.getHours() + 1}" style="width: 42px;" title="Hora" min="0" max="23"> :<input type="number" name="minute" value="${time.getMinutes()}" style="width: 42px;" title="Minuto" min="0" max="59"></div></form>`;
		mydialog.master({
			title: 'Banear usuario',
			body: form,
			buttons: { good: { value: 'Banear', action: `chat.ban()` } }
		});
	},
	userband(params) {
		mydialog.procesando_inicio();
		$.getJSON(global_data.url+'/chat-ban.php', params, function(data) {
			mydialog.body(data.message);
			mydialog.buttons(true, true, 'Aceptar', 'close', true);
			mydialog.procesando_fin();
		});
	},
	ban() {
		chat.userband($('.ban_form').serialize());
	},
	unban(user) {
		chat.userband({ user: user, type: 'delete' });
	},
	seeList(title, page) {
		mydialog.master({
			title: 'Usuarios ' + title,
			body: '<center>Cargando...</center>',
			buttons: { display_all: false }
		});
		$('#modalBody').load(global_data.url+'/chat-'+page+'.php');
	},
	banList() {
		$('.btn_more').removeClass('active');
		$('.admod_menu').hide();
		chat.seeList('baneados', 'banlist');
	},
	online() {
		chat.seeList('online', 'online');
	},
	check() {
		$.getJSON(global_data.url+'/chat-count.php', function(data){
			if(data.count !== 0) {
				if(chat.msgs !== data.count) { 
					chat.msgs = data.count; 
					chat.load();
				}
				return;
			}
			chat.empty();
		});
	},
	load() {
		$('.chat_msgs').load(global_data.url+'/chat-load.php', function(data) {
			if(chat.scrollBottom) $('.chat_msgs').scrollTop($('.chat_msgs ul').outerHeight(true));
			chat.collect();
		});
	},
	collect() {
		$($('.chat_msgs ul li').get().reverse()).each(function() {
			$(this).find('.msg_line').html(chat.parseMessage($(this).find('.msg_line').html()));
			let attrUid = $(this).attr('uid');
			let nextAttrUid = $(this).next().attr('uid');
			if(attrUid === nextAttrUid && attrUid !== global_data.user_key) {
				$(this).find('.chat_msg').append('<div class="message-divider"></div>'+$(this).next().find('.chat_msg').html());
				$(this).next().remove();
			}
		});
	}
};

String.prototype.replaceArray = function(find, replace) {
	var str = this;
	for (let i = 0; i < find.length; i++) {
		for(let a = 0; a < 6; a++) str = str.replace(find[i], replace[i]);
	}
	return str;
};

$(function() {
	var wForm = $('.chat_form div').outerWidth();
	$('.chat_text').css('width', wForm - 164);
	$('.chat_msgs').html(`<div class="py-4 text-center">${chat.loading}</div>`);
	var msgs = $('.chat_msgs');
	msgs.scroll(function () {
		chat.scrollBottom = (msgs.outerHeight(true) + msgs.scrollTop() >= $('.chat_msgs ul').outerHeight(true) - 40);
	});
	$('.chat_text').on('keypress keydown', function(e) {
		if(e.keyCode == '13') {
			chat.send(); 
			return false;
		}
	});
	setInterval(() => chat.check(), 1000);
});