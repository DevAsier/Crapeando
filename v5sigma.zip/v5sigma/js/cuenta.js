'use strict';
function desactivarCuenta(start = 0) {
	imported('import/cuenta.desactivate.js', 'desactivate', start);
}

var cuenta = {
	require: [],
	sistema(...args) {
		imported('import/cuenta.system.js', 'systemAction', args);
	},
	changeTab(object) {
		const classAppend = 'bg bg-opacity-3';
		// Quitamos todo
		$('div.content-tabs').hide();
		$('.menu-tab > span').removeClass(classAppend);
		$(object).addClass(classAppend);
		let nameTab = $(object).children('span').text().toLowerCase().replace(' ', '-');
		$('div.content-tabs.'+nameTab).show();
	},
	alerta({ show = true, section, title, content }) {
		const component = $(`.alert-cuenta.cuenta-${section}`);
		component.html(show ? title : '')[show ? 'slideDown' : 'slideUp'](120);
		setTimeout(() => {
			cuenta.alerta({ show: false });
			window.location.hash = '';
		}, 6000);
	},
	chgsec(obj) {
		$('div.content-tabs.perfil > h3').removeClass('active');
		$('div.content-tabs.perfil > fieldset').slideUp(100);
		if ($(obj).next().css('display') == 'none') {
			$(obj).addClass('active');
			$(obj).next().slideDown(100).addClass('active');
		}
	},
	chgpais: function(){
		let pais_code = $('select[name=pais]').val();
		let selectEstado = $('select[name=estado]');
		//No se selecciono ningun pais.
		if(empty(pais_code)) {
			selectEstado.addClass('disabled').attr('disabled', 'disabled').val('');
		} else {
			//Obtengo las estados
			$(selectEstado).html('');
			$('#loading').fadeIn(250);
			$.get(`${global_data.url}/registro-geo.php`, { pais_code }, req => {
				if(parseInt(req.charAt(0)) === 1) {
					cuenta.require['estado'] = false;
					$(selectEstado).append(req.substring(3)).removeAttr('disabled').val('').focus();
				}
				$('#loading').fadeOut(250);
			});
		}
	},
	next(isprofile) {
		if (typeof isprofile == 'undefined') var isprofile = false;
		if (isprofile) $('div.content-tabs.perfil > h3.active').next().next().click();
		else $('.menu-tab > .active').next().children().click();
	},
	save(secc, next) {
		$(`.cuenta-save-${secc}`).removeClass('input-incorrect');
		if (typeof next == 'undefined') next = false;
		let params = {};
		params['save'] = secc;
		$(`.cuenta-save-${secc}`).each(function() {
			if (($(this).attr('type') != 'checkbox' && $(this).attr('type') != 'radio') || $(this).prop('checked')) {
				params[$(this).attr('name')] = $(this).val();
			}
		});
		const cuenta_url = `${global_data.url}/cuenta.php?action=save&ajax=true`;
		$('#loading').slideDown(250);
		if (params['nacimiento']) {
			const fecha = params['nacimiento'].split('-');
			params['ano'] = fecha[0];
			params['mes'] = fecha[1];
			params['dia'] = fecha[2];
			delete params['nacimiento'];
		}
		$.post(cuenta_url, toStringParams(params), req => {
			const { error, field, porc } = req;
			if(error) {
				if(field) $(`input[name="${field}"]`).focus().addClass('input-incorrect');
				mydialog.toast(error, 'danger');
			} else {
				if(next) cuenta.next(secc > 1 && secc < 5);
				mydialog.toast('Los cambios fueron aceptados y ser&aacute;n aplicados.');
				window.location.hash = 'alert-cuenta';
			}
			$('#loading').slideUp(250); 
		}, 'json');
	}
}

const avatar = {
	size: 120,
	uid: false,
	key: false,
	ext: false,
	crop_coord: false,
	informacion: '',
	current: false,
	success: false,
	total: 2,
	fetching: async (page, data) => {
		const uploader = await fetch(`${global_data.url}/upload-${page}.php`, {
			method: 'POST',
			body: data
		});
		const response = await uploader.json();
		return response;
	},
	changeAvatar(type, allow) {
		const box = $('#loadChangeAvatar');
		box.show();
		if(type === 'desktop' && allow === true) {
			box.html(`
				<label for="file-avatar">Subir Archivo</label>
				<input type="file" name="file-avatar" id="file-avatar" size="15" class="browse"/>
				<button role="button" onclick="avatar.upload('file')" class="avatar-next button d-block w-100 text-center local">Subir</button>
			`);
		} else {
			if(allow) {
				box.html(`
					<label for="url-avatar">Direcci&oacute;n de la imagen</label>
					<input type="text" name="url-avatar" id="url-avatar" size="45"/>
					<button role="button" onclick="avatar.upload('url')" class="avatar-next button d-block w-100 text-center url">Subir</button>
				`);
			} else {
				box.html(`<em>Lo sentimos por el momento solo puedes subir avatares desde tu PC.</em>`);
			}
		}
	},
	upload: async (obj) => {
		$(".avatar-loading").show();
		const myInput = $(`input[name="${obj}-avatar"]`);
		const datoUrl = new FormData();
		datoUrl.append('url', (obj === 'url') ? myInput.val() : myInput[0].files[0]);

		const Response = await avatar.fetching('avatar', datoUrl);
		avatar.uploadsuccess(Response);
	},
	uploadsuccess(request) {
		const { error, msg, key, ext } = request;
		if (error == 'success') avatar.success = true;
		else if (msg) {
         avatar.key = key;
         avatar.ext = ext;
         avatar.cortar(msg);
		} else cuenta.alerta(error, 0);
		$(".avatar-loading").hide();
	},
	cortar(img) {
		let newImageUpload = img + '?t=' + string_random(10);
		mydialog.master({
			title: 'Cortar avatar',
			body: `<img class="avatar-crop" src="${newImageUpload}">`,
			buttons: {
				good: {
					value: 'Cortar avatar',
					action: 'avatar.save()'
				},
				fail: {
					display: true,
					action: 'avatar.close()'
				}
			}
		});
		$(".avatar-big, #avatar-menu").attr("src", newImageUpload).on('load', () => {
			let sizes = [avatar.size, avatar.size, 'px'];
			var croppr = new Croppr('.avatar-crop', {
			   aspectRatio: 1, // Mantemos el tamanio cuadrado 1:1
			   // Minimo de 120px x  120px
    			startSize: sizes, 
    			minSize: sizes, 
    			// Enviamos las coordenadas para cortar la imagen
    			// Tiene la funcion onCropEnd ya que es como va a quedar
    			onCropEnd: data => avatar.informacion = data ?? avatar.preview,
            onCropMove: avatar.preview
			});
		});
	},
	preview: function (coords) {
		avatar.crop_coord = coords;
		var rx = 120 / coords.w;
		var ry = 120 / coords.h;
		$('.avatar-big').css({
			width: Math.round(rx * $('.avatar-crop').width()) + 'px',
			height: Math.round(ry * $('.avatar-crop').height()) + 'px',
			marginLeft: '-' + Math.round(rx * coords.x) + 'px',
			marginTop: '-' + Math.round(ry * coords.y) + 'px'
		});
	},
	close: function () {
		mydialog.close();	
		avatar.success = false;
		let imageUrlUpdated = `${global_data.url}/files/avatar/${avatar.uid}_120.jpg?reload=true`;
		$('.avatar-reload').each(function() {
			$(this).attr('src', imageUrlUpdated);
		});
		$('.avatar-loading').hide();
	},
	save: async function () {
		if (empty(avatar.informacion)) cuenta.alerta('Debes seleccionar una parte de la foto', 0);
		else {
			const allcoord = {
				key: avatar.key,
				ext: avatar.ext,
				x: avatar.informacion.x,
				y: avatar.informacion.y,
				w: avatar.informacion.width,
				h: avatar.informacion.height
			};
			const coordenadas = new FormData();
			for (const prop in allcoord) coordenadas.append(prop, allcoord[prop]);
			const resultado = await avatar.fetching('crop', coordenadas)
			if(resultado.error === "success") {
			   avatar.close();
			   $("#loadChangeAvatar").html('').hide();
			}
		}
	}
}

function systemActive() {
	const html = $('html');
	const mode = html.attr('data-theme');
	const color = html.attr('data-theme-color');
	$(`.${mode}[role="button"]`).addClass('bg bg-opacity-1');
	$(`.${color}[role="button"]`).addClass('shadow');
}
systemActive()