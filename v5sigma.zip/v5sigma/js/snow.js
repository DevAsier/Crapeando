(async function() {
	const loadStyles = () => {
		const style = document.createElement("style");
		style.innerHTML = `.snowflake{position:fixed;width:11px;height:11px;background:white;border-radius:50%;animation:fall linear infinite;top:-16px;transition:width 0.6s ease, height 0.6s ease;}.small-snowflakes .snowflake {width:7px;height:7px;}@keyframes fall{0%{transform:translate(var(--start-x),-10px) scale(var(--scale));opacity:var(--opacity);}50%{transform:translate(var(--end-x),var(--mid-y)) scale(var(--scale));opacity:var(--opacity);}100%{transform:translate(var(--end-x-final),100vh) scale(var(--scale));opacity: 0;}}`;
		document.head.appendChild(style);
	};
	const generateSnowflakes = () => {
		const screenWidth = window.innerWidth;
		const baseCount = 200;
		const snowflakeCount = Math.min(baseCount, Math.floor(screenWidth / 5));
		for (let i = 0; i < snowflakeCount; i++) {
			const snowflake = document.createElement('div');
			snowflake.className = 'snowflake';
			const startX = Math.random() * 100 + 'vw';
			snowflake.style.setProperty('--start-x', startX);
			snowflake.style.setProperty('--end-x', `calc(${startX} + ${(Math.random() - 0.5) * 20}vw)`);
			snowflake.style.setProperty('--end-x-final', `calc(${startX} + ${(Math.random() - 0.5) * 10}vw)`);
			snowflake.style.setProperty('--mid-y', Math.random() * 50 + 50 + '%');
			snowflake.style.setProperty('--scale', Math.random() * 0.5 + 0.5);
			snowflake.style.setProperty('--opacity', Math.random() * 0.5 + 0.5);
			snowflake.style.animationDuration = Math.random() * 15 + 10 + 's';
			snowflake.style.animationDelay = Math.random() * -30 + 's';
			document.body.appendChild(snowflake);
		}
		clearTimeout(window.snowTimer);
		window.snowTimer = setTimeout(() => document.body.classList.add('small-snowflakes'), 3000);
	};
	const debounceResize = (func, delay = 300) => {
		let timer;
		return function(...args) {
			clearTimeout(timer);
			timer = setTimeout(() => func.apply(this, args), delay);
		};
	};
	const init = () => {
		loadStyles();
		generateSnowflakes();
		document.body.addEventListener('click', event => {
			if (event.target.classList.contains('snowflake')) {
				event.target.remove();
			}
		});
		const handleResize = debounceResize(() => {
			document.querySelectorAll('.snowflake').forEach(snowflake => snowflake.remove());
			generateSnowflakes();
		});
		window.addEventListener('resize', handleResize);
	};
	while (true) {
		if (document.readyState === 'complete') {
			init();
			break;
		}
		await new Promise(resolve => setTimeout(resolve, 100));
	}
})();