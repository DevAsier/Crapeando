// Función para borrar un post
export function borrarPost({ pid, confirmacion }) {
   if (confirmacion === 1) {
      mostrarDialogoConfirmacion(pid, (confirmacion === 1));
      return;
   }
   iniciarEliminacionPost(pid);
}

// Función para mostrar el diálogo de confirmación
function mostrarDialogoConfirmacion(pid, esReconfirmacion) {
   const mensaje = esReconfirmacion ? 'Te pregunto de nuevo... ' : '';
   const siguienteAccion = esReconfirmacion ? 2 : 1;
   mydialog.master({
      title: 'Borrar Post',
      body: `&iquest;${mensaje}Seguro que deseas borrar este post?`,
      buttons: {
         good: {
            value: 'Sí, borrar post',
            action: `borrar_post(${pid}, ${siguienteAccion})`
         },
         fail: {
            display: true,
            value: 'NO'
         }
      }
   });
}

// Función para iniciar la eliminación del post
function iniciarEliminacionPost(pid) {
   mydialog.procesando_inicio('Eliminando...', 'Borrar Post');
   $('#loading').fadeIn(250);
   // Envío de solicitud POST para eliminar el post
   $.post(`${global_data.url}/posts-borrar.php`, 'postid=' + pid, respuesta => {
      const resultado = parseInt(respuesta.charAt(0));
      const mensaje = respuesta.substring(3);
      const exito = (resultado === 1);
      mydialog.toast(mensaje, (exito ? 'success' : 'danger'));
      $('#loading').fadeOut(350);
   }).fail(() => {
      mydialog.error_500("borrarPost(2)");
      $('#loading').fadeOut(350);
   }).always(() => {
      mydialog.procesando_fin();
   });
}