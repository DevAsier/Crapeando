const templateForm = `
<div class="nada-gris mb-3" id="AFStatus">
	<span>Ingresa los datos de tu web para afiliarte.</span>
</div>
<div id="AFormInputs">
	<div class="form-group mb-3">
		<label for="atitle">Título</label>
		<input type="text" class="form-control" name="atitle" id="atitle" maxlength="35">
	</div>
	<div class="form-group mb-3">
		<label for="aurl">Dirección</label>
		<input type="url" class="form-control" name="aurl" id="aurl" value="https://">
	</div>
	<div class="form-group mb-3">
		<label for="aimg">Banner <small>(250x40px)</small></label>
		<input type="url" class="form-control" name="aimg" id="aimg" value="https://">
	</div>
	<div class="form-group mb-3">
		<label for="atxt">Descripción</label>
		<textarea class="form-control" name="atxt" id="atxt" rows="3"></textarea>
	</div>
</div>`;

export function nuevoAfiliado() {
	mydialog.master({
		title: 'Nueva Afiliación',
		body: templateForm,
		buttons: {
			good: {
				value: 'Enviar',
				action: 'afiliado.enviar()'
			}
		}
	})
}

export function afiliadoEnviar() {
	const params = $('#AFormInputs :input').map(function() {
		const $this = $(this);
		const name = $this.attr('name');
		const val = name === 'aID' ? '0' : $this.val().trim();
		if (val === '' && name !== 'aID') {
			$('#AFStatus > span').text(`Campo requerido: ${$this.prev('label').text()}`).fadeIn();
			return null;
		}
		return `${name}=${encodeURIComponent(val)}`;
	}).get().join('&');

	if (params) {
		mydialog.procesando_inicio('Enviando...', 'Nueva Afiliación');
		afiliadoEnviando(params);
	}
}

function afiliadoEnviando(params) {
	$('#loading').fadeIn(250);
	$.post(`${global_data.url}/afiliado-nuevo.php`, params, request => {
		mydialog.procesando_fin();
		if(request.charAt(0) === '0' || request.charAt(0) === '2') {
			const msgEnviando = request.charAt(0) === '0' ? 'La URL es incorrecta' : 'Faltan datos';
			$('#AFStatus > span').fadeOut().text(msgEnviando).fadeIn();
		} else {
			mydialog.body(request.substring(3));
			mydialog.buttons(true, true, 'Aceptar', 'mydialog.close()', true, true);
		}
		mydialog.center();
		$('#loading').fadeOut(350);
	});
}

export function detalles(ref) {
	$('#loading').fadeIn(250);
	$.post(`${global_data.url}/afiliado-detalles.php`, { ref }, request => {
		mydialog.show(true);
		mydialog.title('Detalles del afiliado');
		mydialog.body(request);
		mydialog.buttons(true, true, 'Aceptar', 'mydialog.close()', true, true);
		mydialog.center();
		$('#loading').fadeOut(350);
	});
}