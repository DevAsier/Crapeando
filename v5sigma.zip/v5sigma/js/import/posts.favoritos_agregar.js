let handleFavouritePost = false;

export function agregarAFavoritos() {
   if (handleFavouritePost) return;
   if (!gget('key')) {
      mydialog.alert('Login', 'Tienes que estar logueado para realizar esta operaci&oacute;n');
      return;
   }
   handleFavouritePost = true;
   $('#loading').fadeIn(250);
   $('.favorite_button i').removeClass('fa-heart').addClass('fa-spinner fa-animate')
   $.post(`${global_data.url}/favoritos-agregar.php`, gget('postid', true), respuesta => {
   	manejarRespuestaFavoritos(respuesta);
      $('#loading').fadeOut(350);
      $('.favorite_button i').removeClass('fa-spinner fa-animate').addClass('fa-heart')
   }).fail(() => manejarErrorFavoritos());
}

function malHecho(malHechoMsg, time = 2000, withoutmsg = true) {
   const malhecho = $('#malecho')
   if (withoutmsg) malhecho.addClass('nada-rojo').html(malHechoMsg).show();
   setTimeout(() => malhecho.hide(), time);
}

function manejarRespuestaFavoritos(respuesta) {
   const resultado = parseInt(respuesta.charAt(0));
   malHecho((resultado === 0 ? respuesta.substring(3) : ''), 3000, (resultado === 0));
   console.log(resultado)
   if(resultado === 1) {
   	$('#cfavori').total({ sumar: true, find: '' });
   }
}

function manejarErrorFavoritos() {
   handleFavouritePost = false;
   mydialog.error_500("add_favoritos()");
   $('#loading').fadeOut(250);
}