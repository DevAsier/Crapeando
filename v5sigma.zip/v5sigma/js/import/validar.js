export function isValid({ input, type }) {
	let val = input.val();
	const regex = /^(https?|ftp):\/\/[^\s/$.?#].[^\s]*$/i;
	//
	if (empty(val) || regex.test(val) === false) {
		return 'Debes ingresar una direcci&oacute;n URL v&aacute;lida.';
	}
	if (type === 'foto') {
		isImageShout(input);
		return;
	}
	if (type === 'video') {
		isVideoShout(val);
		return;
	}
	return true;
}

function isImageShout(input) {
	const extensiones = ['jpg', 'jpeg', 'png', 'gif'];
	input.val(val.replace(' ', ''));
	let extension = input.val().slice((input.val().lastIndexOf(".") - 1 >>> 0) + 2);
	if (extensiones.indexOf(extension) === -1) {
		return 'S&oacute;lo se permiten im&aacute;genes .jpg, .jpeg, .png y .gif';
	}
}

function isVideoShout(val) {
	if(isYoutube(val) === false) return 'Al parecer la url del video no es v&aacute;lida. Recuerda que solo puedes compartir videos de YouTube.';
}