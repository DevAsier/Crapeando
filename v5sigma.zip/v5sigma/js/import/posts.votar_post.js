let hasVotedPost = false;
// Función para votar un post
export function votarPost(puntos) {
   if (hasVotedPost) return;
   if (!validarPuntos(puntos)) {
      mydialog.alert('Error', 'Debe introducir números válidos');
      return false;
  	}
   hasVotedPost = true;
   $('#loading').fadeIn(250);

   // Envío de solicitud POST para votar
   $.post(`${global_data.url}/posts-votar.php`, `puntos=${puntos}` + gget('postid'), respuesta => {
      manejarRespuestaVoto(respuesta, puntos);
      $('#loading').fadeOut(350);
   }).fail(() => manejarErrorVoto(puntos));
}

function malHecho(malHechoMsg, time = 2000, withoutmsg = true) {
   const malhecho = $('#malecho')
   if (withoutmsg) malhecho.addClass('nada-rojo').html(malHechoMsg).show();
   setTimeout(() => malhecho.hide(), time);
}

// Función para validar los puntos introducidos
function validarPuntos(puntos) {
   return puntos != null && !isNaN(puntos) && puntos >= 1;
}

// Función para manejar la respuesta del voto
function manejarRespuestaVoto(respuesta, puntos) {
   ShowVotes(true);
   $('.dar-puntos').slideUp();
   const resultado = parseInt(respuesta.charAt(0));
   switch (resultado) {
      case 0: // Error
         malHecho(respuesta.substring(3), 3000);
      break;
      case 1: // OK
         actualizarPuntos(puntos);
         actualizarVotos();
         malHecho('Puntos agregados!', 3000);
      break;
   }
}

function sumar(element, total) {
   let puntosActuales = parseInt($(element).text().replace(".", ""));
   $(element).html(number_format(puntosActuales + parseInt(total), 0, ',', '.'));
}

// Función para actualizar la cantidad de puntos del post
function actualizarPuntos(puntos) {
   sumar('#puntos_post', puntos);
}

// Función para actualizar la cantidad de votos del post
function actualizarVotos() {
   sumar('#post_vote_total', 1);
}

// Función para manejar el error al votar
function manejarErrorVoto(puntos) {
   hasVotedPost = false;
   mydialog.error_500(`votarPost('${puntos}')`);
   $('#loading').fadeOut(350);
}

// Función para mostrar u ocultar los votos
function ShowVotes(forceHide) {
   if (hasVotedPost) return;
   const metadataPuntos = $('.post-metadata .dar_puntos');
   const mostrarVotos = !forceHide && metadataPuntos.css('display') === 'none';
   metadataPuntos[mostrarVotos ? 'show' : 'hide']();
}