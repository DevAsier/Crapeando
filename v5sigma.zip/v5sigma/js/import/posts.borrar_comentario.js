/* Eliminar Comentario */
export function borrarComentario([comid, autor, postid, confirmacion]) {
	mydialog.close();
	// Si no se proporciona un postid, se obtiene el valor por defecto
	postid = postid || gget('postid');
	if (!confirmacion) {
	   mostrarModal({ comid, autor, postid });
	} else {
	   $('#loading').fadeIn(250);
	    
	   /**
	    * Parámetros para la solicitud
	    * Más información: https://developer.mozilla.org/en-US/docs/Web/API/URLSearchParams
	   */
	   const params = new URLSearchParams({ comid, autor, postid });

	   // Envío de solicitud POST
	   $.post(`${global_data.url}/comentario-borrar.php`, params.toString(), respuesta => {
	      const resultado = parseInt(respuesta.charAt(0));
	      const mensaje = respuesta.substring(3);

	      if (resultado === 0) {
	         mydialog.alert('Error', mensaje);
	      } else {
	         actualizarComentarios(comid);
	      }
	      
	      $('#loading').fadeOut(350);
	   }).fail(() => {
	      mydialog.error_500(`borrarComentario('${comid}')`);
	      $('#loading').fadeOut(350);
	   });
	}
}

function mostrarModal({ comid, autor, postid }) {
   mydialog.master({
      title: 'Borrar Comentario',
      body: '&#191;Desea eliminar este comentario?',
      buttons: {
         good: {
            value: 'Sí, borrar comentario',
            action: `borrarComentario(['${comid}', '${autor}', '${postid}', true])`
         },
         fail: {
            display: true,
            value: 'No, cancelar'
         }
      }
   });
}

// Función para actualizar la lista de comentarios
function actualizarComentarios(comid) {
   const ncomments = $('#ncomments');
   const currentCount = parseInt(ncomments.text());

   // Actualiza el contador de comentarios
   ncomments.text(currentCount - 1);

   // Elimina visualmente el comentario
   $(`#div_cmnt_${comid}`).fadeOut('slow').slideUp('normal', function() {
      $(this).remove();
   });
}