export function citar_comment(id, nick) {
   const textarea = $('#body_comm');
   textarea.focus();
   let content = (textarea.val() != '') ? textarea.val() + '\n' : '';
   let decode = htmlspecialchars_decode($('#citar_comm_' + id).html(), 'ENT_NOQUOTES');
   textarea.val(`${content} [quote=${nick}]${decode}[/quote]\n`);
}