export function denunciaNueva({ type, obj_id, obj_title, obj_user }) {
	console.log(type, obj_id, obj_title, obj_user)
	$('#loading').fadeIn(250);
	let params = `obj_id=${obj_id}&obj_title=${obj_title}&obj_user=${obj_user}`;
	$.post(`${global_data.url}/denuncia-${type}.php`, params, request => setDialog({ request, obj_id, type }));
}

export function denunciaEnviar({ type, id: obj_id }) {
	let razon = $('select[name=razon]').val();
	let extras = $('textarea[name=extras]').val();
	$('#loading').fadeIn(250);
	$.post(`${global_data.url}/denuncia-${type}.php`, `obj_id=${obj_id}&razon=${razon}&extras=${extras}`, request => {
		mydialog.toast(request.substring(3),(request.charAt(0) == '0' ? "danger" : "success"));
		$('#loading').fadeOut(350);
	});
}

function setDialog({ request, obj_id, type }) {
	console.log(request)
	$('#loading').fadeOut(350);
	mydialog.master({
		title: 'Denunciar ' + type,
		body: request,
		buttons: {
			good: {
				value: 'Enviar',
				action: `denuncia.enviar({ type: '${type}', id: ${obj_id}})`,
			},
			fail: {
				value: 'Cancelar'
			}
		}
	});
}