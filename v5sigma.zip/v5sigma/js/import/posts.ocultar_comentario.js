// Función para ocultar un comentario
export function ocultarComentario([comid, autor, postid]) {
   mydialog.close();
   $('#loading').fadeIn(250);
	/**
	 * Parámetros para la solicitud
	 * Más información: https://developer.mozilla.org/en-US/docs/Web/API/URLSearchParams
	*/
   const params = new URLSearchParams({ comid, autor, postid: postid || gget('postid') });
   // Envío de solicitud POST
   $.post(`${global_data.url}/comentario-ocultar.php`, params.toString(), respuesta => {
      const resultado = parseInt(respuesta.charAt(0));
      const mensaje = respuesta.substring(3);
      if (resultado === 0) {
         mydialog.alert('Error', mensaje);
      } else {
         actualizarVisibilidadComentario(comid, resultado);
      }
      $('#loading').fadeOut(350);
   }).fail(() => {
      mydialog.error_500(`ocultarComentario('${comid}', '${autor}', '${postid}')`);
      $('#loading').fadeOut(350);
   });
}

// Función para actualizar la visibilidad del comentario
function actualizarVisibilidadComentario(comid, estado) {
   const comentarioOpacity = (estado === 1) ? 1 : 0.5;
   const ppOpacity = (estado === 1) ? 0.5 : 1;
   // Actualiza la opacidad del comentario y su imagen de perfil
   $(`#comentario_${comid}`).css('opacity', comentarioOpacity);
   $(`#pp_${comid}`).css('opacity', ppOpacity);
}