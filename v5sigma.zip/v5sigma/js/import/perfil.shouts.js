function handleResponse(response, elementSelector) {
   response = response.replace(/^"|"$/g, '');
   let type = parseInt(response.charAt(0));
   const message = response.substring(3);
   const element = $(elementSelector);
   if(type === 0 || type === 1) {
      mydialog.toast(message, (type === 0 ? 'danger' : 'success'), 8);
   }
   if(type === 2) {
      mydialog.toast(message);
      const total = parseInt(element.data('total')) + 1;
      element.data('total', total).find('strong').text(kmg(total));
   }
   $('#loading').fadeOut(350);
}

export function phpPost(object) {
   const { endpoint, comid, selector: elementSelector } = object;
   $('#loading').fadeIn(250);
   $.post(`${global_data.url}/muro-${endpoint}.php`, { comid })
   .done(response => handleResponse(response, elementSelector))
   .fail(() => {
      mydialog.error_500(`('${comid}')`);
      $('#loading').fadeOut(350);
   });
}

// Cargar actividad del shout con caché
export function ver_actividad(id) {
   $('#loading').fadeIn(250);
   const actividad = $(`#activida${id}`);
   const carga = $(`#carga_${id}`);
   const eye = $(`#actividad_${id}`);
   // Utiliza `data` de jQuery para almacenar y verificar el caché
   let cache = actividad.data('cache');
   if (actividad.is(':hidden')) {
      if (cache) {
         actividad.show().html(cache);
         $('#loading').fadeOut(350);
      } else {
         carga.show();
         $.get(`${global_data.url}/muro-actividad.php`, { id }, response => {
            actividad.show().html(response);
            actividad.data('cache', response); // Guarda la respuesta en caché
            carga.hide();
            eye.find('i').removeClass('fa-eye').addClass('fa-eye-slash');
            $('#loading').fadeOut(350);
         }).fail(() => {
            carga.hide();
            eye.find('i').addClass('fa-eye').removeClass('fa-eye-slash');
            $('#loading').fadeOut(350);
         });
      }
   } else {
      actividad.hide();
      eye.find('i').addClass('fa-eye').removeClass('fa-eye-slash');
      $('#loading').fadeOut(350);
   }
}
