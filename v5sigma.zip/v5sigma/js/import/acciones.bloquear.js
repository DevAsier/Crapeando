export function bloquear({user, bloqueado, lugar, aceptar}) {
	if (!aceptar && bloqueado) {
		mostrarDialogoConfirmacion(user, bloqueado, lugar);
		return;
	}

	realizarSolicitudBloqueo(user, bloqueado, lugar);
}

function mostrarDialogoConfirmacion(user, bloqueado, lugar) {
	mydialog.master({
		title: 'Bloquear usuario',
		body: '¿Realmente deseas bloquear a este usuario?',
		buttons: {
			good: {
				display: true, value: 'Si', action: `bloquear('${user}', true, '${lugar}', true)`
			},
			fail: {
				display: true, value: 'No'
			}
		}
	});
}

async function realizarSolicitudBloqueo(user, bloqueado, lugar) {
	if (bloqueado) mydialog.procesando_inicio('Procesando...', 'Bloquear usuario');
	const paramsToSend = `user=${user}${bloqueado ? '&bloquear=1' : ''}${gget('key')}`;
	try {
		const respuesta = await $.post(`${global_data.url}/bloqueos-cambiar.php`, paramsToSend);
		manejarRespuestaBloqueo(respuesta, { user, bloqueado, lugar });
		mydialog.close();
	} catch (error) {
		mydialog.error_500(`bloquear('${user}', ${bloqueado}, '${lugar}', true)`);
	} finally {
		mydialog.procesando_fin();
	}
}

function manejarRespuestaBloqueo(respuesta, { user, bloqueado, lugar }) {
	mydialog.toast(respuesta.substring(3), {
		type: 'info',
		duration: 4000
	});
	if (respuesta.charAt(0) === '1') {
		actualizarInterfazBloqueo(user, bloqueado, lugar);
	}
}

function actualizarInterfazBloqueo(user, bloqueado, lugar) {
	const acciones = {
		perfil: () => actualizarBoton('bloquear_cambiar', user, bloqueado, lugar),
		respuestas: () => actualizarLista(user, bloqueado),
		comentarios: () => actualizarLista(user, bloqueado),
		mis_bloqueados: () => actualizarListaBloqueados(user, bloqueado, lugar),
		mensajes: () => actualizarBoton('bloquear_cambiar', user, bloqueado, lugar)
	};
	if (acciones[lugar]) {
		acciones[lugar]();
	}
}

function actualizarBoton(element, user, bloqueado, lugar) {
	const texto = bloqueado ? 'Desbloquear' : 'Bloquear';
	const clase = bloqueado ? 'desbloquearU' : 'bloquearU';
	const icono = bloqueado ? 'fa-user' : 'fa-user-slash';
	$(`#${element}`).attr({ onclick: `bloquear(${user}, ${bloqueado}, '${lugar}')` });
	$(`#${element} i`).removeClass('fa-user fa-user-slash').addClass(icono);
	$(`#${element} span`).html(texto);
}


function actualizarLista(user, bloqueado) {
	$(`li.desbloquear_${user}`).toggle(bloqueado);
	$(`li.bloquear_${user}`).toggle(!bloqueado);
}

function actualizarListaBloqueados(user, bloqueado, lugar) {
	const texto = bloqueado ? 'Desbloquear' : 'Bloquear';
	 
	$(`.bloquear_usuario_${user}`)
		.html(texto)
		.removeClass('bloquearU desbloquearU')
		.addClass(bloqueado ? 'desbloquearU' : 'bloquearU')
		.attr({
			title: `${texto} Usuario`,
			onclick: `bloquear('${user}', ${!bloqueado}, '${lugar}')`
		});
}