'use strict';
export function desactivate(actionType) {
	switch (actionType) {
		case 0:
			showDesactivateWarning();
		break;
		case 1:
			confirmDesactivate();
		break;
		case 2:
			executeDesactivation();
		break;
	}
}

function showDesactivateWarning() {
	mydialog.master({
		title: 'Desactivar cuenta',
		body: 'Si desactiva su cuenta, todo el contenido relacionado dejará de ser visible temporalmente. Pasado ese tiempo, el sistema eliminará todo su contenido permanentemente y no podrá recuperarlo.',
		buttons: {
			confirm: {
				value: 'Desactivar',
				action: 'desactivate(1)'
			}
		}
	});
}

function confirmDesactivate() {
	mydialog.master({
		title: 'Confirmación de Desactivación',
		body: '¿Está seguro de que desea desactivar su cuenta?',
		buttons: {
			confirm: {
				value: 'Confirmo desactivación',
				action: 'desactivate(2)'
			}
		}
	});
}

function executeDesactivation() {
	$('#loading').fadeIn(250);
	$.post(`${global_data.url}/cuenta.php?action=desactivate`, { validar: 'ajaxcontinue' }, response => {
		const status = parseInt(response.charAt(0));
		const message = status ? 'Cuenta desactivada' : 'No se pudo desactivar';
		mydialog.alert(status ? 'Hecho' : 'Error', message, !status);
		$('#loading').fadeOut(250); 
	});
}