'use strict';

export function systemAction([type, value]) {
	switch (type) {
		case 'mode':
			$(`.state-btn.light, .state-btn.dark`).removeClass('bg bg-opacity-1');
			systemMode(value);
		break;
		case 'color':
			$(`.state-btn.default, .state-btn.red, .state-btn.green, .state-btn.violet`).removeClass('shadow');
			systemColor(value);
		break;
	}
	
}

function systemMode(val) {
	const MODE = 'light'; // Valor por defecto
	const savedMode = localStorage.getItem('theme-mode') || MODE;
	const modeToSet = val || savedMode;
	$(`.${modeToSet}`).addClass('bg bg-opacity-1');
	localStorage.setItem('theme-mode', modeToSet); // Guarda el modo en localStorage
	$('html').attr('data-theme', modeToSet); // Aplica el tema en el HTML
}

function systemColor(val) {
	const COLOR = 'default'; // Valor por defecto
	const savedColor = localStorage.getItem('theme-color') || COLOR;
	const colorToSet = val || savedColor;
	$(`.${colorToSet}`).addClass('shadow');
	localStorage.setItem('theme-color', colorToSet); // Guarda el color en localStorage
	$('html').attr('data-theme-color', colorToSet); // Aplica el color en el HTML
}