export function likeShout({ id, type, obj }) {
   $('#loading').slideDown(250);
   $.post(`${global_data.url}/muro-likes.php`, { id, type }, ({ status, link, text }) => {
      status === 'ok' ? handleLikeSuccess(id, type, link, text) : mydialog.alert('Error:', text.slice(3));
   }, 'json').always(() => $('#loading').slideUp(250));
}

function handleLikeSuccess(id, type, link, text) {
   type === 'pub' ? updateLikeButton(id, link, text) : updateReplyLike(id, text);
}

function updateReplyLike(id, text) {
   const replyLikeElement = $(`#replyLike_${id}`);
   const updatedTotal = parseInt(replyLikeElement.text(), 10) + (text ? -1 : 1);
   replyLikeElement.text(updatedTotal).removeClass('color-info').addClass('color-success').parent().parent().show();
}

function updateLikeButton(id, link, text) {
   const likeButton = $(`#shout_like_${id}`);
   const opt = { title: link, [text ? 'sumar' : 'restar']: true };
   
   $(`#commentBox${id}`).toggle(link !== 'Me gusta');
   likeButton.total(opt);

   const newTotal = parseInt(likeButton.data('total'), 10);
   likeButton.find('i').toggleClass('fas', newTotal > 0).toggleClass('far', newTotal <= 0);

   $(`#activida${id}`).hide();
   if (link !== 'Me gusta') $(`#commentTextarea${id}`).focus();
}