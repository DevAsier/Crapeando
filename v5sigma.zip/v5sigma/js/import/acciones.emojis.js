'use strict';
const emojiCache = {};

export function loadTabEmojis(tab) {
	$('.GifBoxCats span').removeClass('active bg bg-opacity-2');
	$(`.GifBoxCats span#${tab}`).addClass('active bg bg-opacity-2');
	// Configurar opacidad mientras se carga el contenido
   const $gifBoxImages = $('.GifBoxImages').css({ opacity: .5 });
   // Verificamos si hay datos de la pestaña en caché
   if (emojiCache[tab]) {
      // Si está en caché, mostramos
      $gifBoxImages.html(emojiCache[tab]).css({ opacity: 1 });
      return;
   } 
	getContentEmojis($gifBoxImages, tab);
}

function getContentEmojis(boximage, tab) {
	// Cargar datos de servidor si no están en caché
	$.getJSON(`${global_data.url}/live-images.php?load=${tab}`, (data) => {
		const content = data.map(({ src, name, bbcode }) => `
			<div class="image-emoji image image-5 bg bg-opacity-1 rounded overflow-hidden" role="button" onclick="copyBBCodeToClipboard('${bbcode}')">
				<img src="${src}" class="w-100 h-100 object-fit-cover" title="${name}" alt="${bbcode}">
			</div>
		`).join('');
		// Guardar en caché y mostrar el contenido
		emojiCache[tab] = content;
		boximage.html(content).css({ opacity: 1 });
	});
}