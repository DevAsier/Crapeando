'use strict';
const registro_load_form = () => location.href = `${global_data.url}/registro/`;
const spoiler = obj => $(obj).toggleClass('show').parent().next().slideToggle();
const loadTabEmojis = tab => imported('import/acciones.emojis.js', 'loadTabEmojis', tab);
const bloquear = (user, bloqueado, lugar, aceptar) => imported('import/acciones.bloquear.js', 'bloquear', {user, bloqueado, lugar, aceptar});

function gget(data, sin_amp) {
   const globalKeys = {
      key: global_data.user_key,
      postid: global_data.postid,
      fotoid: global_data.fotoid,
      comid: global_data.comid,
      temaid: global_data.temaid
   };
   const value = globalKeys[data];
   return value ? `${sin_amp ? '' : '&'}${data}=${value}` : '';
}
const denuncia = {
	nueva(type, obj_id, obj_title, obj_user) {
		imported('import/acciones.denuncias.js', 'denunciaNueva', {type, obj_id, obj_title, obj_user});
	},
	enviar(obj) {
		imported('import/acciones.denuncias.js', 'denunciaEnviar', obj);
	}
};

const animateIcon = (name, icon, status = true) => {
	const SpinnerIcon = 'fa-spinner fa-animate';
	$(`a[name=${name}] span`).removeClass((status ? icon : SpinnerIcon)).addClass((status ? SpinnerIcon : icon));
}

/* Notifica */
var notifica = {
	cache: {},
	retry: [],
   handleNumber(parse, format = false) {
   	let parsear = parseInt(parse);
   	return format ? parsear : number_format(parsear);
   },
   handleResponse(response, successCallback) {
      let handleRes = response.split('-');
      if (handleRes.length === 3 && handleRes[0] === 0) {
         successCallback(handleRes);
      } else if (handleRes.length === 4) {
         mydialog.alert('Notificaciones', handleRes[3]);
      }
   },
	userInMencionHandle(response) {
		notifica.handleResponse(response, function(request) {
			let fid = request[1];
	      $(`a.mf_${fid}, a.mf_${fid}`).each(function() {
	         $(this).toggle();
	      });
	      $(`.mft_${fid}`).html(notifica.handleNumber(request[2]));
	      vcard_cache[`mf_${fid}`] = '';
		});
	},
	userMenuHandle(response) {
		notifica.handleResponse(response, request => {
			let cache_id = 'following_' + request[1];
			notifica.cache[cache_id] = notifica.handleNumber(request[0]);
			$('div.avatar-box').children('ul').hide();
		});
	},
	userInPostHandle(response) {
		notifica.handleResponse(response, req => {
			$('a.follow_user_post, a.unfollow_user_post').toggle();
			$('div.metadata-usuario > span.nData.user_follow_count').html(notifica.handleNumber(handleRes[2]));
			notifica.userMenuHandle(response);
		});
	},
	userInMonitorHandle(response, obj) {
		notifica.handleResponse(response, () => $(obj).fadeOut(() => $(obj).remove() ));
	},
	inPostHandle(response) {
		notifica.handleResponse(response, request => {
			let numberHandleInPost = notifica.handleNumber(request[2]);
			$('a.follow_post, a.unfollow_post').parent('li').toggle();
			$('ul.post-estadisticas > li > span.icons.monitor').html(numberHandleInPost);
			$('#cseguir').html(numberHandleInPost);
			$('#cseguir').total({ sumar: true });
		});	
	},
	inComunidadHandle(response) {
		notifica.handleResponse(response, request => {
			$('a.follow_comunidad, a.unfollow_comunidad').toggle();
			$('li.comunidad_seguidores').html(notifica.handleNumber(request[2]) + ' Seguidores');
		});
	},
	temaInComunidadHandle(response) {
		notifica.handleResponse(response, request => {
			$('.followBox > a.follow_tema, a.unfollow_tema').toggle();
			$('.tema_notifica_count').html(notifica.handleNumber(request[2]) + ' Seguidores');
		});
	},
	ruserInAdminHandle(response) {
		notifica.handleResponse(response, request => $('.ruser' + request[1]).toggle());
	},
	listInAdminHandle(response) {
		notifica.handleResponse(response, request => {
			let liahID = request[1];
			const liahc = `.list${liahID}`;
			$(liahc).toggle();
			$(`${liahc}:first`).parent('div').parent('li').children('div:first').fadeTo(0, $(`${liahc}:first`).css('display') == 'none' ? 0.5 : 1);
		});
	},
	spamPostHandle(r) {
		var x = r.split('-');
		if (x.length == 2) mydialog.alert('Notificaciones', x[1]);
		else mydialog.close();
	},
	spamTemaHandle(r) {
		var x = r.split('-');
		if (x.length == 2) mydialog.alert('Notificaciones', x[1]);
		else mydialog.close();
	},
	ajax(param, useFn, obj) {
		if ($(obj).hasClass('spinner')) return;
		notifica.retry.push(param);
		notifica.retry.push(useFn);
		var error = param[0]!='action=count';
		$(obj).addClass('spinner');
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/notificaciones-ajax.php`, param.join('&') + gget('key'), resquest => {
			$(obj).removeClass('spinner');
			useFn(resquest, obj);
			$('#loading').fadeOut(350);
		})
		.fail(() => {
			if (error) mydialog.error_500('notifica.ajax(notifica.retry[0], notifica.retry[1])');
			$('#loading').fadeOut(350);
		});
	},
	follow(type, id, cb, obj) {
		this.ajax(['action=follow', 'type='+type, 'obj='+id], cb, obj);
	},
	unfollow(type, id, cb, obj) {
		this.ajax(['action=unfollow', 'type='+type, 'obj='+id], cb, obj);		
	},
	spam(id, cb) {
		this.ajax(['action=spam', 'postid='+id], cb);
	},
	c_spam(id, cb) {
		this.ajax(['action=c_spam', 'temaid='+id], cb);
	},
	share(id, tipo = 'post') {
		let func = (tipo === 'post') ? '' : 'c_';
		let nameH = (tipo === 'post') ? 'Post' : 'Tema';
		mydialog.master({
			title: 'Recomendar',
			body: `¿Quieres recomendar este ${tipo} a tus seguidores?`,
			buttons: {
				good: {
					value: 'Recomendar',
					action: `notifica.${func}spam('${id}', notifica.spam${nameH}Handle)`
				}
			}
		})
	},
	sharePost(id) {
		this.share(id);
	},
	shareTema(id) {
		this.share(id, 'tema');
	},
	last() {
		let CountMonAlert = parseInt($('#alerta_mon > a > span').html());
		mensaje.close();
		favorito.close();
		shoutbox.close();
		usuario.close();
		if ($('#mon_list').css('display') != 'none') {
			$('#mon_list').hide();
			$('a[name=Monitor]').parent('li').removeClass('bg-active');
		} else {
			if (($('#mon_list').css('display') == 'none' && CountMonAlert > 0) || typeof notifica.cache.last == 'undefined') {
				animateIcon('Monitor', 'fa-bell');
				$('a[name=Monitor]').parent('li').addClass('bg-active');
				$('#mon_list').show();
				notifica.ajax(Array('action=last'), function (r) {
					notifica.cache['last'] = r;
					notifica.show();
				});
			} else notifica.show();
		}
	},
	check() {
		notifica.ajax(['action=count'], notifica.popup);
	},
	popup(request) {
		let CountMonAlertPopup = parseInt($('#alerta_mon > a > span').html());
		if (request != CountMonAlertPopup && request > 0) {
			const NotTotal = ' notificaci' + (request != 1 ? 'ones' : '&oacute;n');
			if (!$('#alerta_mon').length) {
				$('li.monitor').append(`<div class="alertas" id="alerta_mon"><a title="${request}${NotTotal}"><span></span></a></div>`);
			}
			$('#alerta_mon > a > span').html(request);
			$('#alerta_mon').animate({ top: '-=5px' }, 100, null, function(){ $('#alerta_mon').animate({ top: '+=5px' }, 100) });
		} else if (r == 0) $('#alerta_mon').remove();
	},
	show() {
		if (typeof notifica.cache.last != 'undefined') {
			$('#alerta_mon').remove();
			$('a[name=Monitor]').parent('li').addClass('bg-active');
			animateIcon('Monitor', 'fa-bell', false);
			$('#mon_list').show().children('ul').html(notifica.cache.last);
		}
	},
	filter(fid, obj) {
		$.post(`${global_data.url}/notificaciones-filtro.php`, toStringParams(fid))
	},
	close(){
		$('#mon_list').hide();
		$('a[name=Monitor]').parent('li').removeClass('bg-active');
	}
}
/* Mensajes */
var mensaje = {
	cache: {},
	vars: { error:'', to:'', subject:'', message:'' },
	// CREAR HTML
	sendForm() {
		let html = '';
		const fields = ['to', 'subject', 'message'];
		const { error, to, subject, message } = this.vars;
		if (error) html += `<div class="emptyData">${error}</div>`;
		fields.forEach(field => {
			html += (field === 'to' || field === 'subject') ? this.createInputField(field, this.vars[field]) : this.createTextareaField(message);
		});
		return html;
	},
	createInputField(field, value) {
		const placeholder = field === 'to' ? 'Para' : 'Asunto';
		return `<div class="form-group mb-3">
			<input type="text" value="${value}" maxlength="16" tabindex="0" id="msg_${field}" name="msg_${field}" placeholder="${placeholder}" class="form-control">
		</div>`;
	},
	createTextareaField(value) {
		return `<div class="form-group mb-3">
			<textarea tabindex="0" rows="10" id="msg_body" name="msg_body" placeholder="Escribe tu mensaje..." class="form-control">${value}</textarea>
		</div>`;
	},
	// FUNCIONES AUX
	checkform(response) {
		const check = {
			1: 'No es posible enviarse mensajes a s&iacute; mismo.',
			2: 'Este usuario no existe. Por favor, verif&iacute;calo.'
		}
		if(parseInt(response) === 0) mensaje.enviar(1);
		else if(parseInt(response) === 1 || parseInt(response) === 2) {
			const { to, subject, message } = mensaje.vars;
			mensaje.nuevo(to, subject, message, check[parseInt(response)]);
		}
	},
	alert(content) {
		mydialog.procesando_fin();
		mydialog.alert('Aviso',`<div>${content}</div>`);
	},
	eliminar(id, type) {
		mensaje.ajax('editar', toStringParams({ ids: id, act: 'delete' }), () => {
			if(type === 2) {
				location.href = global_data.url + '/mensajes/';
				return;
			}
			let cid = id.split(':');
			$('#mp_' + cid[0]).remove();
		});
	},
	marcar(ids, a, type, obj){
		let act = (a == 0) ? 'read' : 'unread';
		let show = (act == 'read') ? 'unread' : 'read';
		mensaje.ajax('editar', toStringParams({ ids, act }), () => {
			if(type !== 1) {
				location.href = global_data.url + '/mensajes/';
				return;
			}
			// CAMBIAR ENTRE LEIDO Y NO LEIDO
			let cid = ids.split(':');
			$('#mp_' + cid[0])[(act === 'read' ? 'removeClass' : 'addClass')]('unread bg bg-opacity-1');
			$('#mp_' + cid[0] + ' .actims span').toggle();
			//
			$(obj).parent().find('a').hide();
			$(obj).parent().find('.' + show).show();	
		});
	},
	// POST
	ajax(action, params, fn){
		$('#loading').fadeIn(250);
		params = empty(params) ? '' : toStringParams(params);
		$.post(`${global_data.url}/mensajes-${action}.php`, params, request => {
			fn(request);
			$('#loading').fadeOut(350);
		});
	},
	// PREPARAR EL ENVIO
	nuevo(to = '', subject = '', message = '', error = ''){
		$('#mp_list').hide();
		$('a[name=Mensajes]').parent('li').removeClass('bg-active');
		// GUARDAR
		this.vars = { to, subject, message, error };
		//
		mydialog.procesando_fin();
		mydialog.master({
			title: 'Nuevo Mensaje',
			body: this.sendForm(),
			buttons: {
				good: {
					value: 'Enviar', action: '$(\'.wysibb-texarea\').sync(); mensaje.enviar(0)'
				}
			}
		});
		$('#msg_body').wysibb({ 
			buttons: "smilebox,|,bold,italic,underline,strike,sup,sub,|,img,video,link,|,removeFormat" 
		});
	},
	// ENVIAR...
	enviar(enviar){
		// DATOS
		this.vars = {
			to: $('#msg_to').val(),
			subject: $('#msg_subject').val(),
			message: $('#msg_body').bbcode()
		};
		const { to, subject, message } = this.vars;
		// COMPROBAR
		if(enviar === 0){ // VERIFICAR...
			if(this.vars.to === '')
				mensaje.nuevo(mensaje.vars.to, mensaje.vars.subject, mensaje.vars.message, 'Por favor, especific&aacute; el destinatario.');
			if(this.vars.message === '')
				mensaje.nuevo(mensaje.vars.to, mensaje.vars.subject, mensaje.vars.message, 'El mensaje esta vac&iacute;o.');
			//
			mydialog.procesando_inicio('Verificando...', 'Verificando Mensaje');
			this.ajax('validar', { para: this.vars.to }, mensaje.checkform);
		} else if(enviar === 1){
			mydialog.procesando_inicio('Enviando...', 'Enviando Mensaje');
			// ENVIAR
			let paramSendMsg = { para: mensaje.vars.to, asunto: mensaje.vars.subject, mensaje: mensaje.vars.message };
			this.ajax('enviar', paramSendMsg, mensaje.alert);
		}
	},
	// RESPONDER
	responder(mp_id) {
		this.vars['mp_id'] = $('#mp_id').val();
		this.vars['mp_body'] = $('#respuesta').bbcode();
		if(this.vars['mp_body'] == '') {
			$('#respuesta').focus();
			return;
		}
		this.ajax('respuesta', { id: this.vars['mp_id'], body: this.vars['mp_body'] }, function(h){
			$('#respuesta, .wysibb-body').html('');
			if(h.charAt(0) == '0') mydialog.alert("Error", h.substring(3));
			else $('#historial').append($(h.substring(3)).fadeIn('slow'));
			$('#respuesta').focus();
		});
	},
	last() {
		let CountMPAlert = parseInt($('#alerta_mps > a > span').html());
		notifica.close();
		favorito.close();
		shoutbox.close();
		usuario.close();
		//
		if ($('#mp_list').css('display') != 'none') {
			$('#mp_list').hide();
			$('a[name=Mensajes]').parent('li').removeClass('bg-active');
		} else {
			if (($('#mp_list').css('display') == 'none' && CountMPAlert > 0) || typeof mensaje.cache.last == 'undefined') {
				animateIcon('Mensajes', 'fa-envelope');
				$('a[name=Mensajes]').parent('li').addClass('bg-active');
				$('#mp_list').show();
				mensaje.ajax('lista', '', req => {
					mensaje.cache['last'] = req;
					mensaje.show();
				});
			} else mensaje.show();
		}
	},
	popup(mps) {
		let CountMPAlertPopup = parseInt($('#alerta_mps > a > span').html());
		if (mps != CountMPAlertPopup && mps > 0) {
			let MpsTotal = ' mensaje' + (mps != 1 ? 's' : '');
			if (!$('#alerta_mps').length) $('div.userInfoLogin > ul > li.mensajes').append(`<div class="alertas" id="alerta_mps"><a title="${mps}${MpsTotal}"><span></span></a></div>`);
			$('#alerta_mps > a > span').html(mps);
			$('#alerta_mps').animate({ top: '-=5px' }, 100, null, () => $('#alerta_mps').animate({ top: '+=5px' }, 100));
		} else if (mps == 0) $('#alerta_mps').remove();
	},
	show() {
		if (typeof mensaje.cache.last != 'undefined') {
			$('#alerta_mps').remove();
			$('a[name=Mensajes]').parent('li').addClass('bg-active');
			animateIcon('Mensajes', 'fa-envelope', false);
			$('#mp_list').show().children('ul').html(mensaje.cache.last);
		}
	},
	close(){
		$('#mp_list').hide();
		$('a[name=Mensajes]').parent('li').removeClass('bg-active');
	}
}
/* Favorito */
var favorito = {
	cache: {},
	last: function () {
		notifica.close();
		mensaje.close();
		shoutbox.close();
		usuario.close();
		//
		if ($('#fav_list').css('display') != 'none') {
			$('#fav_list').hide();
			$('a[name=Favoritos]').parent('li').removeClass('bg-active');
		} else {
			if (($('#fav_list').css('display') == 'none') || typeof favorito.cache.last == 'undefined') {
				$('a[name=Favoritos]').children('span').addClass('spinner');
				animateIcon('Favoritos', 'fa-star');
				$('a[name=Favoritos]').parent('li').addClass('bg-active');
				$('#fav_list').show();
				favorito.ajax(function (r) {
					favorito.cache['last'] = r;
					favorito.show();
					favorito.total();
				});
			} else favorito.show();
		}
	},
	ajax: function(fn){
		$('#loading').fadeIn(250);
		$.post(global_data.url + '/favoritos-lista.php', {}, request => {
			fn(request);
			$('#loading').fadeOut(350);
		});
	},
	show: function () {
		if (typeof favorito.cache.last != 'undefined') {
			$('a[name=Favoritos]').parent('li').addClass('bg-active');
			animateIcon('Favoritos', 'fa-star', false);
			$('#fav_list').show().children('ul').html(favorito.cache.last);
		}
	},
	total: function () {
		let total = parseInt($('#FTotal').text());
		if(total > 0) {
			$('#FavsTotal').html(`Favoritos <span class="floatR">${total}</span>`);
		}
	},
	close: function(){
		$('#fav_list').hide();
		$('a[name=Favoritos]').parent('li').removeClass('bg-active');
	}
}
/* Shout */
var shoutbox = {
   isOpen: false,
	last: function () {
		notifica.close();
		mensaje.close();
		favorito.close();
		usuario.close();
		//
   	$('#shout_list')[shoutbox.isOpen ? 'slideUp' : 'slideDown'](300, function() {
   	   var isVisible = $(this).is(':visible');
   	   $('button[name=Shout]').parent('li').toggleClass('bg-active', isVisible);
   	   shoutbox.isOpen = !shoutbox.isOpen;
   	});
	},
	close: function(){
		$('#shout_list').hide();
		$('button[name=Shout]').parent('li').removeClass('bg-active');
	}
}
/* Usuario */
var usuario = {
	last() {
		notifica.close();
		mensaje.close();
		favorito.close();
		shoutbox.close();
		//
		if ($('#user_list').css('display') != 'none') {
			$('#user_list').slideUp();
			$('a[name=Usuario]').parent('div').removeClass('bg-active');
		} else {
			if (($('#user_list').css('display') == 'none')) {
				$('a[name=Usuario]').parent('div').addClass('bg-active');
				$('#user_list').slideDown();
			}
		}
	},
	close() {
		$('#user_list').hide();
		$('a[name=Usuario]').parent('div').removeClass('bg-active');
	}
};

// NEWS
var news = {
	total: 0,
	count: 1,
	slider: function(){
		if(news.total > 1){
			if(news.count < news.total) news.count++;
			else news.count = 1;
			//
			$('#top_news > li').hide();
			$('#new_' + news.count).fadeIn();
			// INFINITO :D
			setTimeout("news.slider()",7000);
		}
	}
}

//IR AL CIELO BY TO-UP.NET
$(window).on('scroll', function() {
	const scrollButton = $('#scroll-up');
	let scrollStatus = ($(this).scrollTop() > 100);
	scrollButton[scrollStatus ? 'fadeIn' : 'fadeOut']();
});

$('#scroll-up').on('click', function() {
	$('html, body').animate({scrollTop: 0}, 800);
	return false;
});

const changeTheme = {
	open() {
		$.getJSON(`${global_data.url}/change-get-themes.php`, ({ active, themes }) => {
			const themeOptions = Object.entries(themes).map(([id, name]) => {
				const isActive = (id === active);
				return `
					<button class="reset change_option${isActive ? ' color-tertiary fw-bold' : ''} hover:bg-gray-light" 
						onclick="changeTheme.theme(${id})">
						${isActive ? '<i class="fa-solid fa-check color-secondary" aria-hidden="true"></i> ' : ''}${name}
					</button>`;
			}).join('');
			mydialog.master({
				title: 'Cambiar plantilla',
				body: `<div class="d-flex flex-column gap-3">${themeOptions}</div>`,
				buttons: { good: { value: 'Cambiar', action: 'changeTheme.cambiar()' } }
			});
		});
	},
	theme(theme) {
		$.post(`${global_data.url}/change-theme.php`, { theme }, (request) => {
			if (request.startsWith('0')) return mydialog.alert('Error', `<div class="emptyData">${request.slice(3)}</div>`);
			location.reload();
		});
	}
};

if($('#respuesta').length && !$('.wysibb-texarea').length){
   const wbbOpt = { 
   	buttons: "smilebox,|,bold,italic,underline,strike,|,img,video,link,|,removeFormat" 
   }
   $('#respuesta').removeAttr('onblur onfocus class style title').css('height', '80').html('').wysibb(wbbOpt);
}
function systemStart() {
	const mode = localStorage.getItem('theme-mode') || 'light';
	const color = localStorage.getItem('theme-color') || 'default';
	$('html').attr({ 
		'data-theme': mode,
		'data-theme-color': color
	});
}

$(document).ready(() => {

	systemStart();

	const brandday = $('#brandday');
	$('#stickymsg').on({
   	mouseover: () => brandday.css('opacity', 0.5),
   	mouseout:  () => brandday.css('opacity', 1),
   	click:     () => location.href = `${global_data.url}/moderacion/`
	});

	/* NOTICIAS */
	news.total = $('#top_news > li').length;
	news.slider();
	// Encode URLs automáticamente para enlaces con data-encode="true"
	$('a[data-encode="true"]').attr('href', function() {
		return `${global_data.url}/go/?p=${base64_encode($(this).attr('href'))}`;
	});
	// Buscar botón toggle y campo de búsqueda
	$('.searching > button').on('click', function() {
		const $parent = $(this).parent();
		const $input = $parent.find('input[name="q"]');
		$parent.toggleClass('open-input', !$parent.hasClass('open-input') || $input.val().trim().length > 0);
	});
	// Controlar dropdowns y ocultar al hacer clic fuera
	const dropdowns = [
		{ selector: '#mon_list', trigger: 'Monitor', action: notifica.last },
		{ selector: '#mp_list', trigger: 'Mensajes', action: mensaje.last },
		{ selector: '#fav_list', trigger: 'Favoritos', action: favorito.last },
		{ selector: '#shout_list', trigger: 'Shout', action: shoutbox.last },
		{ selector: '#user_list', trigger: 'Usuario', action: usuario.last }
	];
	$('body').on('click', function(e) {
		dropdowns.forEach(({ selector, trigger, action }) => {
			if ($(selector).is(':visible') && !$(e.target).closest(selector).length && !$(e.target).closest(`a[name=${trigger}]`).length) action();
		});
	});
	// Dropdown botón de menú
	$('.dropdown-button').on('click', function() {
		$(this).parent().toggleClass("open");
	});
	// Selección en menú desplegable y cerrar
	$(".dropdown-menu li").on('click', function() {
		$(".dropdown-button").text($(this).text());
		$(".dropdown").removeClass("open");
	});
	// Cerrar menú desplegable al hacer clic fuera
	$(document).on('click', function(e) {
		if (!$(e.target).closest('.dropdown').length) $(".dropdown").removeClass("open");
	});

	if($('textarea[name="add_wall_comment"]').length > 0) {
		$('textarea[name="add_wall_comment"]').wysibb({ 
			buttons: "smilebox,|,bold,italic,underline,strike,img,video,link,removeFormat" 
		});
	}
});