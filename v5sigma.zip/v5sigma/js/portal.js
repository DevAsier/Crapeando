'use strict';
var portal = {
	cache: {},
	load_tab(type, obj) {
		$('#tabs_menu > li').removeClass('selected');
		$(obj).parent().addClass('selected');
		$('#portal_content > .showHide').hide();
		// CARGAMOS
		$(`#portal_${type}`).show();
		if($(`#portal_${type}`).attr('status') !== 'activo') {
			portal.posts_page(type, 1, false);
		}
	},
	// CARGAR CONTENIDO
	save_configs() {
		let inputs = $('#config_inputs :input');
		let cat_ids = '';
		inputs.each(function() {
			if($(this).prop('checked')) cat_ids += $(this).val() + ',';
		});
		if(cat_ids === '') return false;
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/portal-posts_config.php`, { cids: cat_ids }, response => {
			if(response.charAt(0) === '0') {
				mydialog.alert('Error', response.substring(3));
				return;
			}
			$('#config_posts').slideUp();
			portal.posts_page('posts',1, false);
			$('#loading').fadeOut(350);
		});
	},
	// PAGINAS PARA LOS ULTIMOS POSTS
	posts_page(type, page, scroll) {
		const content = $(`#portal_${type}_content`);
		content.html('<center>Cargando...</center>');
		//
		if(scroll === true) $.scrollTo('#cuerpocontainer', 250);
		if(typeof portal.cache[`${type}_${page}`] === 'undefined') {
			$('#loading').fadeIn(250);
			$.get(`${global_data.url}/portal-${type}_pages.php?page=${page}`, response => {
				portal.cache[`${type}_${page}`] = h;
				$('#portal_' + type).attr('status', 'activo');
				content.html(h);
				$('#loading').fadeOut(350);
			});
		} else content.html(portal.cache[`${type}_${page}`]);
	}
}

function shoutAction(tipo, parte, filtrame = 'recientes', acciones = '', tiempos = 0) {
	$('#loading').fadeIn(250);
	$(`#perfil-${parte}`).css('opacity', 0.5);
	$('#portalMenu span').removeClass('bg bg-opacity-2');

	let params = { tipo, parte };
	if(filtrame === 'populares') {
		Object.assign(params,{ acciones, tiempos});
	}

	$.get(`${global_data.url}/muro-${filtrame}.php`, params, response => {
		$(`#perfil-${parte}`).css('opacity', 1).html(response);
		$(`#portalMenu span.button-${tipo}`).addClass('bg bg-opacity-2');
		$('#portalMenu').removeClass('d-flex').addClass('d-none');
	}).fail(() => {
		$(`#perfil-${parte}`).css('opacity', 1);
		$('#portalMenu span.button-0').addClass('bg bg-opacity-2');
		$('#portalMenu').addClass('d-flex').removeClass('d-none');
	}).always(() => $('#loading').fadeOut(350));
}

function recents(tipo) {
	shoutAction(tipo, 'news', 'recientes');
}
function featured(tipo) {
	shoutAction(tipo, 'destacados', 'destacados');
}
function popular(tipo, acciones, tiempos) {
	shoutAction(tipo, 'populares', 'populares', acciones, tiempos);
}

var pin = {
	updateListPins() {
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/portal-actualizar-pin.php`, response => {
			$('#repin').html(response);
			$('#loading').fadeOut(350);
		});
	},
	nuevo() {
		let textarea = $('#addPin');
		let text = textarea.val();
		// VACIO o DEFAULT
		if (text.length < 2 || text.length > 32 || !text.trim()) {
		   let message = text.trim().length < 2 ? 'más de 2' : 'menos de 32';
		   if(!text.trim()) mydialog.alert('Oops!', `Un pin debe tener ${message} caracteres`);
		   textarea.focus();
		   return;
		}
		$('#loading').fadeIn(250);
		$.post(`${global_data.url}/portal-pin.php?do=add`, "cuerpo=" + encodeURIComponent(text), response => {
			mydialog.toast(response.substring(3), (response.charAt(0) === '0' ? 'danger' : 'success'));
			if(response.charAt(0) === '0') {
				textarea.focus();
				return;
			}
			textarea.val('');               
			$('.miComentario #gif_cargando').hide();
			this.updateListPins();
		}).always(() => $('#loading').fadeOut(350));
	},	
	releaseAction(page, params, subparam = '') {
		$('#loading').fadeIn(250); 
		$.post(`${global_data.url}/portal-${page}.php${subparam}`, params, response => {
			if(response.charAt(0) === '0'){
				mydialog.toast(response.substring(3), 'danger');
				return;
			}
		}).always(() => {
			$('#loading').fadeOut(350);
			this.updateListPins();
		});
	},
	eliminar(id) {
		this.releaseAction('pin', { id, do: 'delete' }, '?do=delete');
	},	
	convertir(id) {
		this.releaseAction('covertir-hashtag', { id });
	},
	usar(hastag) {
		const wall = $('#wall');
		let texto = wall.val().trim();
		let agregar = empty(texto) ? `#${hastag} ` : `${texto} #${hastag} `;
		$('#wall').val(agregar).focus();
	}
}

//FUNCION SIMPLE PARA EL MENU DEL PORTAL 
$(document).ready(function() {
	//$('.globo').hide();//ESCONDER GLOBO ROJO DE NOTIFICACION SHOUTS
 	$('#selec a').on('click', function(event) {
		event.preventDefault();
		$(this).parent().addClass('activo');
		$(this).parent().siblings().removeClass('activo');
	});
	$('#GloNoti').on('click', () => $('#NubeShout').hide());
	$('#GloSho').on('click', () => $('#NubeNotifi').hide());	
});	