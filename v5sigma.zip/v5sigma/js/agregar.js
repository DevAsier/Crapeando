'use strict';
// Algunas variables
const loadWYSIBB = $('textarea[name="cuerpo"]');
// borrador
let draftSetTime;
let draftLastMessage = '';
let draftIsEnabled = true;
// Post
let confirm = true;
let tags = false;
let currentTime = new Date();
// Obtenemos hora
const hours = [currentTime.getHours(), currentTime.getMinutes(), currentTime.getSeconds()].join(':');

// Preguntar antes de cerrar
let confirmar = true;
window.onbeforeunload = () => {
	if (confirmar && ($("input[name=titulo]").val() || loadWYSIBB.bbcode())) 
		return "Este post no fue publicado y se perdera.";
}

function countUpperCase(string) {
	var len = string.length, 
	strip = string.replace(/([A-Z])+/g, '').length, 
	strip2 = string.replace(/([a-zA-Z])+/g, '').length, 
	percent = (len  - strip) / (len - strip2) * 100;
	return percent;
}

// Mostramos el error
function error(objeto = '', mensaje = '', tipo = '') {
	let addRemove = tipo ? 'addClass' : 'removeClass';
	let showHide = tipo ? 'show' : 'hide';
	objeto.parent().children('.helper')[addRemove]('error').html(mensaje)[showHide]();
}

function borrador() {
	let replace_body = 'cuerpo=' + encodeURIComponent(loadWYSIBB.bbcode());
	let params = $("form[name=newpost]").serialize().replace('cuerpo=', replace_body);
	const borrador_id = $('input[name="borrador_id"]').val()
	$('div#borrador-guardado').html('Guardando...');
	setTimeout(() => $('div#borrador-guardado').html(''), 6000);
	draftSetTime = setTimeout('draftSave()', 6000);
	draftSave(false);

	if(!empty(borrador_id)) params += '&borrador_id=' + encodeURIComponent(borrador_id);
	let page = 'borradores-' + (!empty(borrador_id) ? 'guardar' : 'agregar');
	if(comprobarCategoria()) {
		$.post(`${global_data.url}/${page}.php`, params, req => {
			let reqType = parseInt(req.charAt(0));
			if(reqType === 0) {
				clearTimeout(draftSetTime);
				draftSetTime = setTimeout(draftSave, 5000); 
			} else {
				if(!empty(borrador_id)) $('input[name="borrador_id"]').val(message);
			}
			draftLastMessage = (reqType === 0) ? `Guardado a las ${hours} hs.` : req.substring(3);
			$('div#borrador-guardado').html(draftLastMessage);
			setTimeout(() => $('div#borrador-guardado').html(''), 6000);
		}).fail(() => mydialog.error_500('save_borrador()'))
	}
}

function draftSave(enable = true) {
	const draftButton = $('input#borrador');
	if (draftButton.length) {
		draftButton.toggleClass('disabled', !enable).prop('disabled', !enable);
	}
	draftIsEnabled = enable;
}

function comprobarTitulo() {
	if ($('input[name=titulo]').val().length < 5) {
		error($('input[name=titulo]'), 'Debes ingresar un titulo para el post', true);
		$('input[name=titulo]').focus();
		return false;
	}
   error($('input[name=titulo]'), '', false);
	return true;
}
function comprobarContenido() {
	if (loadWYSIBB.bbcode().length < 1) {
		error($('.wysibb'), 'Ingresa contenido para el post', true);
		loadWYSIBB.focus();
		window.scrollTo(0, 50)
		return false;
	}
   error($('.wysibb'), '', false);
	return true;
}
function comprobarTags() {
	let tags = $('input[name=tags]').val().split(',');
	let msg = 'Tienes que ingresar por lo menos 4 tags separados por coma.';
	if (tags.length < 4) {
		error($('input[name=tags]'), msg, true);
		window.scrollTo(0, 50)
		return false;
	} else {
		for(let i = 0; i < tags.length; i++) {
			error($('input[name=tags]'), msg, (tags[i] == ''));
			if(tags[i] == '') return false;
		}
	}
   error($('input[name=tags]'), '', false);
	return true;
}
function comprobarCategoria() {
	if (!$('select[name=categoria]').val()) {
		error($('select[name=categoria]'), 'Selecciona una categor&iacute;a', true);
		window.scrollTo(0, 50);
		return false;
	} else {
	   error($('select[name=categoria]'), '', false);
		return true;
	}
}
function comprobarPortada() {
	if ($('input[name="portada"]').val().length < 1) {
		error($('input[name="portada"]'), 'Ingresa una portada', true);
		window.scrollTo(0, 50);
		return false;
	}
   error($('input[name=portada]'), '', false);
	return true;
}

function replaceAccents(str) {
	// Normalizar la cadena para eliminar acentos
	let normalized = str.normalize("NFD");
	// Eliminar todos los caracteres que no sean letras o espacios
	let cleaned = normalized.replace(/[^a-zA-Z ]/g, '');
	return cleaned;
}

function comprobar(obj) {
	const { id: actionFn } = obj;
	let required = {
		titulo: comprobarTitulo() || false,
		cuerpo: comprobarContenido() || false,
      tags: comprobarTags() || false,
      categoria: comprobarCategoria() || false,
		portada: comprobarPortada() || false
	}
	if (!required.titulo || !required.cuerpo || !required.tags || !required.categoria || !required.portada) {
      return false;
   }
	if (typeof window[actionFn] === 'function') {
    	window[actionFn]();
  	}
}

function previsualizar() {
	mydialog.master({
		title: 'Vista preliminar',
		body: '<div class="carf"><p>Cargando vista previa</p></div>',
		buttons: {
			display_all: false
		}
	});
	// PREVIEW
	const data = { cuerpo: loadWYSIBB.bbcode() };
	$.post(global_data.url + '/posts-preview.php?ts=true', toStringParams(data), req => {
		mydialog.master({
			title: $('input[name=titulo]').val(),
			body: req,
			buttons: {
				display_all: true,
				good: { display: false },
				fail: { display: true, value: 'Cerrar' }
			}
		});
		window.scrollTo(0, 50)
	})	
}

function publicar() {
	mydialog.procesando_inicio('Comprobando contenido...','Publicando');
	confirmar = false;
	$('form[name="newpost"]').submit();
}

$(document).ready(() => {
	$('#previsualizar, #publicar, #borrador').on('click', function() {
		comprobar(this);
	});
	// Cargamos el editor
	$('textarea[name="cuerpo"]').css({height: 470}).wysibb();

	const syncTitulo = $('input[name=titulo]');
	const syncTags = $('input[name=tags]');
	const syncPortada = $('input[name=portada]');
	
	// Chequeamos el titulo
	syncTitulo.on('keyup', () => {
		const titleVal = syncTitulo.val();
		let checkTitle = (titleVal.length >= 5 && countUpperCase(titleVal) > 59) 
		error(syncTitulo, 'El t&iacute;tulo no debe estar en may&uacute;sculas', checkTitle);
		return false;
	});
	// Comprobamos que no este publicado o sea repetido
	syncTitulo.on('blur', () => {
		const titleVal = syncTitulo.val();
		if(!empty(titleVal)) {
			$.post(`${global_data.url}/posts-genbus.php?do=search`, toStringParams({ q: titleVal }), respuesta => $('#repost').html(respuesta))
		}
	});
	syncPortada.on('keyup', () => {
		const preview = $('#preview_image')
		preview.css({ width: '140px', height: '120px' }).show();
	   $('#img_portada').attr({ src: syncPortada.val() });
	});
	// Generamos etiquetas en base al titulo
	let generar = true;
	syncTags.on('click', () => {
		if(generar) {
			const titleVal = syncTitulo.val();
			if (!empty(titleVal)) {
				let generatedTags = titleVal.split(' ')
				.map(tag => replaceAccents(tag.trim().toLowerCase()) )
				.filter(tag => tag.length > 4);
				syncTags.val(generatedTags.join(', '));
				tags = true;
			}
		}
	});
});