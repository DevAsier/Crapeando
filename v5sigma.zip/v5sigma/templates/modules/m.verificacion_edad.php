<?php
// Obtiene la URL actual
$currentUrl = $_SERVER['REQUEST_URI'];

// Verifica si la URL contiene "/crap/"
if (strpos($currentUrl, '/crap/') !== false) {
    echo '<div id="adultWarning" style="display:none;">
            <div style="position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.7);z-index:9999;color:white;text-align:center;">
                <div style="margin:20% auto;width:90%;max-width:400px;background:#333;padding:20px;border-radius:10px;">
                    <h2>Estás en una zona con contenido adulto</h2>
                    <p>Este contenido está destinado solo para mayores de edad. Haz clic en continuar si estás de acuerdo.</p>
                    <button onclick="closeWarning()" style="padding:10px 20px;background:#007BFF;color:white;border:none;border-radius:5px;cursor:pointer;">Continuar</button>
                </div>
            </div>
          </div>';
    echo '<script>
            function closeWarning() {
                document.getElementById("adultWarning").style.display = "none";
            }
            window.onload = function() {
                document.getElementById("adultWarning").style.display = "block";
            };
          </script>';
}
